# agents/risk_agent.py  —  Day 12 | Risk Management Agent
# Production-hardened: uses core.constants, consistent key naming
# Key naming convention matches RiskEngine: "lot" (not "lot_size"),
# "risk_pc" (not "risk_percent"), "risk_usd" (not "risk_amount_usd")

from utils.logger import get_logger
from core.constants import get_pip_size, get_pip_value_usd, clean_symbol

log = get_logger("risk_agent")


class RiskAgent:
    """
    Risk Management Agent — calculates lot size, SL, TP from signal + ATR.
    Enforces 1% risk rule. Tracks daily loss limit.

    This is a simpler alternative to RiskEngine. The main pipeline
    uses RiskEngine by default; this agent is available for
    lightweight or per-pair risk calculations.
    """

    MAX_RISK_PERCENT    = 1.0    # max 1% account risk per trade
    # Day 81+ hotfix: load DAILY_LOSS_LIMIT from config (default 20.0).
    # Was hard-coded 3.0 — user wants 20.0.
    try:
        from config import DAILY_LOSS_LIMIT_PCT as _CFG_DLL
        DAILY_LOSS_LIMIT = float(_CFG_DLL)
    except Exception:
        DAILY_LOSS_LIMIT = 20.0
    # 2026-08-12: TP 1:1.5 R:R — SL=1.5 ATR (~25p), TP=2.25 ATR (~37p)
    MIN_RR              = 1.5    # minimum risk:reward (break-even WR=43%)
    ATR_SL_MULTIPLIER   = 1.5   # SL = ATR * 1.5 (~25 pips on EURUSD H1)

    def __init__(self, account_balance: float = 1000.0):
        self.balance       = account_balance
        self.daily_loss_pc = 0.0

    def calculate(
        self,
        signal:   str,
        entry:    float,
        ind_ctx:  dict,
        regime:   dict,
        symbol:   str = "EURUSD",
    ) -> dict:
        """Calculate full risk parameters from signal + entry + ATR."""

        if signal == "NO TRADE":
            return self._no_trade("Signal is NO TRADE")

        if self.daily_loss_pc >= self.DAILY_LOSS_LIMIT:
            return self._no_trade(
                f"Daily loss limit hit ({self.daily_loss_pc:.1f}%)"
            )

        # FIX (review): previously defaulted missing ATR to a hardcoded
        # 0.0005 — a plausible value for a 4/5-digit pair like EURUSD, but
        # wrong by ~100x for JPY pairs and by 1000x+ for metals/indices/
        # crypto. A silent wrong-scale guess produces a too-tight SL and
        # an oversized lot for the real risk taken — exactly backwards
        # for a risk-management module. Fail safe instead: if ATR is
        # missing or non-positive, refuse to guess and reject the trade
        # with an explicit reason rather than silently mis-sizing it.
        atr = ind_ctx.get("atr")
        if atr is None or atr <= 0:
            return self._no_trade(
                f"ATR unavailable or invalid for {symbol} "
                f"(atr={atr!r}) — refusing to guess a default SL distance"
            )
        csym = clean_symbol(symbol)
        pip = get_pip_size(csym)
        pip_val_std = get_pip_value_usd(csym)

        # FIX (review): pip_val_std is used as a divisor below
        # (risk_amount / (sl_pips * pip_val_std)). Previously there was
        # no guard for pip_val_std == 0 — an unrecognized/mis-cleaned
        # symbol returning 0 from get_pip_value_usd() would raise an
        # unhandled ZeroDivisionError mid-cycle instead of failing safe.
        if pip_val_std <= 0:
            return self._no_trade(
                f"Invalid pip value for {symbol} (pip_val_std={pip_val_std!r}) "
                f"— cannot size position, refusing to guess"
            )

        # Regime-based SL multiplier
        volatility = regime.get("volatility", "NORMAL")
        sl_mult = {
            "LOW_VOLATILITY":  1.2,
            "NORMAL":          self.ATR_SL_MULTIPLIER,
            "HIGH_VOLATILITY": 2.0,
        }.get(volatility, self.ATR_SL_MULTIPLIER)

        sl_distance = round(atr * sl_mult, 5)
        sl_pips     = round(sl_distance / pip) if pip > 0 else 10

        # Guard: if sl_pips is 0 or sl_distance is too small, use defaults
        if sl_pips < 1:
            sl_pips = 10
            sl_distance = sl_pips * pip

        # TP = SL * min RR
        tp_distance = round(sl_distance * self.MIN_RR, 5)
        tp_pips     = round(tp_distance / pip)

        # SL/TP price levels
        if signal == "BUY":
            sl_price = round(entry - sl_distance, 5)
            tp_price = round(entry + tp_distance, 5)
        else:   # SELL
            sl_price = round(entry + sl_distance, 5)
            tp_price = round(entry - tp_distance, 5)

        # Lot size — 1% risk rule
        risk_amount = self.balance * (self.MAX_RISK_PERCENT / 100)
        lot_raw     = risk_amount / (sl_pips * pip_val_std) if sl_pips > 0 else 0
        lot         = round(max(0.01, min(lot_raw, 10.0)), 2)

        rr_ratio    = round(tp_pips / sl_pips, 2) if sl_pips > 0 else 0

        result = {
            "approved":       True,
            "signal":         signal,
            "entry":          entry,
            "sl_price":       sl_price,
            "tp_price":       tp_price,
            "sl_pips":        sl_pips,
            "tp_pips":        tp_pips,
            "lot":            lot,         # Consistent key name with RiskEngine
            "lot_size":       lot,         # Backward compat alias
            "risk_pc":        self.MAX_RISK_PERCENT,  # Consistent key name
            "risk_percent":   self.MAX_RISK_PERCENT,  # Backward compat alias
            "risk_usd":       round(risk_amount, 2),   # Consistent key name
            "risk_amount_usd": round(risk_amount, 2),  # Backward compat alias
            "rr_ratio":       rr_ratio,
            "balance":        self.balance,
            "reject_reason":  None,
        }

        # Final RR check
        if rr_ratio < self.MIN_RR:
            result["approved"]      = False
            result["reject_reason"] = f"RR {rr_ratio} < min {self.MIN_RR}"

        log.info(
            f"[RiskAgent] {signal} | Entry: {entry} | "
            f"SL: {sl_price} ({sl_pips}p) | "
            f"TP: {tp_price} ({tp_pips}p) | "
            f"Lot: {lot} | RR: {rr_ratio} | "
            f"Approved: {result['approved']}"
        )
        return result

    def _no_trade(self, reason: str) -> dict:
        log.info(f"[RiskAgent] No trade — {reason}")
        return {
            "approved":        False,
            "signal":          "NO TRADE",
            "reject_reason":   reason,
            "entry":           None,
            "sl_price":        None,
            "tp_price":        None,
            "lot":             0,
            "lot_size":        0,
            "sl_pips":         0,
            "tp_pips":         0,
            "rr_ratio":        0,
            "risk_usd":        0,
            "risk_amount_usd": 0,
            # FIX (review): the approved-path dict in calculate() includes
            # "balance", "risk_pc", and "risk_percent" — this dict didn't,
            # so any downstream code expecting a uniform schema regardless
            # of approval status would KeyError on the no-trade path.
            "balance":         self.balance,
            "risk_pc":         self.MAX_RISK_PERCENT,
            "risk_percent":    self.MAX_RISK_PERCENT,
        }

    def print_summary(self, result: dict) -> None:
        bar  = "=" * 44
        icon = "[OK]" if result["approved"] else "[REJECT]"
        log.info(bar)
        log.info(f"  {icon}  RISK AGENT")
        log.info(bar)
        log.info(f"  Approved    : {result['approved']}")
        if result.get("reject_reason"):
            log.info(f"  Rejected    : {result['reject_reason']}")
        if result["approved"]:
            log.info(f"  Signal      : {result['signal']}")
            log.info(f"  Entry       : {result['entry']}")
            log.info(f"  SL          : {result['sl_price']}  ({result['sl_pips']} pips)")
            log.info(f"  TP          : {result['tp_price']}  ({result['tp_pips']} pips)")
            log.info(f"  Lot         : {result.get('lot', result.get('lot_size', 0))}")
            log.info(f"  Risk        : {result.get('risk_pc', result.get('risk_percent', 0))}%  (${result.get('risk_usd', result.get('risk_amount_usd', 0))})")
            log.info(f"  R:R         : 1:{result['rr_ratio']}")
        log.info(bar)

    def get_ai_context(self, result: dict) -> dict:
        return {
            "risk_approved":  result["approved"],
            "risk_lot":       result.get("lot", result.get("lot_size", 0)),
            "risk_sl_pips":   result.get("sl_pips", 0),
            "risk_tp_pips":   result.get("tp_pips", 0),
            "risk_rr":        result.get("rr_ratio", 0),
            "risk_reject":    result.get("reject_reason"),
        }