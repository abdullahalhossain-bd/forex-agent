'use client';

import React from 'react';
import { useAuthStore, useNavStore } from '@/stores/admin';
import Sidebar from '@/components/admin/sidebar/Sidebar';
import Header from '@/components/admin/header/Header';
import LoginPage from '@/components/admin/pages/LoginPage';
import DashboardPage from '@/components/admin/pages/DashboardPage';
import NoticesPage from '@/components/admin/pages/NoticesPage';
import OfficersPage from '@/components/admin/pages/OfficersPage';
import ServiceItemsPage from '@/components/admin/pages/ServiceItemsPage';
import EmergencyPage from '@/components/admin/pages/EmergencyPage';
import ClinicsPage from '@/components/admin/pages/ClinicsPage';
import DoctorsPage from '@/components/admin/pages/DoctorsPage';
import DonorsPage from '@/components/admin/pages/DonorsPage';
import BusinessPage from '@/components/admin/pages/BusinessPage';
import PersonsPage from '@/components/admin/pages/PersonsPage';
import ComplaintsPage from '@/components/admin/pages/ComplaintsPage';
import BudgetPage from '@/components/admin/pages/BudgetPage';
import NotificationsPage from '@/components/admin/pages/NotificationsPage';
import UsersPage from '@/components/admin/pages/UsersPage';
import ProfilePage from '@/components/admin/pages/ProfilePage';
import AuditLogPage from '@/components/admin/pages/AuditLogPage';
import SettingsPage from '@/components/admin/pages/SettingsPage';
import CommandPalette from '@/components/admin/common/CommandPalette';
import ReportsPage from '@/components/admin/pages/ReportsPage';
import ServiceDirectoryPage from '@/components/admin/pages/ServiceDirectoryPage';
import MobileBottomNav from '@/components/admin/common/MobileBottomNav';

const PAGE_MAP: Record<string, React.ComponentType> = {
  dashboard: DashboardPage,
  notices: NoticesPage,
  officers: OfficersPage,
  serviceItems: ServiceItemsPage,
  serviceDirectory: ServiceDirectoryPage,
  emergency: EmergencyPage,
  clinics: ClinicsPage,
  doctors: DoctorsPage,
  donors: DonorsPage,
  business: BusinessPage,
  persons: PersonsPage,
  complaints: ComplaintsPage,
  reports: ReportsPage,
  budget: BudgetPage,
  notifications: NotificationsPage,
  users: UsersPage,
  profile: ProfilePage,
  auditLog: AuditLogPage,
  settings: SettingsPage,
};

export default function Home() {
  const { isAuthenticated } = useAuthStore();
  const { currentPage, sidebarOpen } = useNavStore();

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  const PageComponent = PAGE_MAP[currentPage] || DashboardPage;

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <CommandPalette />
      <div
        className={`transition-all duration-300 ${sidebarOpen ? 'lg:ml-[260px]' : 'lg:ml-[72px]'}`}
      >
        <Header />
        <main className="p-4 lg:p-6 pb-24">
          <div key={currentPage} className="animate-fade-in-up">
            <PageComponent />
          </div>
        </main>
        {/* Thin decorative gradient line above footer */}
        <div className="h-[2px] w-full" style={{ background: 'linear-gradient(90deg, transparent 0%, rgba(255,107,53,0.2) 50%, transparent 100%)' }} />
        <footer className="lg:sticky lg:bottom-0 w-full bg-white dark:bg-[#1a1a2e] border-t dark:border-white/5 py-3 px-6 z-10 mt-auto">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-1 text-xs text-muted-foreground max-w-[1400px] mx-auto">
            <p>© ২০২৫ বেতাগী উপজেলা প্রশাসন</p>
            <p className="text-muted-foreground/50">পাওয়ারড বাই ই-সেবা</p>
          </div>
        </footer>
        <MobileBottomNav />
      </div>
    </div>
  );
}