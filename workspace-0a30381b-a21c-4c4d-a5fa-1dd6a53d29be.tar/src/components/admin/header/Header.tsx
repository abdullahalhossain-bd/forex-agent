'use client';

import React, { useState, useEffect } from 'react';
import { Menu, Bell, LogOut, User, ChevronRight, Clock, Sun, Moon, Search, CheckCheck, Settings } from 'lucide-react';
import { useTheme } from 'next-themes';
import { useAuthStore, useNavStore } from '@/stores/admin';
import { ROLE_LABELS, SIDEBAR_MENU } from '@/types/admin';
import { MOCK_NOTIFICATIONS } from '@/lib/mock-data';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';

const PAGE_NAMES: Record<string, string> = {
  dashboard: 'ড্যাশবোর্ড',
  notices: 'নোটিশ বোর্ড',
  officers: 'সরকারি কর্মকর্তা',
  serviceItems: 'সেবা আইটেম',
  emergency: 'জরুরি নম্বর',
  clinics: 'ক্লিনিক/হাসপাতাল',
  doctors: 'বিশেষজ্ঞ চিকিৎসক',
  donors: 'রক্তদাতা',
  business: 'ব্যবসা প্রতিষ্ঠান',
  persons: 'বিশিষ্ট ব্যক্তি',
  complaints: 'অভিযোগ ব্যবস্থাপনা',
  reports: 'রিপোর্ট ও বিশ্লেষণ',
  budget: 'বাজেট ও উন্নয়ন',
  notifications: 'নোটিফিকেশন',
  users: 'ব্যবহারকারী',
  profile: 'প্রোফাইল',
  auditLog: 'সিস্টেম লগ',
  settings: 'সেটিংস',
};

export default function Header() {
  const { user, logout } = useAuthStore();
  const { currentPage, toggleSidebar, toggleMobileSidebar, sidebarOpen, navigate } = useNavStore();
  const { theme, setTheme, resolvedTheme } = useTheme();
  const [liveTime, setLiveTime] = useState('');

  const unreadCount = MOCK_NOTIFICATIONS.filter(n => !n.isRead).length;

  useEffect(() => {
    const update = () => {
      setLiveTime(new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }));
    };
    update();
    const interval = setInterval(update, 30000);
    return () => clearInterval(interval);
  }, []);

  const getBreadcrumb = () => {
    const parent = SIDEBAR_MENU.find(m =>
      m.id === currentPage || m.children?.some(c => c.id === currentPage)
    );
    const child = parent?.children?.find(c => c.id === currentPage);
    return { parent: parent?.label, child: child?.label || PAGE_NAMES[currentPage] || currentPage };
  };

  const bc = getBreadcrumb();

  const notifTypeColors: Record<string, string> = {
    'তথ্য': 'bg-sky-100 text-sky-600',
    'সতর্কতা': 'bg-amber-100 text-amber-600',
    'জরুরি': 'bg-red-100 text-red-600',
    'সাধারণ': 'bg-gray-100 text-gray-500',
  };

  return (
    <header className="sticky top-0 z-20 bg-white/80 dark:bg-[#1a1a2e]/90 backdrop-blur-md border-b dark:border-white/5">
      {/* Thin orange line at top */}
      <div className="h-[2px] w-full" style={{ background: 'linear-gradient(90deg, transparent, rgba(255,107,53,0.15), transparent)' }} />
      <div className="flex items-center justify-between h-14 px-4 lg:px-6">
        <div className="flex items-center gap-3">
          <button
            onClick={sidebarOpen !== undefined ? toggleSidebar : toggleMobileSidebar}
            className="lg:hidden p-2 rounded-[8px] hover:bg-muted transition-colors"
          >
            <Menu className="h-5 w-5" />
          </button>
          <button
            onClick={toggleSidebar}
            className="hidden lg:flex p-2 rounded-[8px] hover:bg-muted transition-colors"
          >
            <Menu className="h-5 w-5" />
          </button>
          <nav className="flex items-center gap-1 text-sm">
            <span className="text-muted-foreground">বেতাগী ই-সেবা</span>
            {bc.parent && <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />}
            {bc.parent && <span className="text-muted-foreground hidden sm:inline">{bc.parent}</span>}
            {bc.parent && <ChevronRight className="h-3.5 w-3.5 text-muted-foreground hidden sm:block" />}
            <span className="font-medium text-foreground">{bc.child}</span>
          </nav>
        </div>

        <div className="flex items-center gap-2">
          {/* Search shortcut hint */}
          <button
            onClick={() => {
              const event = new KeyboardEvent('keydown', { key: 'k', metaKey: true, bubbles: true });
              window.dispatchEvent(event);
            }}
            className="hidden lg:flex items-center gap-2 text-xs text-muted-foreground/60 bg-muted/50 dark:bg-white/5 px-2.5 py-1.5 rounded-[8px] hover:bg-muted dark:hover:bg-white/10 transition-colors cursor-pointer"
          >
            <Search className="h-3.5 w-3.5" />
            <span>খুঁজুন...</span>
            <kbd className="text-[10px] px-1 py-0.5 rounded bg-background dark:bg-white/5 border dark:border-white/10">⌘K</kbd>
          </button>

          {/* Live clock */}
          <div className="hidden md:flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/50 px-2.5 py-1.5 rounded-[8px]">
            <Clock className="h-3.5 w-3.5" />
            <span className="tabular-nums">{liveTime}</span>
          </div>

          {/* Theme toggle */}
          <button
              onClick={() => setTheme(resolvedTheme === 'dark' ? 'light' : 'dark')}
              className="p-2 rounded-[8px] hover:bg-muted transition-colors"
              title={resolvedTheme === 'dark' ? 'হালকা মোড' : 'অন্ধকার মোড'}
            >
              <Sun className="h-5 w-5 hidden dark:block text-amber-400" />
              <Moon className="h-5 w-5 block dark:hidden text-muted-foreground" />
            </button>

          {/* Notification bell */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="relative p-2 rounded-[8px] hover:bg-muted transition-colors">
                <Bell className="h-5 w-5 text-muted-foreground" />
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-[#FF6B35] text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse-dot">
                    {unreadCount}
                  </span>
                )}
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80 rounded-[12px] p-0">
              <div className="px-4 py-3 border-b flex items-center justify-between">
                <p className="font-semibold text-sm">নোটিফিকেশন</p>
                {unreadCount > 0 && (
                  <span className="text-[10px] bg-[#FF6B35]/10 text-[#FF6B35] px-2 py-0.5 rounded-full font-medium">
                    {unreadCount} নতুন
                  </span>
                )}
              </div>
              {unreadCount > 0 && (
                <DropdownMenuItem
                  onClick={() => {}}
                  className="flex items-center gap-1.5 px-4 py-1.5 text-xs text-muted-foreground hover:text-[#FF6B35] cursor-pointer"
                >
                  <CheckCheck className="h-3.5 w-3.5" /> সব পঠিত
                </DropdownMenuItem>
              )}
              <div className="max-h-80 overflow-y-auto custom-scrollbar">
              {MOCK_NOTIFICATIONS.slice(0, 4).map(n => (
                <DropdownMenuItem
                  key={n.id}
                  onClick={() => navigate('notifications')}
                  className="flex items-start gap-3 p-3 cursor-pointer"
                >
                  {!n.isRead && <span className="w-2 h-2 rounded-full bg-[#FF6B35] flex-shrink-0 mt-1.5" />}
                  {n.isRead && <span className="w-2 flex-shrink-0" />}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium truncate">{n.title}</p>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{n.message}</p>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-[4px] font-medium ${notifTypeColors[n.type] || notifTypeColors['সাধারণ']}`}>
                        {n.type}
                      </span>
                      <span className="text-[10px] text-muted-foreground/60">
                        {new Date(n.createdAt).toLocaleString('bn-BD', { month: 'short', day: 'numeric' })}
                      </span>
                    </div>
                  </div>
                </DropdownMenuItem>
              ))}
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate('notifications')} className="justify-center text-[#FF6B35] cursor-pointer font-medium">
                সব নোটিফিকেশন দেখুন
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 p-1.5 rounded-[10px] hover:bg-muted transition-colors">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-[#FF6B35]/10 text-[#FF6B35] text-xs font-bold">
                    {user?.name?.slice(0, 2) || 'অ' }
                  </AvatarFallback>
                </Avatar>
                <div className="hidden md:block text-left">
                  <p className="text-sm font-medium leading-tight">{user?.name || 'অ্যাডমিন'}</p>
                  <p className="text-[11px] text-muted-foreground">{user ? ROLE_LABELS[user.role] : ''}</p>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 rounded-[12px]">
              <div className="px-3 py-2.5 border-b">
                <p className="font-medium text-sm">{user?.name}</p>
                <p className="text-xs text-muted-foreground">{user?.email}</p>
              </div>
              <DropdownMenuItem onClick={() => navigate('profile')} className="gap-2 cursor-pointer">
                <User className="h-4 w-4" /> প্রোফাইল
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('settings')} className="gap-2 cursor-pointer">
                <Settings className="h-4 w-4" /> সেটিংস
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout} className="gap-2 text-red-600 focus:text-red-600 cursor-pointer">
                <LogOut className="h-4 w-4" /> লগআউট
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
