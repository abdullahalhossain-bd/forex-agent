'use client';

import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Download, ListFilter, Table2, Printer, FileX, ChevronLeft, ChevronRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';

type LucideIcon = React.ComponentType<{ className?: string }>;

interface PageHeaderProps {
  title: string;
  description?: string;
  children?: React.ReactNode;
}

export function PageHeader({ title, description, children }: PageHeaderProps) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 animate-fade-in-up">
      <div>
        <h1 className="text-2xl font-bold text-foreground tracking-tight">{title}</h1>
        {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
      </div>
      {children && <div className="flex items-center gap-2 flex-shrink-0 flex-wrap">{children}</div>}
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const config: Record<string, string> = {
    'সক্রিয়': 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'নিষ্ক্রিয়': 'bg-gray-100 text-gray-500 border-gray-200',
    'পেন্ডিং': 'bg-amber-50 text-amber-700 border-amber-200',
    'পর্যালোচনাধীন': 'bg-sky-50 text-sky-700 border-sky-200',
    'সমাধানকৃত': 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'বাতিল': 'bg-red-50 text-red-600 border-red-200',
    'উচ্চ': 'bg-red-50 text-red-700 border-red-200',
    'মাঝারি': 'bg-amber-50 text-amber-700 border-amber-200',
    'নিম্ন': 'bg-green-50 text-green-700 border-green-200',
    'তথ্য': 'bg-sky-50 text-sky-700 border-sky-200',
    'সতর্কতা': 'bg-amber-50 text-amber-700 border-amber-200',
    'জরুরি': 'bg-red-50 text-red-700 border-red-200',
    'সাধারণ': 'bg-gray-50 text-gray-600 border-gray-200',
    'গুরুত্বপূর্ণ': 'bg-orange-50 text-[#FF6B35] border-orange-200',
    'ইভেন্ট': 'bg-teal-50 text-teal-700 border-teal-200',
    'ছুটি': 'bg-violet-50 text-violet-600 border-violet-200',
    'অন্যান্য': 'bg-gray-50 text-gray-600 border-gray-200',
  };
  return <Badge variant="outline" className={`text-xs font-medium ${config[status] || 'bg-gray-100 text-gray-600 border-gray-200'}`}>{status}</Badge>;
}

export function EmptyState({ message, icon: Icon, action }: { message: string; icon?: LucideIcon; action?: { label: string; onClick: () => void } }) {
  const DisplayIcon = Icon || FileX;
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-4 bg-[radial-gradient(circle,rgba(0,0,0,0.03)_1px,transparent_1px)] bg-[size:16px_16px]">
      <div className="p-4 rounded-full bg-muted/50">
        <DisplayIcon className="h-10 w-10 opacity-40" />
      </div>
      <p className="text-sm font-medium">{message}</p>
      {action && (
        <Button variant="outline" size="sm" onClick={action.onClick} className="rounded-[8px] mt-1">
          {action.label}
        </Button>
      )}
    </div>
  );
}

export function DataTableSkeleton({ cols = 5, rows = 5 }: { cols?: number; rows?: number }) {
  return (
    <div className="rounded-[12px] border bg-white dark:bg-card overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-muted/50">
              {Array.from({ length: cols }).map((_, i) => (
                <th key={i} className="p-3">
                  <div className="h-4 w-full animate-pulse bg-muted rounded-[8px]" />
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: rows }).map((_, i) => (
              <tr key={i}>
                {Array.from({ length: cols }).map((_, j) => (
                  <td key={j} className="p-3">
                    <div className="h-4 w-full animate-pulse bg-muted rounded-[8px]" />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

interface ConfirmDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  onConfirm: () => void;
}

export function ConfirmDialog({ open, onOpenChange, title, description, onConfirm }: ConfirmDialogProps) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="rounded-[12px]">
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          <AlertDialogDescription>{description}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>বাতিল</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm} className="bg-destructive text-white hover:bg-destructive/90">
            নিশ্চিত করুন
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

// CSV Export helper
export function exportToCSV<T extends Record<string, unknown>>(data: T[], filename: string, columns: { key: string; label: string }[]) {
  const headers = columns.map(c => c.label).join(',');
  const rows = data.map(row =>
    columns.map(c => {
      const val = row[c.key];
      const str = val != null ? String(val) : '';
      return str.includes(',') || str.includes('"') || str.includes('\n')
        ? `"${str.replace(/"/g, '""')}"`
        : str;
    }).join(',')
  );
  const csv = '\uFEFF' + [headers, ...rows].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${filename}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
  toast.success(`${filename}.csv ডাউনলোড হয়েছে`);
}

interface DataTableProps<T> {
  headers: string[];
  data: T[];
  renderRow: (item: T, idx: number) => React.ReactNode;
  emptyMessage: string;
  loading?: boolean;
  searchKeys?: string[];
  searchPlaceholder?: string;
  pageSize?: number;
  exportConfig?: { filename: string; columns: { key: string; label: string }[] };
  selectable?: boolean;
  bulkActions?: { label: string; icon?: LucideIcon; onClick: (ids: number[]) => void; variant?: 'default' | 'destructive' }[];
  getId?: (item: T) => number | string;
}

export function DataTable<T>({ headers, data, renderRow, emptyMessage, loading, searchKeys, searchPlaceholder = 'খুঁজুন...', pageSize = 10, exportConfig, selectable, bulkActions, getId }: DataTableProps<T>) {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pageSizeState, setPageSizeState] = useState(pageSize);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  useEffect(() => { setSelectedIds(new Set()); }, [page]);

  const filtered = useMemo(() => {
    if (!search || !searchKeys) return data;
    return data.filter(item =>
      searchKeys.some(key => {
        const val = (item as Record<string, unknown>)[key];
        return val != null && String(val).toLowerCase().includes(search.toLowerCase());
      })
    );
  }, [data, search, searchKeys]);

  const totalPages = Math.ceil(filtered.length / pageSizeState);
  const paged = filtered.slice((page - 1) * pageSizeState, page * pageSizeState);

  const pagedIds = selectable && getId ? paged.map(item => String(getId(item))) : [];
  const allPagedSelected = pagedIds.length > 0 && pagedIds.every(id => selectedIds.has(id));
  const somePagedSelected = pagedIds.some(id => selectedIds.has(id));
  const toggleAll = () => {
    if (allPagedSelected) {
      setSelectedIds(prev => { const next = new Set(prev); pagedIds.forEach(id => next.delete(id)); return next; });
    } else {
      setSelectedIds(prev => { const next = new Set(prev); pagedIds.forEach(id => next.add(id)); return next; });
    }
  };

  const handleExport = useCallback(() => {
    if (!exportConfig) return;
    exportToCSV(filtered as unknown as Record<string, unknown>[], exportConfig.filename, exportConfig.columns);
  }, [filtered, exportConfig]);

  return (
    <div className="space-y-4">
      {/* Search, filter bar and export */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-3">
        {searchKeys && (
          <div className="relative flex-1 max-w-sm">
            <ListFilter className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/40" />
            <Input
              placeholder={searchPlaceholder}
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); setSelectedIds(new Set()); }}
              className="rounded-[12px] pl-9"
            />
          </div>
        )}
        <div className="flex items-center gap-2 ml-auto">
          {exportConfig && (
            <Button variant="outline" size="sm" onClick={handleExport} className="rounded-[8px] gap-1.5 text-xs">
              <Download className="h-3.5 w-3.5" />
              CSV ডাউনলোড
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={() => window.print()} className="rounded-[8px] gap-1.5 text-xs" title="প্রিন্ট">
            <Printer className="h-3.5 w-3.5" />
          </Button>
          {data.length > 0 && (
            <span className="text-xs text-muted-foreground">মোট {data.length.toLocaleString('bn-BD')}</span>
          )}
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-muted-foreground">দেখান:</span>
            <Select value={String(pageSizeState)} onValueChange={v => { setPageSizeState(Number(v)); setPage(1); setSelectedIds(new Set()); }}>
              <SelectTrigger className="h-8 w-[60px] rounded-[8px] text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[5, 10, 25, 50].map(s => (
                  <SelectItem key={s} value={String(s)} className="text-xs">{s.toLocaleString('bn-BD')}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Bulk action bar */}
      {selectable && bulkActions && bulkActions.length > 0 && selectedIds.size > 0 && (
        <div className="sticky top-0 z-10 bg-[#FF6B35]/5 border border-[#FF6B35]/20 rounded-[12px] p-3 flex flex-col sm:flex-row items-center justify-between gap-2 animate-fade-in-up">
          <span className="text-sm font-medium text-[#FF6B35]">{selectedIds.size.toLocaleString('bn-BD')} টি নির্বাচিত</span>
          <div className="flex items-center gap-2">
            {bulkActions.map((action, i) => {
              const ActionIcon = action.icon;
              return (
                <Button
                  key={i}
                  size="sm"
                  variant={action.variant === 'destructive' ? 'destructive' : 'default'}
                  onClick={() => { action.onClick(Array.from(selectedIds).map(Number)); setSelectedIds(new Set()); }}
                  className="rounded-[8px] text-xs gap-1.5"
                >
                  {ActionIcon && <ActionIcon className="h-3.5 w-3.5" />}
                  {action.label}
                </Button>
              );
            })}
            <Button variant="ghost" size="sm" onClick={() => setSelectedIds(new Set())} className="rounded-[8px] text-xs text-muted-foreground">
              নির্বাচন মুছুন
            </Button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="rounded-[12px] border bg-white dark:bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50 hover:bg-muted/50">
                {selectable && (
                  <TableHead className="w-10 text-center p-2">
                    <input
                      type="checkbox"
                      className="accent-[#FF6B35] w-4 h-4 rounded cursor-pointer"
                      checked={allPagedSelected}
                      onChange={toggleAll}
                    />
                  </TableHead>
                )}
                {headers.map((h, i) => (
                  <TableHead key={i} className="font-semibold text-xs text-muted-foreground uppercase">{h}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody className="[&>tr]:hover:bg-muted/30 [&>tr]:transition-colors [&>tr]:duration-150">
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    {selectable && <TableCell className="w-10 text-center"><Skeleton className="h-4 w-4 mx-auto" /></TableCell>}
                    {headers.map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}
                  </TableRow>
                ))
              ) : paged.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={headers.length + (selectable ? 1 : 0)}>
                    <EmptyState message={emptyMessage} icon={Table2} />
                  </TableCell>
                </TableRow>
              ) : (
                paged.map((item, idx) => {
                  const rowEl = renderRow(item, idx);
                  if (selectable && getId && React.isValidElement(rowEl)) {
                    const id = String(getId(item));
                    const checked = selectedIds.has(id);
                    const checkboxCell = (
                      <TableCell className="w-10 text-center p-2">
                        <input
                          type="checkbox"
                          className="accent-[#FF6B35] w-4 h-4 rounded cursor-pointer"
                          checked={checked}
                          onChange={() => {
                            setSelectedIds(prev => {
                              const next = new Set(prev);
                              if (checked) next.delete(id); else next.add(id);
                              return next;
                            });
                          }}
                        />
                      </TableCell>
                    );
                    return React.cloneElement(
                      rowEl as React.ReactElement<{ children?: React.ReactNode }>,
                      { key: idx },
                      checkboxCell,
                      ...React.Children.toArray((rowEl as React.ReactElement<{ children?: React.ReactNode }>).props.children)
                    );
                  }
                  return <React.Fragment key={idx}>{rowEl}</React.Fragment>;
                })
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">
            মোট {filtered.length.toLocaleString('bn-BD')} টি আইটেমের মধ্যে {(((page - 1) * pageSizeState) + 1).toLocaleString('bn-BD')}-{Math.min(page * pageSizeState, filtered.length).toLocaleString('bn-BD')}
          </p>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)} className="rounded-[8px] h-8">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
              let pn: number;
              if (totalPages <= 5) pn = i + 1;
              else if (page <= 3) pn = i + 1;
              else if (page >= totalPages - 2) pn = totalPages - 4 + i;
              else pn = page - 2 + i;
              return (
                <Button key={pn} variant={pn === page ? 'default' : 'outline'} size="sm" onClick={() => setPage(pn)} className="rounded-[8px] min-w-[36px] h-8 text-xs">
                  {pn.toLocaleString('bn-BD')}
                </Button>
              );
            })}
            <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="rounded-[8px] h-8">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

interface ModuleCardProps {
  icon: LucideIcon;
  title: string;
  count: number;
  description?: string;
  color: string;
  onClick?: () => void;
}

export function ModuleCard({ icon: Icon, title, count, description, color, onClick }: ModuleCardProps) {
  return (
    <Card className="rounded-[12px] border hover:shadow-md transition-all duration-200 cursor-pointer group" onClick={onClick}>
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className={`p-2.5 rounded-[10px] ${color}`}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
        <div className="mt-4">
          <p className="text-2xl font-bold text-foreground animate-count-up">{count.toLocaleString('bn-BD')}</p>
          <p className="text-sm font-medium text-foreground mt-1">{title}</p>
          {description && <p className="text-xs text-muted-foreground mt-0.5">{description}</p>}
        </div>
      </CardContent>
    </Card>
  );
}