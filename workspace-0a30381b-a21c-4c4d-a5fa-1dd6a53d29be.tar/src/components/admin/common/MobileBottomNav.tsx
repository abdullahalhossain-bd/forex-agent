'use client';

import React, { useState } from 'react';
import {
  LayoutDashboard,
  Megaphone,
  MessageSquareWarning,
  UserCog,
  CircleUserRound,
  MoreHorizontal,
  BarChart3,
  PieChart,
  Bell,
  Activity,
  Settings,
} from 'lucide-react';
import { useNavStore, useDashboardStore } from '@/stores/admin';
import {
  Popover,
  PopoverTrigger,
  PopoverContent,
} from '@/components/ui/popover';
import { cn } from '@/lib/utils';

type LucideIcon = typeof LayoutDashboard;

interface NavItem {
  key: string;
  label: string;
  icon: LucideIcon;
  badge?: 'pendingComplaints' | 'unreadNotifications';
}

interface MoreItem {
  key: string;
  label: string;
  icon: LucideIcon;
}

const NAV_ITEMS: NavItem[] = [
  { key: 'dashboard', label: 'হোম', icon: LayoutDashboard },
  { key: 'notices', label: 'নোটিশ', icon: Megaphone, badge: 'unreadNotifications' },
  { key: 'complaints', label: 'অভিযোগ', icon: MessageSquareWarning, badge: 'pendingComplaints' },
  { key: 'users', label: 'ব্যবহারকারী', icon: UserCog },
  { key: 'profile', label: 'প্রোফাইল', icon: CircleUserRound },
];

const MORE_ITEMS: MoreItem[] = [
  { key: 'reports', label: 'রিপোর্ট', icon: BarChart3 },
  { key: 'budget', label: 'বাজেট ও উন্নয়ন', icon: PieChart },
  { key: 'notifications', label: 'নোটিফিকেশন', icon: Bell },
  { key: 'auditLog', label: 'সিস্টেম লগ', icon: Activity },
  { key: 'settings', label: 'সেটিংস', icon: Settings },
];

function Badge({ count }: { count: number }) {
  if (count <= 0) return null;
  const display = count > 99 ? '৯৯+' : count.toLocaleString('bn-BD');
  return (
    <span className="absolute -top-0.5 right-1/2 translate-x-[calc(50%+10px)] min-w-[16px] h-4 flex items-center justify-center px-1 text-[9px] font-bold leading-none text-white bg-red-500 rounded-full shadow-sm">
      {display}
    </span>
  );
}

export default function MobileBottomNav() {
  const { currentPage, navigate } = useNavStore();
  const { stats } = useDashboardStore();
  const [moreOpen, setMoreOpen] = useState(false);

  const pendingComplaints = stats?.pendingComplaints ?? 0;
  // Mock unread notification count (no real backend)
  const unreadNotifications = 5 as number;

  const getBadgeCount = (type: NavItem['badge']): number => {
    if (type === 'pendingComplaints') return pendingComplaints;
    if (type === 'unreadNotifications') return unreadNotifications;
    return 0;
  };

  const handleMoreNavigate = (key: string) => {
    navigate(key);
    setMoreOpen(false);
  };

  return (
    <nav
      className={cn(
        'fixed bottom-0 left-0 right-0 z-30 lg:hidden',
        'bg-white/80 dark:bg-[#1a1a2e]/80',
        'border-t border-border/50 dark:border-white/5',
        'backdrop-blur-xl backdrop-saturate-150',
        'shadow-[0_-1px_10px_rgba(0,0,0,0.05)] dark:shadow-[0_-1px_10px_rgba(0,0,0,0.3)]',
        'flex items-stretch'
      )}
      style={{
        paddingBottom: 'env(safe-area-inset-bottom, 0px)',
        paddingTop: 'env(safe-area-inset-top, 0px)',
      }}
    >
      {NAV_ITEMS.map((item) => {
        const isActive = currentPage === item.key;
        const Icon = item.icon;
        const badgeCount = item.badge ? getBadgeCount(item.badge) : 0;
        return (
          <button
            key={item.key}
            type="button"
            onClick={() => navigate(item.key)}
            className={cn(
              'relative flex-1 flex flex-col items-center justify-center gap-0.5 py-2 cursor-pointer',
              'transition-all duration-200 ease-out',
              'active:scale-95 transition-transform',
              isActive
                ? 'text-[#FF6B35] bg-[#FF6B35]/5'
                : 'text-muted-foreground hover:bg-muted/50 hover:text-foreground/70'
            )}
          >
            {isActive && (
              <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-[3px] rounded-b-full bg-[#FF6B35] transition-all duration-200" />
            )}
            <Badge count={badgeCount} />
            <Icon
              className={cn(
                'h-5 w-5 transition-transform duration-200',
                isActive && 'scale-110'
              )}
            />
            <span className="text-[10px] font-medium transition-colors duration-200">
              {item.label}
            </span>
          </button>
        );
      })}

      {/* আরও (More) button with Popover */}
      <Popover open={moreOpen} onOpenChange={setMoreOpen}>
        <PopoverTrigger asChild>
          <button
            type="button"
            className={cn(
              'relative flex-1 flex flex-col items-center justify-center gap-0.5 py-2 cursor-pointer',
              'transition-all duration-200 ease-out',
              'active:scale-95 transition-transform',
              'text-muted-foreground hover:bg-muted/50 hover:text-foreground/70'
            )}
          >
            <MoreHorizontal className="h-5 w-5" />
            <span className="text-[10px] font-medium">আরও</span>
          </button>
        </PopoverTrigger>
        <PopoverContent
          side="top"
          align="center"
          sideOffset={8}
          className="w-56 p-1.5 rounded-xl bg-popover dark:bg-[#1e1e36] border border-border/50 dark:border-white/10 shadow-xl"
        >
          <div className="flex flex-col gap-0.5">
            {MORE_ITEMS.map((item) => {
              const isMoreActive = currentPage === item.key;
              const ItemIcon = item.icon;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => handleMoreNavigate(item.key)}
                  className={cn(
                    'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left',
                    'transition-colors duration-150',
                    'active:scale-[0.98] transition-transform',
                    isMoreActive
                      ? 'bg-[#FF6B35]/10 text-[#FF6B35]'
                      : 'text-foreground/80 hover:bg-muted/60 hover:text-foreground'
                  )}
                >
                  <ItemIcon className={cn('h-4 w-4 shrink-0', isMoreActive && 'text-[#FF6B35]')} />
                  <span className="text-sm font-medium">{item.label}</span>
                  {isMoreActive && (
                    <span className="ml-auto w-1.5 h-1.5 rounded-full bg-[#FF6B35]" />
                  )}
                </button>
              );
            })}
          </div>
        </PopoverContent>
      </Popover>
    </nav>
  );
}
