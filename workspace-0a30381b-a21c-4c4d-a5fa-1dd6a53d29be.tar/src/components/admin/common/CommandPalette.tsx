'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  LayoutDashboard, Megaphone, UserCheck, FileText, PhoneCall,
  HeartPulse, Building2, Stethoscope, Droplets, Store, Award,
  MessageSquareWarning, PieChart, Bell, UserCog, CircleUserRound,
  Activity, Settings, Search, Command, ArrowRight
} from 'lucide-react';
import { useNavStore } from '@/stores/admin';
import { SIDEBAR_MENU, PAGE_NAMES } from '@/types/admin';

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  LayoutDashboard, Megaphone, Landmark: UserCheck, UserCheck, FileText, PhoneCall,
  HeartPulse, Building2, Stethoscope, Droplets, Store, Award,
  MessageSquareWarning, PieChart, Bell, UserCog, CircleUserRound,
  Activity, Settings,
};

interface NavItem {
  id: string;
  label: string;
  icon: string;
  group: string;
}

function getAllNavItems(): NavItem[] {
  const items: NavItem[] = [];
  for (const menu of SIDEBAR_MENU) {
    if (menu.module) {
      items.push({ id: menu.id, label: menu.label, icon: menu.icon, group: menu.label });
    }
    if (menu.children) {
      for (const child of menu.children) {
        items.push({ id: child.id, label: child.label, icon: child.icon, group: menu.label });
      }
    }
  }
  return items;
}

const ALL_ITEMS = getAllNavItems();

export default function CommandPalette() {
  const { navigate } = useNavStore();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);

  const filtered = useMemo(() => {
    if (!query.trim()) return ALL_ITEMS;
    const q = query.toLowerCase();
    return ALL_ITEMS.filter(
      item => item.label.toLowerCase().includes(q) || item.group.toLowerCase().includes(q)
    );
  }, [query]);

  const close = useCallback(() => {
    setOpen(false);
    setQuery('');
    setSelectedIndex(0);
  }, []);

  const selectItem = useCallback((item: NavItem) => {
    navigate(item.id);
    close();
  }, [navigate, close]);

  // Reset selection when filter changes using key-based reset approach
  const filteredWithIndex = useMemo(() => {
    return filtered.map((item, i) => ({ item, index: i }));
  }, [filtered]);

  const currentSelectIndex = filteredWithIndex.length > 0 ? selectedIndex % filteredWithIndex.length : 0;

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setOpen(prev => !prev);
      }
      if (e.key === 'Escape') close();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [close]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(i => (i + 1) % filtered.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(i => (i - 1 + filtered.length) % filtered.length);
    } else if (e.key === 'Enter' && filtered.length > 0) {
      selectItem(filtered[currentSelectIndex]);
    }
  };

  if (!open) return null;

  const IconComp = (name: string) => {
    const Comp = ICON_MAP[name] || LayoutDashboard;
    return <Comp className="h-4 w-4" />;
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm"
        onClick={close}
      />
      {/* Dialog */}
      <div className="fixed inset-0 z-50 flex items-start justify-center pt-[15vh] px-4">
        <div
          className="w-full max-w-lg bg-white dark:bg-[#1e1e36] rounded-[12px] shadow-2xl border dark:border-white/10 overflow-hidden animate-fade-in-up"
          onKeyDown={handleKeyDown}
        >
          {/* Search input */}
          <div className="flex items-center gap-3 px-4 border-b dark:border-white/10">
            <Search className="h-5 w-5 text-muted-foreground flex-shrink-0" />
            <input
              autoFocus
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="পেজ খুঁজুন... (Ctrl+K)"
              className="flex-1 py-3.5 bg-transparent text-sm outline-none placeholder:text-muted-foreground/50"
            />
            <kbd className="hidden sm:flex items-center gap-0.5 text-[10px] text-muted-foreground/50 bg-muted dark:bg-white/5 px-1.5 py-0.5 rounded-[4px] border dark:border-white/10">
              ESC
            </kbd>
          </div>

          {/* Results */}
          <div className="max-h-[320px] overflow-y-auto custom-scrollbar p-2">
            {filtered.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
                <Search className="h-8 w-8 mb-2 opacity-30" />
                <p className="text-sm">কোনো ফলাফল পাওয়া যায়নি</p>
              </div>
            ) : (
              <div className="space-y-0.5">
                {filtered.map((item, i) => (
                  <button
                    key={item.id}
                    onClick={() => selectItem(item)}
                    onMouseEnter={() => setSelectedIndex(i)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-[8px] text-left transition-colors ${
                      i === currentSelectIndex
                        ? 'bg-[#FF6B35]/10 text-[#FF6B35]'
                        : 'text-foreground hover:bg-muted dark:hover:bg-white/5'
                    }`}
                  >
                    <div className={`p-1.5 rounded-[6px] ${i === currentSelectIndex ? 'bg-[#FF6B35]/10' : 'bg-muted dark:bg-white/5'}`}>
                      {IconComp(item.icon)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.label}</p>
                      <p className="text-[10px] text-muted-foreground truncate">{item.group}</p>
                    </div>
                    {i === currentSelectIndex && <ArrowRight className="h-4 w-4 flex-shrink-0" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Footer hint */}
          <div className="flex items-center gap-4 px-4 py-2.5 border-t dark:border-white/10 text-[10px] text-muted-foreground/50">
            <span className="flex items-center gap-1"><kbd className="px-1 py-0.5 bg-muted dark:bg-white/5 rounded border dark:border-white/10">↑↓</kbd> নেভিগেট</span>
            <span className="flex items-center gap-1"><kbd className="px-1 py-0.5 bg-muted dark:bg-white/5 rounded border dark:border-white/10">↵</kbd> নির্বাচন</span>
            <span className="flex items-center gap-1"><kbd className="px-1 py-0.5 bg-muted dark:bg-white/5 rounded border dark:border-white/10">ESC</kbd> বন্ধ</span>
          </div>
        </div>
      </div>
    </>
  );
}