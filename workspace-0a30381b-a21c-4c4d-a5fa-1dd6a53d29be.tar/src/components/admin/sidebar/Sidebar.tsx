'use client';

import React, { useState } from 'react';
import {
  LayoutDashboard, Megaphone, Landmark, UserCheck, FileText, PhoneCall,
  HeartPulse, Building2, Stethoscope, Users, Droplets, Store, Award,
  MessageSquareWarning, Shield, PieChart, Bell, UserCog, CircleUserRound,
  ChevronDown, ChevronRight, LogOut, X, Zap, Activity, Settings, BarChart3,
  FolderTree
} from 'lucide-react';
import { useAuthStore, useNavStore } from '@/stores/admin';
import { SIDEBAR_MENU, PERMISSIONS, type MenuItem } from '@/types/admin';
import { ROLE_LABELS } from '@/types/admin';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  LayoutDashboard, Megaphone, Landmark, UserCheck, FileText, PhoneCall,
  HeartPulse, Building2, Stethoscope, Users, Droplets, Store, Award,
  MessageSquareWarning, Shield, PieChart, Bell, UserCog, CircleUserRound,
  Activity, Settings, BarChart3, FolderTree,
};

export default function Sidebar() {
  const { user, logout, hasPermission } = useAuthStore();
  const { currentPage, navigate, sidebarOpen, sidebarMobileOpen, closeMobileSidebar } = useNavStore();
  const [expandedGroups, setExpandedGroups] = useState<string[]>(['govt-services', 'health', 'community', 'admin']);

  const toggleGroup = (id: string) => {
    setExpandedGroups(prev =>
      prev.includes(id) ? prev.filter(g => g !== id) : [...prev, id]
    );
  };

  const canView = (module?: string) => {
    if (!module) return true;
    return hasPermission(module, 'view');
  };

  const renderMenuItem = (item: MenuItem) => {
    if (item.module && !canView(item.module)) return null;

    const IconComp = ICON_MAP[item.icon] || LayoutDashboard;
    const isActive = currentPage === item.id;
    const isGroup = !!item.children?.length;

    if (isGroup) {
      const visibleChildren = item.children?.filter(c => !c.module || canView(c.module)) || [];
      if (visibleChildren.length === 0) return null;
      const isExpanded = expandedGroups.includes(item.id);
      const hasActiveChild = visibleChildren.some(c => currentPage === c.id);

      const btn = (
        <button
          onClick={() => sidebarOpen ? toggleGroup(item.id) : navigate(visibleChildren[0].id)}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-[10px] text-sm transition-all duration-150 group/item ${hasActiveChild ? 'text-white bg-white/5' : isActive ? 'text-white bg-white/10' : 'text-sidebar-foreground/70 hover:text-white hover:bg-white/5'}`}
        >
          <IconComp className={`h-5 w-5 flex-shrink-0 ${isActive ? 'text-[#FF6B35]' : 'text-sidebar-foreground/50 group-hover/item:text-[#FF6B35]'}`} />
          {sidebarOpen && (
            <>
              <span className="flex-1 text-left font-medium">{item.label}</span>
              {isExpanded ? <ChevronDown className="h-4 w-4 opacity-50" /> : <ChevronRight className="h-4 w-4 opacity-50" />}
            </>
          )}
        </button>
      );

      if (!sidebarOpen) {
        return (
          <TooltipProvider key={item.id} delayDuration={0}>
            <Tooltip>
              <TooltipTrigger asChild>{btn}</TooltipTrigger>
              <TooltipContent side="right" className="font-bn">{item.label}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        );
      }

      const childItems = visibleChildren.map((child, idx) => {
        const ChildIcon = ICON_MAP[child.icon] || LayoutDashboard;
        const childActive = currentPage === child.id;
        return (
          <div key={`${item.id}-child-${child.id}`} className="relative">
            {childActive && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 rounded-r-full bg-[#FF6B35]" />}
            <button
              onClick={() => navigate(child.id)}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-[8px] text-[13px] transition-all ${childActive ? 'text-[#FF6B35] bg-[#FF6B35]/10 font-medium' : 'text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-white/5'}`}
            >
              <ChildIcon className="h-4 w-4 flex-shrink-0" />
              <span>{child.label}</span>
            </button>
          </div>
        );
      });

      return (
        <div key={item.id}>
          {btn}
          {isExpanded && sidebarOpen && visibleChildren.length > 0 && (
            <div className="ml-5 mt-1 space-y-0.5 border-l border-white/10 pl-3">
              {childItems}
            </div>
          )}
        </div>
      );
    }

    const plainBtn = (
      <div className="relative">
        {isActive && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 rounded-r-full bg-[#FF6B35]" />}
        <button
          onClick={() => navigate(item.id)}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-[10px] text-sm transition-all duration-150 group/item ${isActive ? 'text-white bg-white/10' : 'text-sidebar-foreground/70 hover:text-white hover:bg-white/5'}`}
        >
          <IconComp className={`h-5 w-5 flex-shrink-0 ${isActive ? 'text-[#FF6B35]' : 'text-sidebar-foreground/50 group-hover/item:text-[#FF6B35]'}`} />
          {sidebarOpen && <span className={`flex-1 text-left ${isActive ? 'font-semibold' : 'font-medium'}`}>{item.label}</span>}
        </button>
      </div>
    );

    if (!sidebarOpen) {
      return (
        <TooltipProvider key={item.id} delayDuration={0}>
          <Tooltip>
            <TooltipTrigger asChild>{plainBtn}</TooltipTrigger>
            <TooltipContent side="right" className="font-bn">{item.label}</TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
    }

    return <React.Fragment key={item.id}>{plainBtn}</React.Fragment>;
  };

  return (
    <>
      {/* Mobile overlay */}
      {sidebarMobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={closeMobileSidebar} />
          <div className="absolute left-0 top-0 bottom-0 w-[280px] bg-[#1a1a2e] animate-in slide-in-from-left duration-300">
            <SidebarContent />
          </div>
        </div>
      )}
      {/* Desktop sidebar */}
      <aside className={`hidden lg:flex flex-col fixed left-0 top-0 bottom-0 z-30 bg-[#1a1a2e] border-r border-sidebar-border transition-all duration-300 ${sidebarOpen ? 'w-[260px]' : 'w-[72px]'}`}>
        <SidebarContent />
      </aside>
    </>
  );

  function SidebarContent() {
    return (
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 h-16 border-b border-white/5">
          <div className="w-9 h-9 rounded-[10px] bg-[#FF6B35] flex items-center justify-center flex-shrink-0">
            <Zap className="h-5 w-5 text-white" />
          </div>
          {sidebarOpen && (
            <div className="min-w-0">
              <h1 className="text-sm font-bold text-white leading-tight truncate">বেতাগী ই-সেবা</h1>
              <p className="text-[10px] text-sidebar-foreground/50">অ্যাডমিন পোর্টাল</p>
            </div>
          )}
          {sidebarMobileOpen && (
            <button onClick={closeMobileSidebar} className="ml-auto text-sidebar-foreground/50 hover:text-white lg:hidden">
              <X className="h-5 w-5" />
            </button>
          )}
        </div>

        {/* Nav items */}
        <ScrollArea className="flex-1 sidebar-scroll py-3 px-3">
          <div className="space-y-1">
            {SIDEBAR_MENU.map(item => renderMenuItem(item))}
          </div>
        </ScrollArea>

        {/* User section */}
        {user && (
          sidebarOpen ? (
            <>
              <Separator className="bg-white/5" />
              <div className="p-3">
                <div className="flex items-center gap-3 p-2 rounded-[10px]">
                  <Avatar className="h-9 w-9">
                    <AvatarFallback className="bg-[#FF6B35]/20 text-[#FF6B35] text-xs font-bold">
                      {user.name.slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{user.name}</p>
                    <p className="text-[11px] text-sidebar-foreground/50">{ROLE_LABELS[user.role]}</p>
                  </div>
                  <button onClick={logout} className="p-1.5 rounded-[8px] text-sidebar-foreground/40 hover:text-red-400 hover:bg-red-400/10 transition-colors" title="লগআউট">
                    <LogOut className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="p-2 flex justify-center">
              <TooltipProvider delayDuration={0}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button onClick={() => navigate('profile')} className="relative">
                      <Avatar className="h-9 w-9 ring-2 ring-[#FF6B35]/30">
                        <AvatarFallback className="bg-[#FF6B35]/20 text-[#FF6B35] text-xs font-bold">
                          {user.name.slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right">{user.name}</TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          )
        )}
      </div>
    );
  }
}
