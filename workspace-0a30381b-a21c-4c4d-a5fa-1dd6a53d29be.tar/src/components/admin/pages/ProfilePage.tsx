'use client';

import React, { useState, useMemo } from 'react';
import {
  Save,
  Lock,
  User,
  Camera,
  LogIn,
  Clock,
  Globe,
  Monitor,
  Smartphone,
  Tablet,
  UserCog,
  FileText,
  Shield,
  Download,
  Upload,
  Settings,
  AlertTriangle,
  Trash2,
  Eye,
  EyeOff,
  LogOut,
} from 'lucide-react';
import { useAuthStore } from '@/stores/admin';
import { ROLE_LABELS } from '@/types/admin';
import { PageHeader } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';

// --- Helper: today's date in Bengali ---
function todayBnBD(): string {
  return new Date().toLocaleDateString('bn-BD', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

// --- Password strength logic ---
function getStrength(password: string): { score: number; label: string; color: string; barColor: string } {
  if (!password) return { score: 0, label: '', color: '', barColor: '' };
  let score = 0;
  if (password.length >= 6) score++;
  if (password.length >= 10) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  if (score <= 2) return { score: 33, label: 'দুর্বল', color: 'text-red-600', barColor: '[&>div]:bg-red-500' };
  if (score <= 3) return { score: 66, label: 'মাঝারি', color: 'text-amber-600', barColor: '[&>div]:bg-amber-500' };
  return { score: 100, label: 'শক্তিশালী', color: 'text-emerald-600', barColor: '[&>div]:bg-emerald-500' };
}

// --- Hardcoded activity log entries ---
const ACTIVITY_LOG = [
  { icon: UserCog, label: 'ব্যবহারকারীর ভূমিকা আপডেট করা হয়েছে', time: '২ ঘণ্টা আগে', color: 'text-[#FF6B35] bg-orange-50' },
  { icon: FileText, label: 'নতুন সেবা আইটেম যোগ করা হয়েছে', time: '৫ ঘণ্টা আগে', color: 'text-[#1eb1b1] bg-teal-50' },
  { icon: Shield, label: 'পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে', time: '১ দিন আগে', color: 'text-emerald-600 bg-emerald-50' },
  { icon: Download, label: 'বাজেট রিপোর্ট ডাউনলোড করা হয়েছে', time: '২ দিন আগে', color: 'text-sky-600 bg-sky-50' },
  { icon: Upload, label: 'প্রোফাইল ছবি আপলোড করা হয়েছে', time: '৩ দিন আগে', color: 'text-violet-600 bg-violet-50' },
  { icon: Settings, label: 'সিস্টেম সেটিংস আপডেট করা হয়েছে', time: '৫ দিন আগে', color: 'text-gray-600 bg-gray-50' },
];

// --- Hardcoded active sessions ---
const ACTIVE_SESSIONS = [
  { id: 1, device: 'ল্যাপটপ', icon: Monitor, browser: 'Chrome ১২৫', ip: '১৯২.১৬৮.১.১০০', current: true, lastActive: 'বর্তমানে সক্রিয়' },
  { id: 2, device: 'মোবাইল', icon: Smartphone, browser: 'Safari ১৭', ip: '১০.০.০.৫২', current: false, lastActive: '৩০ মিনিট আগে' },
  { id: 3, device: 'ট্যাবলেট', icon: Tablet, browser: 'Firefox ১২৬', ip: '১৭২.১৬.০.২৫', current: false, lastActive: '২ ঘণ্টা আগে' },
];

export default function ProfilePage() {
  const { user, updateProfile, hasPermission } = useAuthStore();
  const canEdit = hasPermission('profile', 'edit');

  const [form, setForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    union: user?.union || '',
  });
  const [passForm, setPassForm] = useState({ current: '', newPass: '', confirm: '' });
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [sessions, setSessions] = useState(ACTIVE_SESSIONS);

  const strength = useMemo(() => getStrength(passForm.newPass), [passForm.newPass]);

  const handleSave = () => {
    if (!form.name) {
      toast.error('নাম দিন');
      return;
    }
    updateProfile(form);
    toast.success('প্রোফাইল আপডেট হয়েছে');
  };

  const handlePassChange = () => {
    if (!passForm.current || !passForm.newPass || !passForm.confirm) {
      toast.error('সকল ক্ষেত্র পূরণ করুন');
      return;
    }
    if (passForm.newPass !== passForm.confirm) {
      toast.error('নতুন পাসওয়ার্ড মিলছে না');
      return;
    }
    if (passForm.newPass.length < 6) {
      toast.error('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে');
      return;
    }
    toast.success('পাসওয়ার্ড পরিবর্তন হয়েছে');
    setPassForm({ current: '', newPass: '', confirm: '' });
  };

  const handleAvatarUpload = () => {
    toast.info('ছবি আপলোড ফিচার শীঘ্রই আসছে');
  };

  const handleEndSession = (id: number, device: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== id));
    toast.success(`${device} সেশন বন্ধ করা হয়েছে`);
  };

  const handleDeleteAccount = () => {
    toast.error('অ্যাকাউন্ট মুছে ফেলার অনুরোধ পাঠানো হয়েছে');
  };

  if (!user) return null;

  return (
    <div className="animate-fade-in-up max-w-4xl space-y-6">
      <PageHeader title="প্রোফাইল" description="আপনার অ্যাকাউন্টের তথ্য দেখুন ও আপডেট করুন" />

      {/* ========== 1. PROFILE HEADER CARD ========== */}
      <Card className="rounded-[12px] border overflow-hidden">
        {/* 3px orange gradient top accent line */}
        <div className="h-[3px] bg-gradient-to-r from-[#FF6B35] via-orange-400 to-[#FF6B35]" />
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-center gap-5">
            {/* Avatar with camera overlay */}
            <div className="relative group">
              <Avatar className="h-24 w-24 ring-4 ring-[#FF6B35]/10">
                <AvatarFallback className="bg-[#FF6B35]/10 text-[#FF6B35] text-3xl font-bold">
                  {user.name.slice(0, 2)}
                </AvatarFallback>
              </Avatar>
              <button
                onClick={handleAvatarUpload}
                className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200 cursor-pointer"
                aria-label="প্রোফাইল ছবি আপলোড করুন"
              >
                <Camera className="h-6 w-6 text-white" />
              </button>
            </div>
            {/* Name, role, email, phone, status */}
            <div className="text-center sm:text-left flex-1">
              <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
                <h2 className="text-xl font-bold text-foreground">{user.name}</h2>
                <Badge variant="outline" className="w-fit mx-auto sm:mx-0 text-xs font-medium bg-orange-50 text-[#FF6B35] border-orange-200">
                  {ROLE_LABELS[user.role]}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mt-1.5">{user.email}</p>
              <p className="text-sm text-muted-foreground">{user.phone}</p>
              <div className="flex items-center gap-2 mt-2.5 justify-center sm:justify-start">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
                </span>
                <span className="text-xs font-medium text-emerald-600">সক্রিয়</span>
                <span className="text-xs text-muted-foreground">·</span>
                <span className="text-xs text-muted-foreground">যোগদান: {user.createdAt}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ========== 2. STATS ROW ========== */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Login count */}
        <Card className="rounded-[12px] border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2.5 rounded-[10px] bg-orange-50">
              <LogIn className="h-5 w-5 text-[#FF6B35]" />
            </div>
            <div>
              <p className="text-lg font-bold text-foreground">১২৮</p>
              <p className="text-xs text-muted-foreground">লগইন</p>
            </div>
          </CardContent>
        </Card>
        {/* Last login */}
        <Card className="rounded-[12px] border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2.5 rounded-[10px] bg-emerald-50">
              <Clock className="h-5 w-5 text-emerald-600" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-foreground truncate">{todayBnBD()}</p>
              <p className="text-xs text-muted-foreground">শেষ লগইন</p>
            </div>
          </CardContent>
        </Card>
        {/* Session duration */}
        <Card className="rounded-[12px] border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2.5 rounded-[10px] bg-sky-50">
              <Clock className="h-5 w-5 text-sky-600" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">২ ঘণ্টা ৩৫ মিনিট</p>
              <p className="text-xs text-muted-foreground">সেশন</p>
            </div>
          </CardContent>
        </Card>
        {/* IP */}
        <Card className="rounded-[12px] border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2.5 rounded-[10px] bg-violet-50">
              <Globe className="h-5 w-5 text-violet-600" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">১৯২.১৬৮.১.১০০</p>
              <p className="text-xs text-muted-foreground">আইপি</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ========== 3. ACTIVITY LOG CARD ========== */}
      <Card className="rounded-[12px] border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <UserCog className="h-4 w-4 text-[#FF6B35]" />
            সাম্প্রতিক কার্যকলাপ
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 pb-1">
          <div className="max-h-96 overflow-y-auto">
            {ACTIVITY_LOG.map((item, idx) => {
              const Icon = item.icon;
              return (
                <React.Fragment key={idx}>
                  <div className="flex items-start gap-3 px-6 py-3 hover:bg-muted/30 transition-colors">
                    <div className={`p-2 rounded-[10px] shrink-0 mt-0.5 ${item.color}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-foreground">{item.label}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{item.time}</p>
                    </div>
                  </div>
                  {idx < ACTIVITY_LOG.length - 1 && <Separator className="mx-6" />}
                </React.Fragment>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* ========== 4. ACTIVE SESSIONS CARD ========== */}
      <Card className="rounded-[12px] border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Monitor className="h-4 w-4 text-[#FF6B35]" />
            সক্রিয় সেশন
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {sessions.map((session) => {
            const Icon = session.icon;
            return (
              <div
                key={session.id}
                className="flex flex-col sm:flex-row sm:items-center gap-3 p-3 rounded-[12px] border bg-muted/20 hover:bg-muted/40 transition-colors"
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <div className="p-2 rounded-[10px] bg-white border shrink-0">
                    <Icon className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-foreground">{session.device}</p>
                      {session.current && (
                        <Badge className="text-[10px] px-1.5 py-0 bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-50">
                          বর্তমান
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {session.browser} · {session.ip} · {session.lastActive}
                    </p>
                  </div>
                </div>
                {!session.current && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEndSession(session.id, session.device)}
                    className="rounded-[12px] text-xs text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700 shrink-0 self-end sm:self-center"
                  >
                    <LogOut className="h-3.5 w-3.5 mr-1" />
                    সেশন বন্ধ করুন
                  </Button>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>

      <Separator />

      {/* ========== 5. EDIT FORM ========== */}
      <Card className="rounded-[12px] border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <User className="h-4 w-4 text-[#FF6B35]" />
            ব্যক্তিগত তথ্য সম্পাদনা
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="profile-name" className="text-xs font-medium">
                নাম <span className="text-red-500">*</span>
              </Label>
              <Input
                id="profile-name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                disabled={!canEdit}
                className="rounded-[12px]"
                placeholder="আপনার পূর্ণ নাম"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="profile-email" className="text-xs font-medium">
                ইমেইল
              </Label>
              <Input
                id="profile-email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                disabled={!canEdit}
                className="rounded-[12px]"
                placeholder="example@email.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="profile-phone" className="text-xs font-medium">
                ফোন
              </Label>
              <Input
                id="profile-phone"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                disabled={!canEdit}
                className="rounded-[12px]"
                placeholder="০১XXXXXXXXX"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="profile-union" className="text-xs font-medium">
                ইউনিয়ন
              </Label>
              <Input
                id="profile-union"
                value={form.union}
                onChange={(e) => setForm({ ...form, union: e.target.value })}
                disabled={!canEdit}
                className="rounded-[12px]"
                placeholder="ইউনিয়নের নাম"
              />
            </div>
          </div>
          {canEdit && (
            <Button
              onClick={handleSave}
              className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white"
            >
              <Save className="h-4 w-4 mr-1.5" />
              আপডেট করুন
            </Button>
          )}
        </CardContent>
      </Card>

      {/* ========== 6. PASSWORD CHANGE ========== */}
      <Card className="rounded-[12px] border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Lock className="h-4 w-4 text-[#FF6B35]" />
            পাসওয়ার্ড পরিবর্তন
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Current password */}
          <div className="space-y-2">
            <Label htmlFor="pass-current" className="text-xs font-medium">
              বর্তমান পাসওয়ার্ড
            </Label>
            <div className="relative">
              <Input
                id="pass-current"
                type={showCurrent ? 'text' : 'password'}
                value={passForm.current}
                onChange={(e) => setPassForm({ ...passForm, current: e.target.value })}
                placeholder="বর্তমান পাসওয়ার্ড"
                className="rounded-[12px] pr-10"
              />
              <button
                type="button"
                onClick={() => setShowCurrent(!showCurrent)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                aria-label={showCurrent ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখান'}
              >
                {showCurrent ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
          {/* New password */}
          <div className="space-y-2">
            <Label htmlFor="pass-new" className="text-xs font-medium">
              নতুন পাসওয়ার্ড
            </Label>
            <div className="relative">
              <Input
                id="pass-new"
                type={showNew ? 'text' : 'password'}
                value={passForm.newPass}
                onChange={(e) => setPassForm({ ...passForm, newPass: e.target.value })}
                placeholder="নতুন পাসওয়ার্ড"
                className="rounded-[12px] pr-10"
              />
              <button
                type="button"
                onClick={() => setShowNew(!showNew)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                aria-label={showNew ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখান'}
              >
                {showNew ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            {/* Strength indicator */}
            {passForm.newPass && (
              <div className="space-y-1.5 mt-2">
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-medium ${strength.color}`}>{strength.label}</span>
                  <span className="text-xs text-muted-foreground">
                    {passForm.newPass.length}/২০
                  </span>
                </div>
                <Progress value={strength.score} className={`h-2 rounded-full ${strength.barColor}`} />
              </div>
            )}
          </div>
          {/* Confirm password */}
          <div className="space-y-2">
            <Label htmlFor="pass-confirm" className="text-xs font-medium">
              নতুন পাসওয়ার্ড নিশ্চিত করুন
            </Label>
            <div className="relative">
              <Input
                id="pass-confirm"
                type={showConfirm ? 'text' : 'password'}
                value={passForm.confirm}
                onChange={(e) => setPassForm({ ...passForm, confirm: e.target.value })}
                placeholder="পুনরায় লিখুন"
                className="rounded-[12px] pr-10"
              />
              <button
                type="button"
                onClick={() => setShowConfirm(!showConfirm)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                aria-label={showConfirm ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখান'}
              >
                {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
          <Button
            onClick={handlePassChange}
            className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white"
          >
            <Lock className="h-4 w-4 mr-1.5" />
            পাসওয়ার্ড পরিবর্তন করুন
          </Button>
        </CardContent>
      </Card>

      {/* ========== 7. DANGER ZONE ========== */}
      <Card className="rounded-[12px] border-l-4 border-l-red-500">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2 text-red-600">
            <AlertTriangle className="h-4 w-4" />
            বিপজ্জনক অঞ্চল
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            এই অ্যাকাউন্টটি মুছে ফেললে সকল তথ্য স্থায়ীভাবে মুছে যাবে এবং পুনরুদ্ধার করা সম্ভব হবে না।
          </p>
          <Button
            variant="outline"
            onClick={handleDeleteAccount}
            className="rounded-[12px] text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700 hover:border-red-300"
          >
            <Trash2 className="h-4 w-4 mr-1.5" />
            অ্যাকাউন্ট মুছুন
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
