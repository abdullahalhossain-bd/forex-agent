'use client';

import React, { useState } from 'react';
import { UserCog, Shield, Trash2 } from 'lucide-react';
import { MOCK_USERS } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { ROLE_LABELS, type UserRole } from '@/types/admin';
import { PageHeader, DataTable, StatusBadge, ConfirmDialog } from '@/components/admin/common/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

export default function UsersPage() {
  const { user: currentUser, hasPermission } = useAuthStore();
  const canDelete = hasPermission('users', 'delete');

  const roleColors: Record<UserRole, string> = {
    admin: 'bg-orange-50 text-orange-700 border-orange-200',
    uno: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    ict: 'bg-blue-50 text-blue-700 border-blue-200',
    developer: 'bg-purple-50 text-purple-700 border-purple-200',
  };

  const roleIcons: Record<UserRole, string> = {
    admin: 'bg-orange-100 text-orange-600',
    uno: 'bg-emerald-100 text-emerald-600',
    ict: 'bg-blue-100 text-blue-600',
    developer: 'bg-purple-100 text-purple-600',
  };

  const stats = {
    total: MOCK_USERS.length,
    admin: MOCK_USERS.filter(u => u.role === 'admin').length,
    uno: MOCK_USERS.filter(u => u.role === 'uno').length,
    ict: MOCK_USERS.filter(u => u.role === 'ict').length,
    developer: MOCK_USERS.filter(u => u.role === 'developer').length,
  };

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="ব্যবহারকারী" description="সিস্টেমের সকল ব্যবহারকারীর তালিকা" />

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        {Object.entries(stats).filter(([k]) => k !== 'total').map(([role, count]) => (
          <Card key={role} className="rounded-[12px] border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-10 h-10 rounded-[10px] flex items-center justify-center ${roleIcons[role as UserRole] || ''}`}>
                <Shield className="h-5 w-5" />
              </div>
              <div>
                <p className="text-lg font-bold">{count}</p>
                <p className="text-xs text-muted-foreground">{ROLE_LABELS[role as UserRole]}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <DataTable
        headers={['#', 'ব্যবহারকারী', 'ইমেইল', 'ফোন', 'ভূমিকা', 'ইউনিয়ন', 'যোগদানের তারিখ']}
        data={MOCK_USERS}
        searchKeys={['name', 'email', 'role']}
        searchPlaceholder="ব্যবহারকারী খুঁজুন..."
        emptyMessage="কোনো ব্যবহারকারী পাওয়া যায়নি"
        exportConfig={{
          filename: 'ব্যবহারকারী',
          columns: [
            { key: 'id', label: 'ক্রমিক' },
            { key: 'name', label: 'নাম' },
            { key: 'email', label: 'ইমেইল' },
            { key: 'role', label: 'ভূমিকা' },
          ],
        }}
        renderRow={(item: typeof MOCK_USERS[0]) => (
          <tr key={item.id} className="hover:bg-muted/50 transition-colors">
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.id}</td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-2.5">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className={`text-xs font-bold ${roleIcons[item.role]}`}>{item.name.slice(0, 2)}</AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium">{item.name}</span>
              </div>
            </td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.email}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.phone}</td>
            <td className="px-4 py-3"><Badge variant="outline" className={`text-xs ${roleColors[item.role]}`}>{ROLE_LABELS[item.role]}</Badge></td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.union || '-'}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.createdAt}</td>
          </tr>
        )}
      />
    </div>
  );
}