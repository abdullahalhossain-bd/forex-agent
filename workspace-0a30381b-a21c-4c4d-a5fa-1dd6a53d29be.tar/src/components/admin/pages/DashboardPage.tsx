'use client';

import React, { useState, useEffect } from 'react';
import {
  Users, UserCheck, UserCog, Building2, Stethoscope, Droplets, Store,
  MessageSquareWarning, Megaphone, PieChart, AlertTriangle, CheckCircle2,
  PlusCircle, PhoneCall, Send, Clock, Activity, ArrowUpRight, FileText, Zap, LandPlot, Monitor, Code, Info, Settings, Bell
} from 'lucide-react';
import { MOCK_DASHBOARD_STATS, MOCK_COMPLAINTS, MOCK_NOTICES, MOCK_BUDGET } from '@/lib/mock-data';
import { useAuthStore, useNavStore } from '@/stores/admin';
import { StatusBadge } from '@/components/admin/common/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ROLE_LABELS, type UserRole } from '@/types/admin';

// Role-specific welcome data
interface WelcomeQuickStat { label: string; value: string; color: string }
interface WelcomeAction { label: string; page: string; icon: string }
interface WelcomeInfo {
  greeting: string;
  sub: string;
  message: string;
  iconBg: string;
  iconColor: string;
  tip: string;
  tipIcon: string;
  quickStats: WelcomeQuickStat[];
  quickActions: WelcomeAction[];
}

const WELCOME_DATA: Record<Exclude<UserRole, 'admin'>, WelcomeInfo> = {
  uno: {
    greeting: 'জনসেবায় আপনার অবদান অপরিসীম',
    sub: 'বেতাগী উপজেলা নির্বাহী অফিসার',
    message: 'আপনার নেতৃত্বে বেতাগী উপজেলার সার্বিক উন্নয়ন ও জনসেবা নিশ্চিত হোক। নোটিশ প্রকাশ, অভিযোগ তত্ত্বাবধান এবং সেবা ব্যবস্থাপনার জন্য ড্যাশবোর্ড ব্যবহার করুন।',
    iconBg: 'bg-emerald-50 dark:bg-emerald-500/10',
    iconColor: 'text-emerald-600 dark:text-emerald-400',
    tip: 'আজকে ৫টি নতুন অভিযোগ এবং ২টি নোটিশ প্রকাশের অপেক্ষমান রয়েছে',
    tipIcon: 'messageSquareWarning',
    quickStats: [
      { label: 'মোট অভিযোগ', value: '৫৪', color: 'text-rose-600 dark:text-rose-400' },
      { label: 'পেন্ডিং', value: '১২', color: 'text-amber-600 dark:text-amber-400' },
      { label: 'সক্রিয় নোটিশ', value: '৮', color: 'text-emerald-600 dark:text-emerald-400' },
      { label: 'সেবা আইটেম', value: '২৩', color: 'text-[#FF6B35]' },
    ],
    quickActions: [
      { label: 'নোটিশ প্রকাশ', page: 'notices', icon: 'Megaphone' },
      { label: 'অভিযোগ দেখুন', page: 'complaints', icon: 'MessageSquareWarning' },
      { label: 'সেবা তালিকা', page: 'serviceItems', icon: 'FileText' },
      { label: 'কর্মকর্তা', page: 'officers', icon: 'UserCheck' },
    ],
  },
  ict: {
    greeting: 'প্রযুক্তি দিয়ে জনসেবা এগিয়ে যাক',
    sub: 'আইসিটি অফিসার, বেতাগী উপজেলা',
    message: 'ই-সেবা প্ল্যাটফর্মের কন্টেন্ট আপডেট, নোটিশ ব্যবস্থাপনা এবং ডেটা রক্ষণাবেক্ষণ করুন। ডিজিটাল বাংলাদেশ গড়ার অঙ্গীকারে আপনার ভূমিকা অপরিহার্য।',
    iconBg: 'bg-sky-50 dark:bg-sky-500/10',
    iconColor: 'text-sky-600 dark:text-sky-400',
    tip: '৩টি নোটিশ আপডেট এবং ১টি সিস্টেম নোটিফিকেশন রয়েছে',
    tipIcon: 'monitor',
    quickStats: [
      { label: 'মোট নোটিশ', value: '৮', color: 'text-[#FF6B35]' },
      { label: 'নোটিফিকেশন', value: '৩', color: 'text-sky-600 dark:text-sky-400' },
      { label: 'কর্মকর্তা', value: '১৫', color: 'text-emerald-600 dark:text-emerald-400' },
      { label: 'জরুরি নম্বর', value: '১৮', color: 'text-amber-600 dark:text-amber-400' },
    ],
    quickActions: [
      { label: 'নোটিশ বোর্ড', page: 'notices', icon: 'Megaphone' },
      { label: 'কর্মকর্তা পরিচালনা', page: 'officers', icon: 'UserCheck' },
      { label: 'নোটিফিকেশন', page: 'notifications', icon: 'Bell' },
      { label: 'জরুরি নম্বর', page: 'emergency', icon: 'PhoneCall' },
    ],
  },
  acLand: {
    greeting: 'ভূমি সেবায় স্বচ্ছতা ও জবাবদিহিতা নিশ্চিত করুন',
    sub: 'সহকারী কমিশনার (ভূমি), বেতাগী',
    message: 'ভূমি সংক্রান্ত সেবা প্রদান, অভিযোগ নিষ্পত্তি এবং নাগরিকদের ভূমি অধিকার রক্ষায় আপনার ভূমিকা গুরুত্বপূর্ণ। ডিজিটাল ভূমি ব্যবস্থাপনায় এগিয়ে যান।',
    iconBg: 'bg-amber-50 dark:bg-amber-500/10',
    iconColor: 'text-amber-600 dark:text-amber-400',
    tip: '৩টি পেন্ডিং অভিযোগ এবং ২টি নতুন সেবা আবেদন রয়েছে',
    tipIcon: 'landPlot',
    quickStats: [
      { label: 'মোট অভিযোগ', value: '৫৪', color: 'text-rose-600 dark:text-rose-400' },
      { label: 'পেন্ডিং', value: '১২', color: 'text-amber-600 dark:text-amber-400' },
      { label: 'সেবা আইটেম', value: '২৩', color: 'text-[#FF6B35]' },
      { label: 'সমাধানকৃত', value: '৪২', color: 'text-emerald-600 dark:text-emerald-400' },
    ],
    quickActions: [
      { label: 'অভিযোগ ব্যবস্থাপনা', page: 'complaints', icon: 'MessageSquareWarning' },
      { label: 'সেবা আইটেম', page: 'serviceItems', icon: 'FileText' },
      { label: 'নোটিশ প্রকাশ', page: 'notices', icon: 'Megaphone' },
      { label: 'জরুরি নম্বর', page: 'emergency', icon: 'PhoneCall' },
    ],
  },
  developer: {
    greeting: 'কোড দিয়ে গড়ে তুলুন স্মার্ট বেতাগী',
    sub: 'সিস্টেম ডেভেলপার, ই-সেবা প্ল্যাটফর্ম',
    message: 'বেতাগী ই-সেবা প্ল্যাটফর্মের ডেটা ব্যবস্থাপনা, সিস্টেম রক্ষণাবেক্ষণ ও উন্নয়ন কাজ চালিয়ে যান। আপনার প্রচেষ্টায় ডিজিটাল সেবা আরও শক্তিশালী হচ্ছে।',
    iconBg: 'bg-violet-50 dark:bg-violet-500/10',
    iconColor: 'text-violet-600 dark:text-violet-400',
    tip: 'সিস্টেম স্থিতিশীল — সকল সেবা সচল আছে, আপটাইম ৯৯.৮%',
    tipIcon: 'code',
    quickStats: [
      { label: 'মোডিউল', value: '১৪', color: 'text-violet-600 dark:text-violet-400' },
      { label: 'API কল', value: '১.২K', color: 'text-sky-600 dark:text-sky-400' },
      { label: 'সক্রিয় ব্যবহারকারী', value: '৮', color: 'text-emerald-600 dark:text-emerald-400' },
      { label: 'সিস্টেম আপটাইম', value: '৯৯.৮%', color: 'text-[#FF6B35]' },
    ],
    quickActions: [
      { label: 'সিস্টেম লগ', page: 'auditLog', icon: 'Activity' },
      { label: 'সেটিংস', page: 'settings', icon: 'Settings' },
      { label: 'ব্যবহারকারী', page: 'users', icon: 'UserCog' },
      { label: 'নোটিশ ব্যবস্থাপনা', page: 'notices', icon: 'Megaphone' },
    ],
  },
};

const COMPLAINT_BY_UNION = [
  { union: 'বেতাগী সদর', count: 18, color: '#FF6B35' },
  { union: 'চরবাড়ি', count: 12, color: '#1eb1b1' },
  { union: 'পাতারহাট', count: 9, color: '#E5A100' },
  { union: 'হলদিয়া', count: 7, color: '#8B5CF6' },
  { union: 'কালিগঞ্জ', count: 5, color: '#EC4899' },
  { union: 'সন্তোষপুর', count: 3, color: '#10B981' },
];

const RECENT_ACTIVITIES = [
  { id: 1, icon: MessageSquareWarning, color: 'text-rose-500 bg-rose-50', text: 'নতুন অভিযোগ জমা হয়েছে - পানি নিষ্কাশন', time: '৫ মিনিট আগে', dot: 'bg-rose-500' },
  { id: 2, icon: CheckCircle2, color: 'text-emerald-500 bg-emerald-50', text: 'অভিযোগ সমাধান করা হয়েছে - স্কুল ভবন', time: '৩০ মিনিট আগে', dot: 'bg-emerald-500' },
  { id: 3, icon: Megaphone, color: 'text-[#FF6B35] bg-orange-50', text: 'নোটিশ প্রকাশিত - ডেঙ্গু প্রতিরোধ', time: '১ ঘণ্টা আগে', dot: 'bg-[#FF6B35]' },
  { id: 4, icon: Users, color: 'text-teal-500 bg-teal-50', text: 'নতুন রক্তদাতা নিবন্ধন - মোঃ ইমরান', time: '২ ঘণ্টা আগে', dot: 'bg-teal-500' },
  { id: 5, icon: FileText, color: 'text-amber-500 bg-amber-50', text: 'সেবা আইটেম আপডেট - ট্রেড লাইসেন্স', time: '৩ ঘণ্টা আগে', dot: 'bg-amber-500' },
];

const QUICK_ACTIONS = [
  { id: 1, label: 'নতুন নোটিশ', icon: Megaphone, page: 'notices' as const, color: 'bg-orange-50 text-[#FF6B35] hover:bg-orange-100', border: 'border-orange-100' },
  { id: 2, label: 'নতুন অভিযোগ', icon: MessageSquareWarning, page: 'complaints' as const, color: 'bg-rose-50 text-rose-500 hover:bg-rose-100', border: 'border-rose-100' },
  { id: 3, label: 'রক্তদাতা খুঁজুন', icon: Droplets, page: 'donors' as const, color: 'bg-red-50 text-red-500 hover:bg-red-100', border: 'border-red-100' },
  { id: 4, label: 'জরুরি নম্বর', icon: PhoneCall, page: 'emergency' as const, color: 'bg-amber-50 text-amber-600 hover:bg-amber-100', border: 'border-amber-100' },
  { id: 5, label: 'নোটিফিকেশন', icon: Send, page: 'notifications' as const, color: 'bg-teal-50 text-teal-600 hover:bg-teal-100', border: 'border-teal-100' },
  { id: 6, label: 'বাজেট রিপোর্ট', icon: PieChart, page: 'budget' as const, color: 'bg-violet-50 text-violet-500 hover:bg-violet-100', border: 'border-violet-100' },
];

const COMPLAINT_CATEGORIES = [
  { name: 'পানি ও স্যানিটেশন', percent: 35, color: '#FF6B35' },
  { name: 'রাস্তা ও অবকাঠামো', percent: 25, color: '#1eb1b1' },
  { name: 'শিক্ষা', percent: 20, color: '#8B5CF6' },
  { name: 'স্বাস্থ্য', percent: 12, color: '#EC4899' },
  { name: 'অন্যান্য', percent: 8, color: '#94A3B8' },
];

export default function DashboardPage() {
  const { user } = useAuthStore();
  const { navigate } = useNavStore();
  const stats = MOCK_DASHBOARD_STATS;
  const budgetPercent = Math.round((stats.spentBudget / stats.totalBudget) * 100);
  const maxUnionCount = Math.max(...COMPLAINT_BY_UNION.map(u => u.count));

  const welcomeInfo = user?.role && user.role !== 'admin' ? WELCOME_DATA[user.role] : null;

  // Resolve the welcome icon component
  const WelcomeIcon = user?.role === 'acLand' ? LandPlot
    : user?.role === 'ict' ? Monitor
    : user?.role === 'developer' ? Code
    : user?.role === 'uno' ? MessageSquareWarning
    : Zap;

  const [currentTime, setCurrentTime] = useState('');
  const [currentDate, setCurrentDate] = useState('');

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }));
      setCurrentDate(now.toLocaleDateString('bn-BD', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));
    };
    update();
    const interval = setInterval(update, 60000);
    return () => clearInterval(interval);
  }, []);

  const statCards = [
    { icon: Users, title: 'নিবন্ধিত নাগরিক', count: stats.totalCitizens, desc: 'মোট নিবন্ধিত', color: 'bg-orange-50 text-[#FF6B35]', border: 'border-l-orange-400' },
    { icon: UserCheck, title: 'সরকারি কর্মকর্তা', count: stats.totalOfficers, desc: 'সক্রিয় কর্মকর্তা', color: 'bg-emerald-50 text-emerald-600', border: 'border-l-emerald-400' },
    { icon: Building2, title: 'ক্লিনিক/হাসপাতাল', count: stats.totalClinics, desc: 'স্বাস্থ্য সেবা', color: 'bg-teal-50 text-teal-600', border: 'border-l-teal-400' },
    { icon: Stethoscope, title: 'বিশেষজ্ঞ চিকিৎসক', count: stats.totalDoctors, desc: 'নিবন্ধিত চিকিৎসক', color: 'bg-rose-50 text-rose-500', border: 'border-l-rose-400' },
    { icon: Droplets, title: 'রক্তদাতা', count: stats.totalDonors, desc: 'সক্রিয় দাতা', color: 'bg-red-50 text-red-500', border: 'border-l-red-400' },
    { icon: Store, title: 'ব্যবসা প্রতিষ্ঠান', count: stats.totalBusiness, desc: 'নিবন্ধিত ব্যবসা', color: 'bg-amber-50 text-amber-600', border: 'border-l-amber-400' },
    { icon: MessageSquareWarning, title: 'মোট অভিযোগ', count: stats.totalComplaints, desc: `পেন্ডিং: ${stats.pendingComplaints}`, color: 'bg-rose-50 text-rose-600', border: 'border-l-rose-400' },
    { icon: Megaphone, title: 'নোটিশ', count: stats.totalNotices, desc: 'সক্রিয় বিজ্ঞপ্তি', color: 'bg-teal-50 text-teal-600', border: 'border-l-teal-400' },
  ];

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Welcome Banner with thin orange top line */}
      <div className="relative rounded-[12px] bg-card border shadow-sm overflow-hidden">
        <div className="h-[3px] w-full" style={{ background: 'linear-gradient(90deg, #FF6B35 0%, #FF8F5E 50%, #FF6B35 100%)' }} />
        <div className="p-5 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className={`hidden sm:flex w-12 h-12 rounded-[10px] ${welcomeInfo ? welcomeInfo.iconBg : 'bg-[#FF6B35]/10 dark:bg-[#FF6B35]/15'} items-center justify-center flex-shrink-0`}>
                <WelcomeIcon className={`h-6 w-6 ${welcomeInfo ? welcomeInfo.iconColor : 'text-[#FF6B35]'}`} />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold text-foreground">স্বাগতম, {user?.name || 'অ্যাডমিন'}!</h1>
                <p className="text-sm text-muted-foreground mt-0.5">
                  {welcomeInfo ? welcomeInfo.greeting : 'বেতাগী উপজেলা প্রশাসনিক ব্যবস্থাপনা ড্যাশবোর্ড'}
                </p>
                {welcomeInfo && (
                  <p className="text-xs text-muted-foreground/70 mt-1">{welcomeInfo.sub}</p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-3 text-right flex-wrap justify-end">
              <div>
                <p className="text-lg font-bold text-foreground tabular-nums">{currentTime || '--:--'}</p>
                <p className="text-xs text-muted-foreground">{currentDate}</p>
              </div>
              <div className="hidden sm:flex items-center gap-2 text-xs bg-muted/60 dark:bg-white/5 px-3 py-1.5 rounded-[8px]">
                <Activity className="h-3.5 w-3.5 text-emerald-500" />
                <span className="text-muted-foreground">ভূমিকা:</span>
                <span className="font-semibold text-foreground">{user ? ROLE_LABELS[user.role] : ''}</span>
              </div>
              <div className="hidden sm:flex items-center gap-2 text-xs bg-muted/60 dark:bg-white/5 px-3 py-1.5 rounded-[8px]">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-muted-foreground">অনলাইন: ৩</span>
              </div>
            </div>
          </div>
          {/* Role-specific detailed message */}
          {welcomeInfo && (
            <div className="mt-4 pt-4 border-t border-border/50 dark:border-white/5">
              <p className="text-sm text-muted-foreground leading-relaxed">{welcomeInfo.message}</p>
              {/* Quick stats row */}
              <div className="flex flex-wrap gap-4 mt-3">
                {welcomeInfo.quickStats.map((s, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className={`text-base font-bold ${s.color}`}>{s.value}</span>
                    <span className="text-[11px] text-muted-foreground">{s.label}</span>
                  </div>
                ))}
              </div>
              {/* Quick action buttons for role */}
              <div className="flex flex-wrap gap-2 mt-3">
                {welcomeInfo.quickActions.map((action, i) => {
                  const icons: Record<string, React.ComponentType<{className?: string}>> = { Megaphone, MessageSquareWarning, FileText, UserCheck, Bell, PhoneCall, Activity, Settings, UserCog };
                  const ActionIcon = icons[action.icon] || ArrowUpRight;
                  return (
                    <button
                      key={i}
                      onClick={() => navigate(action.page)}
                      className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-[8px] bg-muted/50 dark:bg-white/5 text-muted-foreground hover:text-foreground hover:bg-muted dark:hover:bg-white/10 transition-all duration-200"
                    >
                      <ActionIcon className="h-3.5 w-3.5" />
                      {action.label}
                    </button>
                  );
                })}
              </div>
              {/* Contextual tip */}
              <div className="flex items-center gap-2 mt-3 p-2.5 rounded-[8px] bg-muted/30 dark:bg-white/[0.03]">
                <Info className={`h-4 w-4 flex-shrink-0 ${welcomeInfo.iconColor}`} />
                <p className="text-xs text-muted-foreground">{welcomeInfo.tip}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Stat Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <Card key={i} style={{ animationDelay: `${i * 60}ms` }} className={`rounded-[12px] border-l-4 ${card.border} hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 cursor-pointer group animate-stagger-in`}>
              <CardContent className="p-4 sm:p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className={`p-2 rounded-[10px] ${card.color}`}>
                    <Icon className="h-4 w-4 sm:h-5 sm:w-5" />
                  </div>
                  <ArrowUpRight className="h-4 w-4 text-muted-foreground/30 group-hover:text-[#FF6B35]/50 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                </div>
                <p className="text-xl sm:text-2xl font-bold text-foreground animate-count-up">{card.count.toLocaleString('bn-BD')}</p>
                <p className="text-xs sm:text-sm font-medium text-foreground mt-0.5">{card.title}</p>
                {card.desc && <p className="text-[11px] text-muted-foreground mt-0.5">{card.desc}</p>}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Main Content: 2/3 + 1/3 layout */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Left Column (2/3) */}
        <div className="lg:col-span-2 space-y-4">
          {/* Complaint Bar Chart */}
          <Card className="rounded-[12px] border shadow-sm hover:shadow-md transition-shadow duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <MessageSquareWarning className="h-4 w-4 text-[#FF6B35]" />
                ইউনিয়ন অনুযায়ী অভিযোগ
                <span className="ml-auto text-xs font-normal text-muted-foreground">মোট {(COMPLAINT_BY_UNION.reduce((a, b) => a + b.count, 0)).toLocaleString('bn-BD')} টি</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {COMPLAINT_BY_UNION.map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-xs text-muted-foreground w-20 text-right flex-shrink-0 truncate">{item.union}</span>
                  <div className="flex-1 bg-muted/50 rounded-[10px] h-8 overflow-hidden relative">
                    <div
                      className="h-full rounded-[10px] transition-all duration-1000 ease-out flex items-center px-3"
                      style={{
                        width: `${Math.max((item.count / maxUnionCount) * 100, 15)}%`,
                        backgroundColor: item.color,
                      }}
                    >
                      <span className="text-xs font-bold text-white drop-shadow-sm">{item.count.toLocaleString('bn-BD')}</span>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Recent Activity Timeline */}
          <Card className="rounded-[12px] border shadow-sm hover:shadow-md transition-shadow duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <Clock className="h-4 w-4 text-[#FF6B35]" />
                সাম্প্রতিক কার্যক্রম
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative space-y-0">
                {/* Vertical line */}
                <div className="absolute left-[7px] top-2 bottom-2 w-[2px] bg-gradient-to-b from-[#FF6B35]/20 via-muted-200 dark:via-muted-700 to-transparent" />
                {RECENT_ACTIVITIES.map((activity, i) => {
                  const Icon = activity.icon;
                  return (
                    <div key={activity.id} className="relative flex items-start gap-4 pb-4 last:pb-0">
                      <div className={`relative z-10 w-4 h-4 rounded-full mt-1 flex-shrink-0 ${activity.dot} ring-4 ring-white dark:ring-[#1a1a2e]`} />
                      <div className={`flex-1 flex items-start gap-3 p-2.5 rounded-[10px] hover:bg-muted/40 transition-colors`}>
                        <div className={`p-1.5 rounded-[8px] ${activity.color} flex-shrink-0`}>
                          <Icon className="h-3.5 w-3.5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground leading-relaxed">{activity.text}</p>
                          <p className="text-[11px] text-muted-foreground mt-0.5 flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {activity.time}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column (1/3) */}
        <div className="space-y-4">
          {/* Budget Ring Chart */}
          <Card className="rounded-[12px] border shadow-sm hover:shadow-md transition-shadow duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <PieChart className="h-4 w-4 text-[#FF6B35]" />
                বাজেট সারসংক্ষেপ
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center">
              {/* CSS Ring Chart */}
              <div className="relative w-32 h-32 mb-4">
                <div
                  className="w-full h-full rounded-full"
                  style={{
                    background: `conic-gradient(#FF6B35 0% ${budgetPercent}%, var(--muted) ${budgetPercent}% 100%)`,
                  }}
                />
                <div className="absolute inset-2 rounded-full bg-card flex flex-col items-center justify-center">
                  <p className="text-2xl font-bold text-foreground">{budgetPercent}%</p>
                  <p className="text-[10px] text-muted-foreground">ব্যয়িত</p>
                </div>
              </div>
              <p className="text-sm font-bold text-foreground">৳{(stats.totalBudget / 10000000).toFixed(0)} কোটি</p>
              <p className="text-xs text-muted-foreground mt-0.5">মোট বার্ষিক বাজেট ২০২৪-২৫</p>
              <div className="w-full mt-4 pt-3 border-t space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">ব্যয়িত</span>
                  <span className="font-medium text-foreground">৳{(stats.spentBudget / 10000000).toFixed(1)} কোটি</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">অবশিষ্ট</span>
                  <span className="font-medium text-emerald-600 dark:text-emerald-400">৳{((stats.totalBudget - stats.spentBudget) / 10000000).toFixed(1)} কোটি</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="rounded-[12px] border shadow-sm hover:shadow-md transition-shadow duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <PlusCircle className="h-4 w-4 text-[#FF6B35]" />
                দ্রুত কাজ
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2">
                {QUICK_ACTIONS.map(action => {
                  const Icon = action.icon;
                  return (
                    <button
                      key={action.id}
                      onClick={() => navigate(action.page)}
                      className={`flex flex-col items-center gap-2 p-3 rounded-[10px] border ${action.border} ${action.color} transition-all duration-200 hover:-translate-y-0.5 hover:shadow-sm active:translate-y-0`}
                    >
                      <Icon className="h-5 w-5" />
                      <span className="text-[11px] font-medium leading-tight text-center">{action.label}</span>
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Complaints by Category Pie Chart */}
          <Card className="rounded-[12px] border shadow-sm hover:shadow-md transition-shadow duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <PieChart className="h-4 w-4 text-[#FF6B35]" />
                অভিযোগ বিভাগ
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center">
              <div
                className="w-32 h-32 rounded-full mb-4"
                style={{
                  background: `conic-gradient(
                    #FF6B35 0% 35%,
                    #1eb1b1 35% 60%,
                    #8B5CF6 60% 80%,
                    #EC4899 80% 92%,
                    #94A3B8 92% 100%
                  )`,
                }}
              />
              <div className="w-full space-y-1.5">
                {COMPLAINT_CATEGORIES.map((cat, i) => (
                  <div key={i} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ backgroundColor: cat.color }} />
                      <span className="text-muted-foreground">{cat.name}</span>
                    </div>
                    <span className="font-semibold text-foreground">{cat.percent}%</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Notices mini list */}
          <Card className="rounded-[12px] border shadow-sm hover:shadow-md transition-shadow duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <Megaphone className="h-4 w-4 text-[#FF6B35]" />
                সাম্প্রতিক নোটিশ
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2.5">
                {MOCK_NOTICES.slice(0, 3).map(n => (
                  <div key={n.id} className="flex items-start gap-2.5 p-2 rounded-[8px] hover:bg-muted/40 transition-colors cursor-pointer" onClick={() => navigate('notices')}>
                    <div className="mt-0.5 w-2 h-2 rounded-full bg-[#FF6B35] flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{n.title}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{n.createdAt}</p>
                    </div>
                    <StatusBadge status={n.category} />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Bottom complaint status cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="flex items-center gap-3 p-4 rounded-[12px] bg-card border-l-4 border-l-emerald-400 shadow-sm hover:shadow-md transition-shadow duration-200">
          <div className="p-2 rounded-[10px] bg-emerald-50 dark:bg-emerald-500/10">
            <CheckCircle2 className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div>
            <p className="text-lg font-bold text-emerald-700 dark:text-emerald-400">{stats.resolvedComplaints.toLocaleString('bn-BD')}</p>
            <p className="text-xs text-muted-foreground">সমাধানকৃত</p>
          </div>
        </div>
        <div className="flex items-center gap-3 p-4 rounded-[12px] bg-card border-l-4 border-l-amber-400 shadow-sm hover:shadow-md transition-shadow duration-200">
          <div className="p-2 rounded-[10px] bg-amber-50 dark:bg-amber-500/10">
            <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
          </div>
          <div>
            <p className="text-lg font-bold text-amber-700 dark:text-amber-400">{stats.pendingComplaints.toLocaleString('bn-BD')}</p>
            <p className="text-xs text-muted-foreground">পেন্ডিং</p>
          </div>
        </div>
        <div className="flex items-center gap-3 p-4 rounded-[12px] bg-card border-l-4 border-l-[#FF6B35] shadow-sm hover:shadow-md transition-shadow duration-200">
          <div className="p-2 rounded-[10px] bg-orange-50 dark:bg-[#FF6B35]/10">
            <PieChart className="h-5 w-5 text-[#FF6B35]" />
          </div>
          <div>
            <p className="text-lg font-bold text-[#FF6B35]">{budgetPercent}%</p>
            <p className="text-xs text-muted-foreground">বাজেট ব্যয়</p>
          </div>
        </div>
        <div className="flex items-center gap-3 p-4 rounded-[12px] bg-card border-l-4 border-l-teal-400 shadow-sm hover:shadow-md transition-shadow duration-200">
          <div className="p-2 rounded-[10px] bg-teal-50 dark:bg-teal-500/10">
            <Megaphone className="h-5 w-5 text-teal-600 dark:text-teal-400" />
          </div>
          <div>
            <p className="text-lg font-bold text-teal-700 dark:text-teal-400">{stats.totalNotices.toLocaleString('bn-BD')}</p>
            <p className="text-xs text-muted-foreground">মোট নোটিশ</p>
          </div>
        </div>
        <div className="flex items-center gap-3 p-4 rounded-[12px] bg-card border-l-4 border-l-[#FF6B35] shadow-sm hover:shadow-md transition-shadow duration-200">
          <div className="p-2 rounded-[10px] bg-orange-50 dark:bg-[#FF6B35]/10">
            <div className="flex items-end gap-0.5">
              <div className="w-2 bg-[#FF6B35]/60 rounded-full h-3" />
              <div className="w-2 bg-[#FF6B35]/60 rounded-full h-5" />
              <div className="w-2 bg-[#FF6B35]/60 rounded-full h-4" />
            </div>
          </div>
          <div>
            <p className="text-lg font-bold text-[#FF6B35]">১২</p>
            <p className="text-xs text-muted-foreground">এই মাসে</p>
          </div>
        </div>
      </div>
    </div>
  );
}