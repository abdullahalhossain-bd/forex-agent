'use client';

import React, { useState } from 'react';
import { Plus, Pencil, Trash2, Phone } from 'lucide-react';
import { MOCK_EMERGENCY, EMERGENCY_CATEGORIES } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, DataTable, StatusBadge, ConfirmDialog } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import type { EmergencyNumber } from '@/types/admin';

export default function EmergencyPage() {
  const { hasPermission } = useAuthStore();
  const [data, setData] = useState<EmergencyNumber[]>(MOCK_EMERGENCY);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editItem, setEditItem] = useState<EmergencyNumber | null>(null);
  const [form, setForm] = useState({ name: '', number: '', category: '', description: '' });

  const canAdd = hasPermission('emergency', 'add');
  const canEdit = hasPermission('emergency', 'edit');
  const canDelete = hasPermission('emergency', 'delete');

  const openAdd = () => { setEditItem(null); setForm({ name: '', number: '', category: '', description: '' }); setDialogOpen(true); };
  const openEdit = (item: EmergencyNumber) => { setEditItem(item); setForm({ name: item.name, number: item.number, category: item.category, description: item.description || '' }); setDialogOpen(true); };
  const handleSave = () => {
    if (!form.name || !form.number) { toast.error('নাম ও নম্বর দিন'); return; }
    if (editItem) {
      setData(prev => prev.map(e => e.id === editItem.id ? { ...e, ...form } : e));
      toast.success('জরুরি নম্বর আপডেট হয়েছে');
    } else {
      setData(prev => [...prev, { id: Date.now(), ...form, status: 'সক্রিয়', createdAt: new Date().toISOString().slice(0, 10) }]);
      toast.success('নতুন জরুরি নম্বর যোগ হয়েছে');
    }
    setDialogOpen(false);
  };
  const handleDelete = () => { if (editItem) { setData(prev => prev.filter(e => e.id !== editItem.id)); toast.success('মুছে ফেলা হয়েছে'); } setDeleteOpen(false); };

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="জরুরি নম্বর" description="জরুরি যোগাযোগের নম্বর ও তথ্য ব্যবস্থাপনা">
        {canAdd && <Button onClick={openAdd} className="rounded-[12px] bg-[#1eb1b1] hover:bg-[#189696] text-white"><Plus className="h-4 w-4 mr-1.5" />নতুন নম্বর</Button>}
      </PageHeader>
      <DataTable
        headers={['#', 'নাম', 'নম্বর', 'বিভাগ', 'বিবরণ', 'অবস্থা', (canEdit || canDelete) ? 'অ্যাকশন' : '']}
        data={data}
        searchKeys={['name', 'number', 'category']}
        searchPlaceholder="জরুরি নম্বর খুঁজুন..."
        emptyMessage="কোনো জরুরি নম্বর পাওয়া যায়নি"
        exportConfig={{
          filename: 'জরুরি_নম্বর',
          columns: [
            { key: 'id', label: 'ক্রমিক' },
            { key: 'name', label: 'নাম' },
            { key: 'number', label: 'নম্বর' },
            { key: 'category', label: 'বিভাগ' },
            { key: 'status', label: 'অবস্থা' },
          ],
        }}
        renderRow={(item: EmergencyNumber) => (
          <tr key={item.id} className="hover:bg-muted/50 transition-colors">
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.id}</td>
            <td className="px-4 py-3 text-sm font-medium">{item.name}</td>
            <td className="px-4 py-3"><span className="inline-flex items-center gap-1.5 text-sm font-mono font-medium text-[#FF6B35]"><Phone className="h-3.5 w-3.5" />{item.number}</span></td>
            <td className="px-4 py-3"><StatusBadge status={item.category} /></td>
            <td className="px-4 py-3 text-sm text-muted-foreground max-w-[200px] truncate">{item.description}</td>
            <td className="px-4 py-3"><StatusBadge status={item.status} /></td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-1">
                {canEdit && <button onClick={() => openEdit(item)} className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>}
                {canDelete && <button onClick={() => { setEditItem(item); setDeleteOpen(true); }} className="p-1.5 rounded-[8px] hover:bg-red-50 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>}
              </div>
            </td>
          </tr>
        )}
      />
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="rounded-[12px] max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'নম্বর সম্পাদনা' : 'নতুন জরুরি নম্বর যোগ করুন'}</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2"><Label>নাম</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="সেবার নাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>নম্বর</Label><Input value={form.number} onChange={e => setForm({ ...form, number: e.target.value })} placeholder="ফোন নম্বর" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>বিভাগ</Label>
              <Select value={form.category} onValueChange={v => setForm({ ...form, category: v })}>
                <SelectTrigger className="rounded-[12px]"><SelectValue placeholder="বিভাগ নির্বাচন" /></SelectTrigger>
                <SelectContent>{EMERGENCY_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>বিবরণ</Label><Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="বিবরণ" rows={2} className="rounded-[12px]" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-[12px]">বাতিল</Button>
            <Button onClick={handleSave} className="rounded-[12px] bg-[#1eb1b1] hover:bg-[#189696] text-white">সংরক্ষণ করুন</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={deleteOpen} onOpenChange={setDeleteOpen} title="নম্বর মুছুন" description="আপনি কি এই জরুরি নম্বর মুছে ফেলতে চান?" onConfirm={handleDelete} />
    </div>
  );
}