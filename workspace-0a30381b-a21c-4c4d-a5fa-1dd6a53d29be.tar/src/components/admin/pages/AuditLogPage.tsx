'use client';

import React, { useState, useMemo } from 'react';
import { Activity, Users, CalendarCheck } from 'lucide-react';
import { PageHeader, DataTable, StatusBadge } from '@/components/admin/common/shared';
import { Card, CardContent } from '@/components/ui/card';

interface AuditLogEntry {
  id: number;
  user: string;
  action: string;
  type: string;
  details: string;
  createdAt: string;
}

const AUDIT_LOG: AuditLogEntry[] = [
  { id: 1, user: 'মোঃ আব্দুল করিম', action: 'নতুন নোটিশ যোগ করেছেন', type: 'তৈরি', details: 'উপজেলা প্রশাসনের নিয়মিত সভার নোটিশ প্রকাশ করেছেন।', createdAt: '2025-07-22 14:30' },
  { id: 2, user: 'মোসাঃ ফাতেমা বেগম', action: 'অভিযোগ সমাধান করেছেন', type: 'যোগ করা হয়েছে', details: 'স্কুল ভবন মেরামত অভিযোগটি সমাধান করা হয়েছে।', createdAt: '2025-07-22 13:15' },
  { id: 3, user: 'System', action: 'বাজেট আপডেট হয়েছে', type: 'পাসওয়ার্ড পরিবর্তন', details: '২০২৪-২৫ অর্থবছরের বাজেট তথ্য আপডেট করা হয়েছে।', createdAt: '2025-07-22 12:00' },
  { id: 4, user: 'মোঃ রহিম হোসেন', action: 'লগইন করেছেন', type: 'ব্যবহারকারী', details: 'ইউসার মোঃ রহিম হোসেন সিস্টেমে লগইন করেছেন।', createdAt: '2025-07-22 11:45' },
  { id: 5, user: 'মোঃ সোহেল রানা', action: 'নতুন ডাটা যোগ করেছেন', type: 'তৈরি', details: 'ডেভেলপার হিসেবে নতুন ডাটা রেকর্ড যোগ করেছেন।', createdAt: '2025-07-22 11:30' },
  { id: 6, user: 'System', action: 'ব্যবহারকারী তৈরি পরিবর্তন', type: 'নিরাপক্ষেষ', details: 'মোঃ কামরুজ্জামানের ভূমিকা থেকে পরিবর্তন করা হয়েছে।', createdAt: '2025-07-22 10:00' },
  { id: 7, user: 'মোসাঃ নাসরিন আক্তার', action: 'নোটিফিকেশন পাঠিয়েছেন', type: 'নোটিফিকেশন', details: 'সকল ব্যবহারকারীকে নোটিফিকেশন পাঠান করা হয়েছে।', createdAt: '2025-07-22 09:30' },
  { id: 8, user: 'মোঃ আব্দুল করিম', action: 'সিস্টেম ব্যাকআপ নিয়ম', type: 'পাসওয়ার্ড পরিবর্তন', details: 'ডেটাবেস ব্যাকআপ নেওয়া হয়েছে।', createdAt: '2025-07-22 09:00' },
  { id: 9, user: 'System', action: 'সার্ভার শুরু হয়েছে', type: 'সব', details: 'বেতাগী ই-সেবা অ্যাডমিন পোর্টাল সার্ভার শুরু হয়েছে।', createdAt: '2025-07-22 08:00' },
  { id: 10, user: 'মোঃ শফিকুল ইসলাম', action: 'কর্মকর্তা তথ্য আপডেট', type: 'তৈরি', details: 'উপজেলা কৃষি অফিসারের তথ্য আপডেট করা হয়েছে।', createdAt: '2025-07-21 16:00' },
];

const FILTER_OPTIONS = [
  { label: 'সব', value: 'সব' },
  { label: 'যোগ করা হয়েছে', value: 'যোগ করা হয়েছে' },
  { label: 'ব্যবহারকারী', value: 'ব্যবহারকারী' },
  { label: 'নিরাপক্ষেষ', value: 'নিরাপক্ষেষ' },
  { label: 'পাসওয়ার্ড পরিবর্তন', value: 'পাসওয়ার্ড পরিবর্তন' },
];

export default function AuditLogPage() {
  const [activeFilter, setActiveFilter] = useState<string>('সব');

  const todayCount = AUDIT_LOG.filter(log => log.createdAt.startsWith('2025-07-22')).length;
  const uniqueUsers = new Set(AUDIT_LOG.filter(l => l.user !== 'System').map(l => l.user)).size;

  const filteredData = useMemo(() => {
    if (activeFilter === 'সব') return AUDIT_LOG;
    return AUDIT_LOG.filter(log => log.type === activeFilter);
  }, [activeFilter]);

  const statCards = [
    {
      label: 'মোট ইভেন্ট',
      value: AUDIT_LOG.length,
      icon: Activity,
      accentClass: 'bg-orange-50 text-orange-600',
      borderClass: 'border-orange-200',
    },
    {
      label: 'আজকের ইভেন্ট',
      value: todayCount,
      icon: CalendarCheck,
      accentClass: 'bg-emerald-50 text-emerald-600',
      borderClass: 'border-emerald-200',
    },
    {
      label: 'সক্রিয় ব্যবহারকারী',
      value: uniqueUsers,
      icon: Users,
      accentClass: 'bg-teal-50 text-teal-600',
      borderClass: 'border-teal-200',
    },
  ];

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="সিস্টেম লগ" description="সকল সিস্টেম কার্যকল্রামের তালিকা দেখুন" />

      {/* Summary Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        {statCards.map((card) => {
          const IconComp = card.icon;
          return (
            <Card key={card.label} className={`rounded-[12px] border ${card.borderClass}`}>
              <CardContent className="p-4 flex items-center gap-4">
                <div className={`w-11 h-11 rounded-[10px] flex items-center justify-center ${card.accentClass}`}>
                  <IconComp className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{card.value}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{card.label}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Filter Buttons */}
      <div className="flex flex-wrap items-center gap-2 mb-4">
        {FILTER_OPTIONS.map((opt) => (
          <button
            key={opt.value}
            onClick={() => setActiveFilter(opt.value)}
            className={`px-3.5 py-1.5 rounded-[10px] text-xs font-medium transition-all duration-200 ${
              activeFilter === opt.value
                ? 'bg-[#FF6B35] text-white shadow-sm'
                : 'bg-muted/60 text-muted-foreground hover:bg-muted hover:text-foreground'
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>

      {/* Data Table */}
      <DataTable<AuditLogEntry>
        headers={['#', 'সময়', 'ব্যবহারকারী', 'ধরন', 'বিবরণ', 'তারিখ']}
        data={filteredData}
        searchKeys={['user', 'action', 'details']}
        searchPlaceholder="লগ খুঁজুন..."
        emptyMessage="কোনো লগ পাওয়া যায়নি"
        exportConfig={{
          filename: 'সিস্টেম_লগ',
          columns: [
            { key: 'id', label: 'ক্রমিক' },
            { key: 'user', label: 'ব্যবহারকারী' },
            { key: 'action', label: 'কার্যকলাপ' },
            { key: 'type', label: 'ধরন' },
            { key: 'details', label: 'বিবরণ' },
            { key: 'createdAt', label: 'তারিখ' },
          ],
        }}
        renderRow={(item: AuditLogEntry) => (
          <tr key={item.id} className="hover:bg-muted/50 transition-colors">
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.id}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.createdAt.split(' ')[1]}</td>
            <td className="px-4 py-3 text-sm font-medium">
              <span className={item.user === 'System' ? 'text-muted-foreground italic' : ''}>
                {item.user}
              </span>
            </td>
            <td className="px-4 py-3">
              <StatusBadge status={item.type} />
            </td>
            <td className="px-4 py-3 text-sm text-muted-foreground max-w-xs truncate">{item.details}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.createdAt.split(' ')[0]}</td>
          </tr>
        )}
      />
    </div>
  );
}
