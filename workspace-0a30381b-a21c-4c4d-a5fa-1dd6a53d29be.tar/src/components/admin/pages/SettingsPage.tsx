'use client';

import React, { useState } from 'react';
import {
  Settings, Shield, Bell, Palette, Database, Save,
  Globe, Lock, Monitor, Mail, Smartphone, Upload, Download, Trash2,
  Clock, Image as ImageIcon, Building, CalendarDays, Hash, KeyRound
} from 'lucide-react';
import { useAuthStore } from '@/stores/admin';
import { PageHeader } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';

const ACCENT_LINE = 'h-[3px] w-full rounded-t-[12px]';

export default function SettingsPage() {
  const { hasPermission } = useAuthStore();
  const canEdit = hasPermission('dashboard', 'edit');

  // General settings
  const [general, setGeneral] = useState({
    orgName: 'বেতাগী উপজেলা প্রশাসন',
    upazila: 'বেতাগী',
    district: 'বরিশাল',
    fiscalYear: '২০২৪-২০২৫',
  });

  // Notification settings
  const [notif, setNotif] = useState({
    emailEnabled: true,
    smsEnabled: false,
    pushEnabled: true,
    frequency: 'তাৎক্ষণিক',
  });

  // Security settings
  const [security, setSecurity] = useState({
    minLength: 8,
    requireUppercase: true,
    requireNumber: true,
    requireSpecial: false,
    sessionTimeout: '৩০ মিনিট',
    twoFactorEnabled: false,
  });

  // Display settings
  const [display, setDisplay] = useState({
    theme: 'light',
    sidebarDefault: 'expanded',
    itemsPerPage: '১০',
    language: 'বাংলা',
  });

  const handleSave = () => {
    toast.success('সেটিংস সফলভাবে সংরক্ষিত হয়েছে');
  };

  const handleExportData = () => {
    toast.success('ডেটা এক্সপোর্ট শুরু হয়েছে');
  };

  const handleImportData = () => {
    toast.info('ইমপোর্ট ফিচার শীঘ্রই আসছে');
  };

  const handleClearCache = () => {
    toast.success('ক্যাশে সফলভাবে মুছে ফেলা হয়েছে');
  };

  return (
    <div className="animate-fade-in-up max-w-4xl">
      <PageHeader
        title="সেটিংস"
        description="সিস্টেমের সকল কনফিগারেশন ও পছন্দসমূহ পরিচালনা করুন"
      />

      <div className="space-y-6">
        {/* General Settings */}
        <Card className="rounded-[12px] border overflow-hidden hover:shadow-md transition-shadow duration-200">
          <div className={ACCENT_LINE} style={{ background: 'linear-gradient(90deg, #FF6B35, #ff9a5c, #FF6B35)' }} />
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Building className="h-4 w-4 text-[#FF6B35]" />
              সাধারণ সেটিংস
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Organization name */}
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5 text-xs">
                <Globe className="h-3.5 w-3.5 text-muted-foreground" />
                প্রতিষ্ঠানের নাম
              </Label>
              <Input
                value={general.orgName}
                onChange={e => setGeneral({ ...general, orgName: e.target.value })}
                disabled={!canEdit}
                className="rounded-[12px]"
              />
            </div>

            {/* Logo placeholder */}
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5 text-xs">
                <ImageIcon className="h-3.5 w-3.5 text-muted-foreground" />
                লোগো
              </Label>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-[12px] border-2 border-dashed border-muted-foreground/30 flex items-center justify-center bg-muted/30">
                  <ImageIcon className="h-6 w-6 text-muted-foreground/40" />
                </div>
                {canEdit && (
                  <Button variant="outline" size="sm" className="rounded-[12px] text-xs gap-1.5">
                    <Upload className="h-3.5 w-3.5" />
                    লোগো আপলোড করুন
                  </Button>
                )}
              </div>
            </div>

            {/* Upazila & District & Fiscal Year */}
            <div className="grid sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-xs">উপজেলা</Label>
                <Input
                  value={general.upazila}
                  onChange={e => setGeneral({ ...general, upazila: e.target.value })}
                  disabled={!canEdit}
                  className="rounded-[12px]"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs">জেলা</Label>
                <Input
                  value={general.district}
                  onChange={e => setGeneral({ ...general, district: e.target.value })}
                  disabled={!canEdit}
                  className="rounded-[12px]"
                />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5 text-xs">
                  <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" />
                  অর্থবছর
                </Label>
                <Select
                  value={general.fiscalYear}
                  onValueChange={v => setGeneral({ ...general, fiscalYear: v })}
                  disabled={!canEdit}
                >
                  <SelectTrigger className="rounded-[12px] text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="২০২৩-২০২৪">২০২৩-২০২৪</SelectItem>
                    <SelectItem value="২০২৪-২০২৫">২০২৪-২০২৫</SelectItem>
                    <SelectItem value="২০২৫-২০২৬">২০২৫-২০২৬</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card className="rounded-[12px] border overflow-hidden hover:shadow-md transition-shadow duration-200">
          <div className={ACCENT_LINE} style={{ background: 'linear-gradient(90deg, #FF6B35, #ff9a5c, #FF6B35)' }} />
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Bell className="h-4 w-4 text-[#FF6B35]" />
              নোটিফিকেশন সেটিংস
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Email toggle */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-[10px] bg-sky-50">
                  <Mail className="h-4 w-4 text-sky-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">ইমেইল নোটিফিকেশন</p>
                  <p className="text-xs text-muted-foreground">গুরুত্বপূর্ণ আপডেট ইমেইলে পান</p>
                </div>
              </div>
              <Switch
                checked={notif.emailEnabled}
                onCheckedChange={v => setNotif({ ...notif, emailEnabled: v })}
                disabled={!canEdit}
              />
            </div>

            <Separator />

            {/* SMS toggle */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-[10px] bg-emerald-50">
                  <Smartphone className="h-4 w-4 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">এসএমএস নোটিফিকেশন</p>
                  <p className="text-xs text-muted-foreground">মোবাইলে এসএমএস পান</p>
                </div>
              </div>
              <Switch
                checked={notif.smsEnabled}
                onCheckedChange={v => setNotif({ ...notif, smsEnabled: v })}
                disabled={!canEdit}
              />
            </div>

            <Separator />

            {/* Push toggle */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-[10px] bg-violet-50">
                  <Bell className="h-4 w-4 text-violet-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">পুশ নোটিফিকেশন</p>
                  <p className="text-xs text-muted-foreground">ব্রাউজার পুশ নোটিফিকেশন পান</p>
                </div>
              </div>
              <Switch
                checked={notif.pushEnabled}
                onCheckedChange={v => setNotif({ ...notif, pushEnabled: v })}
                disabled={!canEdit}
              />
            </div>

            <Separator />

            {/* Notification frequency */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-[10px] bg-amber-50">
                  <Clock className="h-4 w-4 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">নোটিফিকেশন ফ্রিকোয়েন্সি</p>
                  <p className="text-xs text-muted-foreground">নোটিফিকেশন পাওয়ার সময়কাল নির্বাচন করুন</p>
                </div>
              </div>
              <Select
                value={notif.frequency}
                onValueChange={v => setNotif({ ...notif, frequency: v })}
                disabled={!canEdit}
              >
                <SelectTrigger className="w-[160px] rounded-[12px] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="তাৎক্ষণিক">তাৎক্ষণিক</SelectItem>
                  <SelectItem value="প্রতিঘণ্টা">প্রতিঘণ্টা</SelectItem>
                  <SelectItem value="দৈনিক সারাংশ">দৈনিক সারাংশ</SelectItem>
                  <SelectItem value="সাপ্তাহিক সারাংশ">সাপ্তাহিক সারাংশ</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card className="rounded-[12px] border overflow-hidden hover:shadow-md transition-shadow duration-200">
          <div className={ACCENT_LINE} style={{ background: 'linear-gradient(90deg, #FF6B35, #ff9a5c, #FF6B35)' }} />
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Shield className="h-4 w-4 text-[#FF6B35]" />
              নিরাপত্তা সেটিংস
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Password policy header */}
            <div className="flex items-center gap-2 mb-1">
              <KeyRound className="h-4 w-4 text-muted-foreground" />
              <p className="text-sm font-medium">পাসওয়ার্ড পলিসি</p>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 pl-6">
              {/* Min length */}
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5 text-xs">
                  <Hash className="h-3.5 w-3.5 text-muted-foreground" />
                  ন্যূনতম দৈর্ঘ্য
                </Label>
                <Select
                  value={String(security.minLength)}
                  onValueChange={v => setSecurity({ ...security, minLength: Number(v) })}
                  disabled={!canEdit}
                >
                  <SelectTrigger className="rounded-[12px] text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="6">৬</SelectItem>
                    <SelectItem value="8">৮</SelectItem>
                    <SelectItem value="10">১০</SelectItem>
                    <SelectItem value="12">১২</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Session timeout */}
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5 text-xs">
                  <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                  সেশন টাইমআউট
                </Label>
                <Select
                  value={security.sessionTimeout}
                  onValueChange={v => setSecurity({ ...security, sessionTimeout: v })}
                  disabled={!canEdit}
                >
                  <SelectTrigger className="rounded-[12px] text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="১৫ মিনিট">১৫ মিনিট</SelectItem>
                    <SelectItem value="৩০ মিনিট">৩০ মিনিট</SelectItem>
                    <SelectItem value="১ ঘণ্টা">১ ঘণ্টা</SelectItem>
                    <SelectItem value="২ ঘণ্টা">২ ঘণ্টা</SelectItem>
                    <SelectItem value="কখনো না">কখনো না</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Password requirement toggles */}
            <div className="space-y-4 pl-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-[8px] bg-amber-50">
                    <Lock className="h-3.5 w-3.5 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">বড় হাতের অক্ষর প্রয়োজন</p>
                    <p className="text-xs text-muted-foreground">A-Z অক্ষর অন্তর্ভুক্ত থাকতে হবে</p>
                  </div>
                </div>
                <Switch
                  checked={security.requireUppercase}
                  onCheckedChange={v => setSecurity({ ...security, requireUppercase: v })}
                  disabled={!canEdit}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-[8px] bg-sky-50">
                    <Hash className="h-3.5 w-3.5 text-sky-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">সংখ্যা প্রয়োজন</p>
                    <p className="text-xs text-muted-foreground">০-৯ সংখ্যা অন্তর্ভুক্ত থাকতে হবে</p>
                  </div>
                </div>
                <Switch
                  checked={security.requireNumber}
                  onCheckedChange={v => setSecurity({ ...security, requireNumber: v })}
                  disabled={!canEdit}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-[8px] bg-rose-50">
                    <Settings className="h-3.5 w-3.5 text-rose-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">বিশেষ অক্ষর প্রয়োজন</p>
                    <p className="text-xs text-muted-foreground">!@#$%^&* ইত্যাদি অক্ষর অন্তর্ভুক্ত থাকতে হবে</p>
                  </div>
                </div>
                <Switch
                  checked={security.requireSpecial}
                  onCheckedChange={v => setSecurity({ ...security, requireSpecial: v })}
                  disabled={!canEdit}
                />
              </div>
            </div>

            <Separator />

            {/* 2FA toggle */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-[10px] bg-emerald-50">
                  <Shield className="h-4 w-4 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">দুই-ধাপে প্রমাণীকরণ (২এফএ)</p>
                  <p className="text-xs text-muted-foreground">অতিরিক্ত নিরাপত্তার জন্য ২এফএ সক্রিয় করুন</p>
                </div>
              </div>
              <Switch
                checked={security.twoFactorEnabled}
                onCheckedChange={v => setSecurity({ ...security, twoFactorEnabled: v })}
                disabled={!canEdit}
              />
            </div>
          </CardContent>
        </Card>

        {/* Display Settings */}
        <Card className="rounded-[12px] border overflow-hidden hover:shadow-md transition-shadow duration-200">
          <div className={ACCENT_LINE} style={{ background: 'linear-gradient(90deg, #FF6B35, #ff9a5c, #FF6B35)' }} />
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Palette className="h-4 w-4 text-[#FF6B35]" />
              প্রদর্শন সেটিংস
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Theme toggle */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-[10px] bg-violet-50">
                  <Monitor className="h-4 w-4 text-violet-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">থিম</p>
                  <p className="text-xs text-muted-foreground">আপনার পছন্দের থিম নির্বাচন করুন</p>
                </div>
              </div>
              <Select
                value={display.theme}
                onValueChange={v => setDisplay({ ...display, theme: v })}
                disabled={!canEdit}
              >
                <SelectTrigger className="w-[160px] rounded-[12px] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">হালকা</SelectItem>
                  <SelectItem value="dark">অন্ধকার</SelectItem>
                  <SelectItem value="system">সিস্টেম</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Separator />

            {/* Sidebar default state */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-[10px] bg-sky-50">
                  <Settings className="h-4 w-4 text-sky-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">সাইডবার ডিফল্ট অবস্থা</p>
                  <p className="text-xs text-muted-foreground">লগইনের সময় সাইডবারের প্রাথমিক অবস্থা</p>
                </div>
              </div>
              <Select
                value={display.sidebarDefault}
                onValueChange={v => setDisplay({ ...display, sidebarDefault: v })}
                disabled={!canEdit}
              >
                <SelectTrigger className="w-[160px] rounded-[12px] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="expanded">প্রসারিত</SelectItem>
                  <SelectItem value="collapsed">সংকুচিত</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Separator />

            {/* Items per page */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-[10px] bg-emerald-50">
                  <Database className="h-4 w-4 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">প্রতি পৃষ্ঠায় আইটেম</p>
                  <p className="text-xs text-muted-foreground">তালিকায় প্রতি পৃষ্ঠায় দেখানো আইটেম সংখ্যা</p>
                </div>
              </div>
              <Select
                value={display.itemsPerPage}
                onValueChange={v => setDisplay({ ...display, itemsPerPage: v })}
                disabled={!canEdit}
              >
                <SelectTrigger className="w-[160px] rounded-[12px] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="৫">৫</SelectItem>
                  <SelectItem value="১০">১০</SelectItem>
                  <SelectItem value="২৫">২৫</SelectItem>
                  <SelectItem value="৫০">৫০</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Separator />

            {/* Language selector */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-[10px] bg-amber-50">
                  <Globe className="h-4 w-4 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">ভাষা</p>
                  <p className="text-xs text-muted-foreground">ইন্টারফেসের ভাষা নির্বাচন করুন</p>
                </div>
              </div>
              <Select
                value={display.language}
                onValueChange={v => setDisplay({ ...display, language: v })}
                disabled={!canEdit}
              >
                <SelectTrigger className="w-[160px] rounded-[12px] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="বাংলা">বাংলা</SelectItem>
                  <SelectItem value="English">English</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Backup & Data */}
        <Card className="rounded-[12px] border overflow-hidden hover:shadow-md transition-shadow duration-200">
          <div className={ACCENT_LINE} style={{ background: 'linear-gradient(90deg, #FF6B35, #ff9a5c, #FF6B35)' }} />
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Database className="h-4 w-4 text-[#FF6B35]" />
              ব্যাকআপ ও ডেটা
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Last backup info */}
            <div className="flex items-center gap-3 p-3 rounded-[12px] bg-muted/40">
              <div className="p-2 rounded-[10px] bg-emerald-50 flex-shrink-0">
                <Database className="h-4 w-4 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm font-medium">সর্বশেষ ব্যাকআপ</p>
                <p className="text-xs text-muted-foreground">১ জুন, ২০২৫ তারিখ ০৩:০০ টায় (স্বয়ংক্রিয় দৈনিক)</p>
              </div>
              <span className="ml-auto text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-medium flex-shrink-0">
                সফল
              </span>
            </div>

            {/* Action buttons */}
            <div className="grid sm:grid-cols-3 gap-3">
              <Button
                variant="outline"
                onClick={handleExportData}
                disabled={!canEdit}
                className="rounded-[12px] gap-2 text-xs h-10 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-200 transition-colors"
              >
                <Download className="h-4 w-4" />
                সকল ডেটা এক্সপোর্ট
              </Button>

              <Button
                variant="outline"
                onClick={handleImportData}
                disabled={!canEdit}
                className="rounded-[12px] gap-2 text-xs h-10 hover:bg-sky-50 hover:text-sky-700 hover:border-sky-200 transition-colors"
              >
                <Upload className="h-4 w-4" />
                ডেটা ইমপোর্ট
              </Button>

              <Button
                variant="outline"
                onClick={handleClearCache}
                disabled={!canEdit}
                className="rounded-[12px] gap-2 text-xs h-10 hover:bg-amber-50 hover:text-amber-700 hover:border-amber-200 transition-colors"
              >
                <Trash2 className="h-4 w-4" />
                ক্যাশে মুছুন
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex justify-end pt-2 pb-6">
          <Button
            onClick={handleSave}
            disabled={!canEdit}
            className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white gap-2 px-6 h-10"
          >
            <Save className="h-4 w-4" />
            সেটিংস সংরক্ষণ করুন
          </Button>
        </div>
      </div>
    </div>
  );
}
