'use client';

import React, { useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { MOCK_SERVICE_ITEMS } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, DataTable, StatusBadge, ConfirmDialog } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import type { GovtServiceItem } from '@/types/admin';

export default function ServiceItemsPage() {
  const { hasPermission } = useAuthStore();
  const [data, setData] = useState<GovtServiceItem[]>(MOCK_SERVICE_ITEMS);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editItem, setEditItem] = useState<GovtServiceItem | null>(null);
  const [form, setForm] = useState({ name: '', category: '', description: '', fee: 0, requiredDocs: '', process: '' });

  const canAdd = hasPermission('serviceItems', 'add');
  const canEdit = hasPermission('serviceItems', 'edit');
  const canDelete = hasPermission('serviceItems', 'delete');

  const openAdd = () => { setEditItem(null); setForm({ name: '', category: '', description: '', fee: 0, requiredDocs: '', process: '' }); setDialogOpen(true); };
  const openEdit = (item: GovtServiceItem) => { setEditItem(item); setForm({ name: item.name, category: item.category, description: item.description || '', fee: item.fee, requiredDocs: item.requiredDocs || '', process: item.process || '' }); setDialogOpen(true); };
  const handleSave = () => {
    if (!form.name || !form.category) { toast.error('সেবার নাম ও বিভাগ দিন'); return; }
    if (editItem) {
      setData(prev => prev.map(s => s.id === editItem.id ? { ...s, ...form } : s));
      toast.success('সেবা আইটেম আপডেট হয়েছে');
    } else {
      setData(prev => [...prev, { id: Date.now(), ...form, status: 'সক্রিয়', createdAt: new Date().toISOString().slice(0, 10) }]);
      toast.success('নতুন সেবা আইটেম যোগ হয়েছে');
    }
    setDialogOpen(false);
  };
  const handleDelete = () => {
    if (editItem) { setData(prev => prev.filter(s => s.id !== editItem.id)); toast.success('সেবা আইটেম মুছে ফেলা হয়েছে'); }
    setDeleteOpen(false);
  };

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="সেবা আইটেম" description="সরকারি সেবার তালিকা ও ব্যবস্থাপনা">
        {canAdd && <Button onClick={openAdd} className="rounded-[12px] bg-[#1eb1b1] hover:bg-[#189696] text-white"><Plus className="h-4 w-4 mr-1.5" />নতুন সেবা</Button>}
      </PageHeader>
      <DataTable
        headers={['#', 'সেবার নাম', 'বিভাগ', 'ফি (৳)', 'প্রয়োজনীয় কাগজপত্র', 'অবস্থা', (canEdit || canDelete) ? 'অ্যাকশন' : '']}
        data={data}
        searchKeys={['name', 'category']}
        searchPlaceholder="সেবা খুঁজুন..."
        emptyMessage="কোনো সেবা আইটেম পাওয়া যায়নি"
        exportConfig={{
          filename: 'সেবা_আইটেম',
          columns: [
            { key: 'id', label: 'ক্রমিক' },
            { key: 'name', label: 'নাম' },
            { key: 'category', label: 'বিভাগ' },
            { key: 'fee', label: 'ফি' },
            { key: 'status', label: 'অবস্থা' },
          ],
        }}
        renderRow={(item: GovtServiceItem) => (
          <tr key={item.id} className="hover:bg-muted/50 transition-colors">
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.id}</td>
            <td className="px-4 py-3"><p className="text-sm font-medium">{item.name}</p><p className="text-[11px] text-muted-foreground mt-0.5 max-w-xs truncate">{item.description}</p></td>
            <td className="px-4 py-3 text-sm">{item.category}</td>
            <td className="px-4 py-3 text-sm font-medium">{item.fee === 0 ? 'বিনামূল্যে' : `৳${item.fee}`}</td>
            <td className="px-4 py-3 text-xs text-muted-foreground max-w-[200px] truncate">{item.requiredDocs}</td>
            <td className="px-4 py-3"><StatusBadge status={item.status} /></td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-1">
                {canEdit && <button onClick={() => openEdit(item)} className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>}
                {canDelete && <button onClick={() => { setEditItem(item); setDeleteOpen(true); }} className="p-1.5 rounded-[8px] hover:bg-red-50 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>}
              </div>
            </td>
          </tr>
        )}
      />
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="rounded-[12px] max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'সেবা সম্পাদনা' : 'নতুন সেবা যোগ করুন'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="space-y-2 col-span-2"><Label>সেবার নাম</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="সেবার নাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>বিভাগ</Label><Input value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} placeholder="বিভাগ" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>ফি (৳)</Label><Input type="number" value={form.fee} onChange={e => setForm({ ...form, fee: Number(e.target.value) })} className="rounded-[12px]" /></div>
            <div className="space-y-2 col-span-2"><Label>বিবরণ</Label><Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="সেবার বিবরণ" rows={2} className="rounded-[12px]" /></div>
            <div className="space-y-2 col-span-2"><Label>প্রয়োজনীয় কাগজপত্র</Label><Input value={form.requiredDocs} onChange={e => setForm({ ...form, requiredDocs: e.target.value })} placeholder="কমা দিয়ে আলাদা করুন" className="rounded-[12px]" /></div>
            <div className="space-y-2 col-span-2"><Label>প্রক্রিয়া</Label><Input value={form.process} onChange={e => setForm({ ...form, process: e.target.value })} placeholder="আবেদন → যাচাই → প্রদান" className="rounded-[12px]" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-[12px]">বাতিল</Button>
            <Button onClick={handleSave} className="rounded-[12px] bg-[#1eb1b1] hover:bg-[#189696] text-white">সংরক্ষণ করুন</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={deleteOpen} onOpenChange={setDeleteOpen} title="সেবা আইটেম মুছুন" description="আপনি কি এই সেবা আইটেম মুছে ফেলতে চান?" onConfirm={handleDelete} />
    </div>
  );
}