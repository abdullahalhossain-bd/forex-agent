'use client';

import React, { useState } from 'react';
import { Plus, Pencil, Trash2, Stethoscope } from 'lucide-react';
import { MOCK_DOCTORS, BLOOD_GROUPS } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, DataTable, StatusBadge, ConfirmDialog } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import type { Doctor } from '@/types/admin';

export default function DoctorsPage() {
  const { hasPermission } = useAuthStore();
  const [data, setData] = useState<Doctor[]>(MOCK_DOCTORS);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editItem, setEditItem] = useState<Doctor | null>(null);
  const [form, setForm] = useState({ name: '', specialization: '', qualification: '', phone: '', chamber: '', schedule: '', fee: 0, bloodGroup: '' });

  const canAdd = hasPermission('doctors', 'add');
  const canEdit = hasPermission('doctors', 'edit');
  const canDelete = hasPermission('doctors', 'delete');

  const openAdd = () => { setEditItem(null); setForm({ name: '', specialization: '', qualification: '', phone: '', chamber: '', schedule: '', fee: 0, bloodGroup: '' }); setDialogOpen(true); };
  const openEdit = (item: Doctor) => { setEditItem(item); setForm({ name: item.name, specialization: item.specialization, qualification: item.qualification || '', phone: item.phone, chamber: item.chamber || '', schedule: item.schedule || '', fee: item.fee || 0, bloodGroup: item.bloodGroup || '' }); setDialogOpen(true); };
  const handleSave = () => {
    if (!form.name || !form.specialization) { toast.error('নাম ও বিশেষজ্ঞতা দিন'); return; }
    if (editItem) { setData(prev => prev.map(d => d.id === editItem.id ? { ...d, ...form } : d)); toast.success('চিকিৎসকের তথ্য আপডেট হয়েছে'); }
    else { setData(prev => [...prev, { id: Date.now(), ...form, status: 'সক্রিয়', createdAt: new Date().toISOString().slice(0, 10) }]); toast.success('নতুন চিকিৎসক যোগ হয়েছে'); }
    setDialogOpen(false);
  };
  const handleDelete = () => { if (editItem) { setData(prev => prev.filter(d => d.id !== editItem.id)); toast.success('চিকিৎসক মুছে ফেলা হয়েছে'); } setDeleteOpen(false); };

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="বিশেষজ্ঞ চিকিৎসক" description="বিশেষজ্ঞ চিকিৎসকদের তথ্য ব্যবস্থাপনা">
        {canAdd && <Button onClick={openAdd} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white"><Plus className="h-4 w-4 mr-1.5" />নতুন চিকিৎসক</Button>}
      </PageHeader>
      <DataTable
        headers={['#', 'নাম', 'বিশেষজ্ঞতা', 'যোগ্যতা', 'ফোন', 'চেম্বার', 'ফি', 'রক্তের গ্রুপ', (canEdit || canDelete) ? 'অ্যাকশন' : '']}
        data={data}
        searchKeys={['name', 'specialization', 'chamber']}
        searchPlaceholder="চিকিৎসক খুঁজুন..."
        emptyMessage="কোনো চিকিৎসক পাওয়া যায়নি"
        exportConfig={{
          filename: 'চিকিৎসক',
          columns: [
            { key: 'id', label: 'ক্রমিক' },
            { key: 'name', label: 'নাম' },
            { key: 'specialization', label: 'বিশেষজ্ঞতা' },
            { key: 'phone', label: 'ফোন' },
            { key: 'chamber', label: 'চেম্বার' },
            { key: 'fee', label: 'ফি' },
            { key: 'bloodGroup', label: 'রক্তের গ্রুপ' },
          ],
        }}
        renderRow={(item: Doctor) => (
          <tr key={item.id} className="hover:bg-muted/50 transition-colors">
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.id}</td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-orange-50 text-[#FF6B35] flex items-center justify-center flex-shrink-0"><Stethoscope className="h-4 w-4" /></div>
                <span className="text-sm font-medium">{item.name}</span>
              </div>
            </td>
            <td className="px-4 py-3 text-sm">{item.specialization}</td>
            <td className="px-4 py-3 text-xs text-muted-foreground">{item.qualification}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.phone}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground max-w-[150px] truncate">{item.chamber}</td>
            <td className="px-4 py-3 text-sm font-medium">{item.fee === 0 ? 'বিনামূল্যে' : `৳${item.fee}`}</td>
            <td className="px-4 py-3"><span className="text-xs px-2 py-1 rounded-full bg-red-50 text-red-600 font-medium">{item.bloodGroup}</span></td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-1">
                {canEdit && <button onClick={() => openEdit(item)} className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>}
                {canDelete && <button onClick={() => { setEditItem(item); setDeleteOpen(true); }} className="p-1.5 rounded-[8px] hover:bg-red-50 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>}
              </div>
            </td>
          </tr>
        )}
      />
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="rounded-[12px] max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'চিকিৎসক সম্পাদনা' : 'নতুন চিকিৎসক যোগ করুন'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="space-y-2 col-span-2"><Label>নাম</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="ডাক্তারের নাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>বিশেষজ্ঞতা</Label><Input value={form.specialization} onChange={e => setForm({ ...form, specialization: e.target.value })} placeholder="বিশেষজ্ঞতা" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>যোগ্যতা</Label><Input value={form.qualification} onChange={e => setForm({ ...form, qualification: e.target.value })} placeholder="এমবিবিএস, এফসিপিএস" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>ফোন</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="ফোন নম্বর" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>চেম্বার</Label><Input value={form.chamber} onChange={e => setForm({ ...form, chamber: e.target.value })} placeholder="চেম্বারের নাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>সূচি</Label><Input value={form.schedule} onChange={e => setForm({ ...form, schedule: e.target.value })} placeholder="সপ্তাহের দিন ও সময়" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>ফি (৳)</Label><Input type="number" value={form.fee} onChange={e => setForm({ ...form, fee: Number(e.target.value) })} className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>রক্তের গ্রুপ</Label>
              <Select value={form.bloodGroup} onValueChange={v => setForm({ ...form, bloodGroup: v })}>
                <SelectTrigger className="rounded-[12px]"><SelectValue placeholder="নির্বাচন" /></SelectTrigger>
                <SelectContent>{BLOOD_GROUPS.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-[12px]">বাতিল</Button>
            <Button onClick={handleSave} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white">সংরক্ষণ করুন</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={deleteOpen} onOpenChange={setDeleteOpen} title="চিকিৎসক মুছুন" description="আপনি কি এই চিকিৎসকের তথ্য মুছে ফেলতে চান?" onConfirm={handleDelete} />
    </div>
  );
}