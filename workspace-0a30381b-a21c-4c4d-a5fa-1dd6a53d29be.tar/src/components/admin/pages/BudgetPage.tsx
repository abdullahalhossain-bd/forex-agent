'use client';

import React, { useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  Wallet,
  TrendingUp,
  PiggyBank,
  IndianRupee,
} from 'lucide-react';
import { MOCK_BUDGET } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, ConfirmDialog } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import type { BudgetItem } from '@/types/admin';

/* ─── Constants ──────────────────────────────────────────────── */
const TEAL = '#1eb1b1';
const ORANGE = '#FF6B35';

const GOVT_CATEGORIES = new Set([
  'রাস্তা ও অবকাঠামো',
  'শিক্ষা',
  'স্বাস্থ্য',
  'কৃষি',
]);

function isGovtCategory(cat: string) {
  return GOVT_CATEGORIES.has(cat);
}

/* ─── Helper: Bengali numeral formatter ──────────────────────── */
function bn(n: number) {
  return n.toLocaleString('bn-BD');
}

/* ─── Custom colored progress bar (identical to shadcn style) ── */
function ColorBar({
  value,
  color,
  h = 10,
}: {
  value: number;
  color: string;
  h?: number;
}) {
  return (
    <div
      className="relative w-full overflow-hidden rounded-full bg-muted/60"
      style={{ height: `${h}px` }}
    >
      <div
        className="h-full rounded-full transition-all duration-500 ease-out"
        style={{
          width: `${Math.min(value, 100)}%`,
          backgroundColor: color,
        }}
      />
    </div>
  );
}

/* ─── Category icon helper ───────────────────────────────────── */
const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  'রাস্তা ও অবকাঠামো': (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19l4-14 4 8 4-4 4 10"/></svg>
  ),
  'শিক্ষা': (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
  ),
  'স্বাস্থ্য': (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
  ),
  'কৃষি': (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M7 20h10"/><path d="M10 20c5.5-2.5.8-6.4 3-10"/><path d="M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z"/><path d="M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z"/></svg>
  ),
  'সমাজসেবা': (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
  ),
};

/* ═════════════════════════════════════════════════════════════ */
export default function BudgetPage() {
  const { hasPermission } = useAuthStore();
  const [data, setData] = useState<BudgetItem[]>(MOCK_BUDGET);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editItem, setEditItem] = useState<BudgetItem | null>(null);
  const [form, setForm] = useState({
    category: '',
    allocated: 0,
    spent: 0,
    fiscalYear: '2024-2025',
    description: '',
  });

  const canAdd = hasPermission('budget', 'add');
  const canEdit = hasPermission('budget', 'edit');
  const canDelete = hasPermission('budget', 'delete');

  /* ── Computed values ────────────────────────────────────── */
  const totalAllocated = data.reduce((s, b) => s + b.allocated, 0);
  const totalSpent = data.reduce((s, b) => s + b.spent, 0);
  const totalRemaining = totalAllocated - totalSpent;
  const overallPercent = Math.round((totalSpent / totalAllocated) * 100);

  /* ── Handlers ───────────────────────────────────────────── */
  const openAdd = () => {
    setEditItem(null);
    setForm({ category: '', allocated: 0, spent: 0, fiscalYear: '2024-2025', description: '' });
    setDialogOpen(true);
  };

  const openEdit = (item: BudgetItem) => {
    setEditItem(item);
    setForm({
      category: item.category,
      allocated: item.allocated,
      spent: item.spent,
      fiscalYear: item.fiscalYear,
      description: item.description || '',
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!form.category) {
      toast.error('বিভাগ দিন');
      return;
    }
    if (editItem) {
      setData((prev) =>
        prev.map((b) => (b.id === editItem.id ? { ...b, ...form } : b)),
      );
      toast.success('বাজেট আপডেট হয়েছে');
    } else {
      setData((prev) => [
        ...prev,
        {
          id: Date.now(),
          ...form,
          createdAt: new Date().toISOString().slice(0, 10),
        },
      ]);
      toast.success('নতুন বাজেট আইটেম যোগ হয়েছে');
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (editItem) {
      setData((prev) => prev.filter((b) => b.id !== editItem.id));
      toast.success('মুছে ফেলা হয়েছে');
    }
    setDeleteOpen(false);
  };

  /* ═════════════════════════════════════════════════════════ */
  return (
    <div className="animate-fade-in-up space-y-6">
      {/* ── Page Header ─────────────────────────────────── */}
      <PageHeader
        title="বাজেট ও উন্নয়ন"
        description="বেতাগী উপজেলার বাজেট ও পরিচালন ও দেখুন।"
      >
        {canAdd && (
          <Button
            onClick={openAdd}
            className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white"
          >
            <Plus className="h-4 w-4 mr-1.5" />
            নতুন বাজেট
          </Button>
        )}
      </PageHeader>

      {/* ── 1. Summary Stat Cards ────────────────────────── */}
      <div className="grid sm:grid-cols-3 gap-4">
        {/* Total Budget */}
        <Card className="rounded-[12px] border shadow-sm hover:shadow-md transition-shadow duration-200">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-[10px] bg-slate-100 text-slate-600">
                  <Wallet className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-medium">
                    মোট বরাদ্দ
                  </p>
                  <p className="text-xl font-bold text-foreground mt-0.5">
                    ৳{bn(Math.round(totalAllocated / 10000000))} কোটি
                  </p>
                </div>
              </div>
            </div>
            {/* Thin orange accent line */}
            <div
              className="h-[3px] rounded-full w-full bg-muted/40 overflow-hidden"
            >
              <div
                className="h-full rounded-full"
                style={{
                  width: '100%',
                  backgroundColor: '#FF6B35',
                  opacity: 0.85,
                }}
              />
            </div>
            <p className="text-[11px] text-muted-foreground mt-2">
              অর্থবছর ২০২৪-২৫
            </p>
          </CardContent>
        </Card>

        {/* Total Spent */}
        <Card className="rounded-[12px] border shadow-sm hover:shadow-md transition-shadow duration-200">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-[10px] bg-orange-50 text-[#FF6B35]">
                  <TrendingUp className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-medium">
                    মোট ব্যয়
                  </p>
                  <p className="text-xl font-bold text-[#FF6B35] mt-0.5">
                    ৳{bn((totalSpent / 10000000).toFixed(1))} কোটি
                  </p>
                </div>
              </div>
              <span className="text-xs font-semibold text-[#FF6B35] bg-orange-50 px-2 py-0.5 rounded-full">
                {bn(overallPercent)}%
              </span>
            </div>
            {/* Thin orange accent progress */}
            <div
              className="h-[3px] rounded-full w-full bg-muted/40 overflow-hidden"
            >
              <div
                className="h-full rounded-full transition-all duration-700 ease-out"
                style={{
                  width: `${overallPercent}%`,
                  backgroundColor: '#FF6B35',
                  opacity: 0.85,
                }}
              />
            </div>
            <p className="text-[11px] text-muted-foreground mt-2">
              মোট বরাদ্দের {bn(overallPercent)}% ব্যয়িত
            </p>
          </CardContent>
        </Card>

        {/* Remaining */}
        <Card className="rounded-[12px] border shadow-sm hover:shadow-md transition-shadow duration-200">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-[10px] bg-emerald-50 text-emerald-600">
                  <PiggyBank className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-medium">
                    অবশিষ্ট অর্থ
                  </p>
                  <p className="text-xl font-bold text-emerald-600 mt-0.5">
                    ৳{bn((totalRemaining / 10000000).toFixed(1))} কোটি
                  </p>
                </div>
              </div>
              <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                {bn(100 - overallPercent)}%
              </span>
            </div>
            {/* Thin green accent progress */}
            <div
              className="h-[3px] rounded-full w-full bg-muted/40 overflow-hidden"
            >
              <div
                className="h-full rounded-full bg-emerald-500 transition-all duration-700 ease-out"
                style={{
                  width: `${100 - overallPercent}%`,
                }}
              />
            </div>
            <p className="text-[11px] text-muted-foreground mt-2">
              অর্থবছর শেষে ব্যবহারযোগ্য
            </p>
          </CardContent>
        </Card>
      </div>

      {/* ── 2. Category-wise Visual Bars ─────────────────── */}
      <Card className="rounded-[12px] border shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold text-foreground flex items-center gap-2">
            <IndianRupee className="h-4.5 w-4.5 text-muted-foreground" />
            বিভাগওয়ারী বাজেট বিবরণ
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          {data.map((item) => {
            const pct = Math.round((item.spent / item.allocated) * 100);
            const isGovt = isGovtCategory(item.category);
            const barColor = isGovt ? TEAL : ORANGE;
            const allocatedInCrore = item.allocated / 10000000;
            const spentInCrore = item.spent / 10000000;

            return (
              <div key={item.id}>
                {/* Category header */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="p-1.5 rounded-lg flex items-center justify-center"
                      style={{
                        backgroundColor: isGovt
                          ? 'rgba(30,177,177,0.10)'
                          : 'rgba(255,107,53,0.10)',
                        color: barColor,
                      }}
                    >
                      {CATEGORY_ICONS[item.category] || (
                        <IndianRupee className="h-4 w-4" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-foreground">
                        {item.category}
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {item.description}
                      </p>
                    </div>
                  </div>
                  {/* Percentage badge */}
                  <span
                    className="text-xs font-bold px-2.5 py-1 rounded-full"
                    style={{
                      backgroundColor: isGovt
                        ? 'rgba(30,177,177,0.10)'
                        : 'rgba(255,107,53,0.10)',
                      color: barColor,
                    }}
                  >
                    {bn(pct)}%
                  </span>
                </div>

                {/* Progress bar */}
                <ColorBar value={pct} color={barColor} h={8} />

                {/* Spent / Allocated label */}
                <div className="flex items-center justify-between mt-1.5">
                  <span className="text-[11px] text-muted-foreground">
                    ব্যয়: <span className="font-medium" style={{ color: barColor }}>৳{bn(spentInCrore.toFixed(1))} কোটি</span>
                  </span>
                  <span className="text-[11px] text-muted-foreground">
                    বরাদ্দ: <span className="font-medium text-foreground">৳{bn(allocatedInCrore.toFixed(0))} কোটি</span>
                  </span>
                </div>

                {/* Separator */}
                <div className="border-t border-dashed border-border/50 mt-4" />
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* ── 3. Overall Budget Progress ───────────────────── */}
      <Card className="rounded-[12px] border shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold text-foreground flex items-center gap-2">
            <TrendingUp className="h-4.5 w-4.5 text-muted-foreground" />
            সামগ্রিক বাজেট অগ্রগতি
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Large overall progress using shadcn Progress */}
          <div className="relative">
            <Progress value={overallPercent} className="h-5 w-full" />
            {/* Centered label inside progress */}
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-xs font-bold text-foreground drop-shadow-sm">
                {bn(overallPercent)}% সম্পন্ন
              </span>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-3 gap-3 pt-1">
            <div className="text-center">
              <p className="text-[11px] text-muted-foreground">মোট বরাদ্দ</p>
              <p className="text-sm font-bold text-foreground mt-0.5">
                ৳{bn(Math.round(totalAllocated / 10000000))} কোটি
              </p>
            </div>
            <div className="text-center">
              <p className="text-[11px] text-muted-foreground">ব্যয়িত</p>
              <p className="text-sm font-bold text-[#FF6B35] mt-0.5">
                ৳{bn((totalSpent / 10000000).toFixed(1))} কোটি
              </p>
            </div>
            <div className="text-center">
              <p className="text-[11px] text-muted-foreground">অবশিষ্ট</p>
              <p className="text-sm font-bold text-emerald-600 mt-0.5">
                ৳{bn((totalRemaining / 10000000).toFixed(1))} কোটি
              </p>
            </div>
          </div>

          {/* Color legend */}
          <div className="flex items-center gap-4 pt-2 border-t border-border/40">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: TEAL }} />
              <span className="text-[11px] text-muted-foreground">সরকারি সেবা</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: ORANGE }} />
              <span className="text-[11px] text-muted-foreground">অন্যান্য</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ── CRUD Actions per item (edit / delete buttons) ── */}
      {(canEdit || canDelete) && (
        <Card className="rounded-[12px] border shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold text-foreground">
              দ্রুত পরিচালনা
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {data.map((item) => {
                const pct = Math.round((item.spent / item.allocated) * 100);
                return (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-3 rounded-[10px] bg-muted/30 hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                        style={{
                          backgroundColor: isGovtCategory(item.category)
                            ? TEAL
                            : ORANGE,
                        }}
                      />
                      <div>
                        <p className="text-sm font-medium text-foreground">
                          {item.category}
                        </p>
                        <p className="text-[11px] text-muted-foreground">
                          ৳{bn((item.spent / 10000000).toFixed(1))} / ৳
                          {bn(Math.round(item.allocated / 10000000))} কোটি
                          &nbsp;·&nbsp;
                          <span className="font-medium" style={{ color: isGovtCategory(item.category) ? TEAL : ORANGE }}>
                            {bn(pct)}%
                          </span>
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      {canEdit && (
                        <button
                          onClick={() => openEdit(item)}
                          className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                          title="সম্পাদনা"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                      )}
                      {canDelete && (
                        <button
                          onClick={() => {
                            setEditItem(item);
                            setDeleteOpen(true);
                          }}
                          className="p-1.5 rounded-[8px] hover:bg-red-50 text-muted-foreground hover:text-red-600 transition-colors"
                          title="মুছুন"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ── Add / Edit Dialog ────────────────────────────── */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="rounded-[12px] max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editItem ? 'বাজেট সম্পাদনা' : 'নতুন বাজেট আইটেম'}
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="space-y-2 col-span-2">
              <Label>বিভাগ</Label>
              <Input
                value={form.category}
                onChange={(e) =>
                  setForm({ ...form, category: e.target.value })
                }
                placeholder="বাজেট বিভাগ"
                className="rounded-[12px]"
              />
            </div>
            <div className="space-y-2">
              <Label>বরাদ্দ (৳)</Label>
              <Input
                type="number"
                value={form.allocated}
                onChange={(e) =>
                  setForm({ ...form, allocated: Number(e.target.value) })
                }
                className="rounded-[12px]"
              />
            </div>
            <div className="space-y-2">
              <Label>ব্যয় (৳)</Label>
              <Input
                type="number"
                value={form.spent}
                onChange={(e) =>
                  setForm({ ...form, spent: Number(e.target.value) })
                }
                className="rounded-[12px]"
              />
            </div>
            <div className="space-y-2">
              <Label>অর্থবছর</Label>
              <Input
                value={form.fiscalYear}
                onChange={(e) =>
                  setForm({ ...form, fiscalYear: e.target.value })
                }
                placeholder="2024-2025"
                className="rounded-[12px]"
              />
            </div>
            <div className="space-y-2">
              <Label>বিবরণ</Label>
              <Input
                value={form.description}
                onChange={(e) =>
                  setForm({ ...form, description: e.target.value })
                }
                placeholder="বিবরণ"
                className="rounded-[12px]"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDialogOpen(false)}
              className="rounded-[12px]"
            >
              বাতিল
            </Button>
            <Button
              onClick={handleSave}
              className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white"
            >
              সংরক্ষণ করুন
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Delete Confirmation ───────────────────────────── */}
      <ConfirmDialog
        open={deleteOpen}
        onOpenChange={setDeleteOpen}
        title="বাজেট আইটেম মুছুন"
        description="আপনি কি এই বাজেট আইটেম মুছে ফেলতে চান?"
        onConfirm={handleDelete}
      />
    </div>
  );
}
