'use client';

import React, { useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { MOCK_OFFICERS } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, DataTable, StatusBadge, ConfirmDialog } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import type { GovtOfficer } from '@/types/admin';

export default function OfficersPage() {
  const { hasPermission } = useAuthStore();
  const [data, setData] = useState<GovtOfficer[]>(MOCK_OFFICERS);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editItem, setEditItem] = useState<GovtOfficer | null>(null);
  const [form, setForm] = useState({ name: '', designation: '', department: '', phone: '', email: '', office: '', address: '' });

  const canAdd = hasPermission('officers', 'add');
  const canEdit = hasPermission('officers', 'edit');
  const canDelete = hasPermission('officers', 'delete');

  const openAdd = () => { setEditItem(null); setForm({ name: '', designation: '', department: '', phone: '', email: '', office: '', address: '' }); setDialogOpen(true); };
  const openEdit = (item: GovtOfficer) => { setEditItem(item); setForm({ name: item.name, designation: item.designation, department: item.department, phone: item.phone, email: item.email || '', office: item.office || '', address: item.address || '' }); setDialogOpen(true); };

  const handleSave = () => {
    if (!form.name || !form.designation) { toast.error('নাম ও পদবি দিন'); return; }
    if (editItem) {
      setData(prev => prev.map(o => o.id === editItem.id ? { ...o, ...form } : o));
      toast.success('তথ্য আপডেট হয়েছে');
    } else {
      setData(prev => [...prev, { id: Date.now(), ...form, status: 'সক্রিয়', createdAt: new Date().toISOString().slice(0, 10) }]);
      toast.success('নতুন কর্মকর্তা যোগ হয়েছে');
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (editItem) { setData(prev => prev.filter(o => o.id !== editItem.id)); toast.success('কর্মকর্তা মুছে ফেলা হয়েছে'); }
    setDeleteOpen(false);
  };

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="সরকারি কর্মকর্তা" description="বেতাগী উপজেলার সরকারি কর্মকর্তাদের তথ্য ব্যবস্থাপনা">
        {canAdd && <Button onClick={openAdd} className="rounded-[12px] bg-[#1eb1b1] hover:bg-[#189696] text-white"><Plus className="h-4 w-4 mr-1.5" />নতুন কর্মকর্তা</Button>}
      </PageHeader>
      <DataTable
        headers={['#', 'নাম', 'পদবি', 'বিভাগ', 'ফোন', 'অবস্থা', (canEdit || canDelete) ? 'অ্যাকশন' : '']}
        data={data}
        searchKeys={['name', 'designation', 'department']}
        searchPlaceholder="কর্মকর্তা খুঁজুন..."
        emptyMessage="কোনো কর্মকর্তা পাওয়া যায়নি"
        exportConfig={{
          filename: 'সরকারি_কর্মকর্তা',
          columns: [
            { key: 'id', label: 'ক্রমিক' },
            { key: 'name', label: 'নাম' },
            { key: 'designation', label: 'পদবি' },
            { key: 'department', label: 'বিভাগ' },
            { key: 'phone', label: 'ফোন' },
            { key: 'email', label: 'ইমেইল' },
            { key: 'office', label: 'অফিস' },
            { key: 'status', label: 'অবস্থা' },
          ],
        }}
        renderRow={(item: GovtOfficer) => (
          <tr key={item.id} className="hover:bg-muted/50 transition-colors">
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.id}</td>
            <td className="px-4 py-3 text-sm font-medium">{item.name}</td>
            <td className="px-4 py-3 text-sm">{item.designation}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.department}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.phone}</td>
            <td className="px-4 py-3"><StatusBadge status={item.status} /></td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-1">
                {canEdit && <button onClick={() => openEdit(item)} className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>}
                {canDelete && <button onClick={() => { setEditItem(item); setDeleteOpen(true); }} className="p-1.5 rounded-[8px] hover:bg-red-50 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>}
              </div>
            </td>
          </tr>
        )}
      />
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="rounded-[12px] max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'কর্মকর্তার তথ্য সম্পাদনা' : 'নতুন কর্মকর্তা যোগ করুন'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="space-y-2 col-span-2"><Label>নাম</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="পুরো নাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>পদবি</Label><Input value={form.designation} onChange={e => setForm({ ...form, designation: e.target.value })} placeholder="পদবি" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>বিভাগ</Label><Input value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} placeholder="বিভাগ" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>ফোন</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="ফোন নম্বর" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>ইমেইল</Label><Input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="ইমেইল" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>অফিস</Label><Input value={form.office} onChange={e => setForm({ ...form, office: e.target.value })} placeholder="অফিসের নাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>ঠিকানা</Label><Input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="ঠিকানা" className="rounded-[12px]" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-[12px]">বাতিল</Button>
            <Button onClick={handleSave} className="rounded-[12px] bg-[#1eb1b1] hover:bg-[#189696] text-white">সংরক্ষণ করুন</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={deleteOpen} onOpenChange={setDeleteOpen} title="কর্মকর্তা মুছুন" description="আপনি কি এই কর্মকর্তার তথ্য মুছে ফেলতে চান?" onConfirm={handleDelete} />
    </div>
  );
}