'use client';

import React, { useState } from 'react';
import { Plus, Pencil, Trash2, Award } from 'lucide-react';
import { MOCK_PERSONS, PERSON_CATEGORIES } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, DataTable, StatusBadge, ConfirmDialog } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import type { Person } from '@/types/admin';

export default function PersonsPage() {
  const { hasPermission } = useAuthStore();
  const [data, setData] = useState<Person[]>(MOCK_PERSONS);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editItem, setEditItem] = useState<Person | null>(null);
  const [form, setForm] = useState({ name: '', designation: '', category: '', phone: '', address: '', details: '' });

  const canAdd = hasPermission('persons', 'add');
  const canEdit = hasPermission('persons', 'edit');
  const canDelete = hasPermission('persons', 'delete');

  const openAdd = () => { setEditItem(null); setForm({ name: '', designation: '', category: '', phone: '', address: '', details: '' }); setDialogOpen(true); };
  const openEdit = (item: Person) => { setEditItem(item); setForm({ name: item.name, designation: item.designation || '', category: item.category, phone: item.phone || '', address: item.address || '', details: item.details || '' }); setDialogOpen(true); };
  const handleSave = () => {
    if (!form.name || !form.category) { toast.error('নাম ও বিভাগ দিন'); return; }
    if (editItem) { setData(prev => prev.map(p => p.id === editItem.id ? { ...p, ...form } : p)); toast.success('তথ্য আপডেট হয়েছে'); }
    else { setData(prev => [...prev, { id: Date.now(), ...form, status: 'সক্রিয়', createdAt: new Date().toISOString().slice(0, 10) }]); toast.success('নতুন ব্যক্তি যোগ হয়েছে'); }
    setDialogOpen(false);
  };
  const handleDelete = () => { if (editItem) { setData(prev => prev.filter(p => p.id !== editItem.id)); toast.success('মুছে ফেলা হয়েছে'); } setDeleteOpen(false); };

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="বিশিষ্ট ব্যক্তি" description="বেতাগীর বিশিষ্ট ব্যক্তিদের তথ্য ব্যবস্থাপনা">
        {canAdd && <Button onClick={openAdd} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white"><Plus className="h-4 w-4 mr-1.5" />নতুন ব্যক্তি</Button>}
      </PageHeader>
      <DataTable
        headers={['#', 'নাম', 'পদবি', 'বিভাগ', 'ফোন', 'ঠিকানা', 'অবস্থা', (canEdit || canDelete) ? 'অ্যাকশন' : '']}
        data={data}
        searchKeys={['name', 'designation', 'category']}
        searchPlaceholder="ব্যক্তি খুঁজুন..."
        emptyMessage="কোনো ব্যক্তি পাওয়া যায়নি"
        exportConfig={{
          filename: 'বিশিষ্ট_ব্যক্তি',
          columns: [
            { key: 'id', label: 'ক্রমিক' },
            { key: 'name', label: 'নাম' },
            { key: 'designation', label: 'পদবি' },
            { key: 'category', label: 'বিভাগ' },
            { key: 'phone', label: 'ফোন' },
            { key: 'status', label: 'অবস্থা' },
          ],
        }}
        renderRow={(item: Person) => (
          <tr key={item.id} className="hover:bg-muted/50 transition-colors">
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.id}</td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-violet-50 text-violet-600 flex items-center justify-center flex-shrink-0"><Award className="h-4 w-4" /></div>
                <span className="text-sm font-medium">{item.name}</span>
              </div>
            </td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.designation || '-'}</td>
            <td className="px-4 py-3 text-sm">{item.category}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.phone || '-'}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground max-w-[180px] truncate">{item.address || '-'}</td>
            <td className="px-4 py-3"><StatusBadge status={item.status} /></td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-1">
                {canEdit && <button onClick={() => openEdit(item)} className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>}
                {canDelete && <button onClick={() => { setEditItem(item); setDeleteOpen(true); }} className="p-1.5 rounded-[8px] hover:bg-red-50 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>}
              </div>
            </td>
          </tr>
        )}
      />
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="rounded-[12px] max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'ব্যক্তি সম্পাদনা' : 'নতুন ব্যক্তি যোগ করুন'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="space-y-2 col-span-2"><Label>নাম</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="পুরো নাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>পদবি</Label><Input value={form.designation} onChange={e => setForm({ ...form, designation: e.target.value })} placeholder="পদবি" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>বিভাগ</Label>
              <Select value={form.category} onValueChange={v => setForm({ ...form, category: v })}>
                <SelectTrigger className="rounded-[12px]"><SelectValue placeholder="বিভাগ নির্বাচন" /></SelectTrigger>
                <SelectContent>{PERSON_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>ফোন</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="ফোন নম্বর" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>ঠিকানা</Label><Input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="ঠিকানা" className="rounded-[12px]" /></div>
            <div className="space-y-2 col-span-2"><Label>বিবরণ</Label><Textarea value={form.details} onChange={e => setForm({ ...form, details: e.target.value })} placeholder="বিস্তারিত" rows={2} className="rounded-[12px]" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-[12px]">বাতিল</Button>
            <Button onClick={handleSave} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white">সংরক্ষণ করুন</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={deleteOpen} onOpenChange={setDeleteOpen} title="ব্যক্তি মুছুন" description="আপনি কি এই ব্যক্তির তথ্য মুছে ফেলতে চান?" onConfirm={handleDelete} />
    </div>
  );
}