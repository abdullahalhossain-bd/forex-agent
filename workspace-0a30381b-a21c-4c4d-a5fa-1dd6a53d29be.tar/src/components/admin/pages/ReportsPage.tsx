'use client';

import React, { useState } from 'react';
import {
  Users, MessageSquareWarning, CheckCircle2, Megaphone, Store, Droplets, Trophy,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PageHeader } from '@/components/admin/common/shared';

const PERIODS = ['চতুর্থাংশ', 'ত্রৈমাসিক', 'বার্ষিক', 'সব'] as const;

type Period = (typeof PERIODS)[number];

const SUMMARY_STATS = [
  { label: 'মোট নাগরিক', value: 15423, icon: Users, borderColor: 'border-l-orange-500', iconBg: 'bg-orange-100 text-orange-600', textColor: 'text-orange-600' },
  { label: 'সক্রিয় অভিযোগ', value: 23, icon: MessageSquareWarning, borderColor: 'border-l-red-500', iconBg: 'bg-red-100 text-red-600', textColor: 'text-red-600' },
  { label: 'সমাধান হার', value: 78, icon: CheckCircle2, borderColor: 'border-l-emerald-500', iconBg: 'bg-emerald-100 text-emerald-600', textColor: 'text-emerald-600', suffix: '%' },
  { label: 'নোটিশ প্রকাশিত', value: 45, icon: Megaphone, borderColor: 'border-l-teal-500', iconBg: 'bg-teal-100 text-teal-600', textColor: 'text-teal-600' },
  { label: 'ব্যবসা প্রতিষ্ঠান', value: 128, icon: Store, borderColor: 'border-l-amber-500', iconBg: 'bg-amber-100 text-amber-600', textColor: 'text-amber-600' },
  { label: 'রক্তদাতা', value: 85, icon: Droplets, borderColor: 'border-l-rose-500', iconBg: 'bg-rose-100 text-rose-600', textColor: 'text-rose-600' },
];

const COMPLAINT_TREND = [
  { month: 'জানুয়ারী', count: 28 },
  { month: 'ফেব্রুয়ারী', count: 22 },
  { month: 'মার্চ', count: 35 },
  { month: 'এপ্রিল', count: 18 },
  { month: 'মে', count: 42 },
  { month: 'জুন', count: 23 },
];

const MAX_COMPLAINT = 42;

const SERVICE_DISTRIBUTION = [
  { label: 'সরকারি সেবা', pct: 40, color: '#1eb1b1' },
  { label: 'স্বাস্থ্য সেবা', pct: 25, color: '#FF6B35' },
  { label: 'সম্প্রদায়', pct: 20, color: '#8B5CF6' },
  { label: 'প্রশাসন', pct: 15, color: '#EC4899' },
];

// Build conic-gradient stops
let cumDeg = 0;
const DONUT_GRADIENT = SERVICE_DISTRIBUTION.map(s => {
  const start = cumDeg;
  cumDeg += (s.pct / 100) * 360;
  return `${s.color} ${start}deg ${cumDeg}deg`;
}).join(', ');

const UNION_DATA = [
  { name: 'বেতাগী সদর', population: 4230, complaints: 8, rate: 85, business: 38 },
  { name: 'চরবাড়ি', population: 3180, complaints: 5, rate: 92, business: 22 },
  { name: 'পাতারহাট', population: 2850, complaints: 4, rate: 75, business: 28 },
  { name: 'হলদিয়া', population: 2540, complaints: 3, rate: 58, business: 18 },
  { name: 'কুকুটিয়া', population: 1560, complaints: 2, rate: 88, business: 12 },
  { name: 'বড়জালিয়া', population: 1063, complaints: 1, rate: 65, business: 10 },
];

const TOP_PERFORMERS = [
  { rank: 1, name: 'মোঃ আনোয়ার হোসেন', designation: 'উপজেলা নির্বাহী অফিসার', resolved: 45 },
  { rank: 2, name: 'মোঃ শফিকুল ইসলাম', designation: 'আইসিটি অফিসার', resolved: 38 },
  { rank: 3, name: 'মোসাঃ রেহানা বেগম', designation: 'উপজেলা কৃষি অফিসার', resolved: 31 },
];

const RANK_STYLES: Record<number, { bg: string; text: string; ring: string }> = {
  1: { bg: 'bg-amber-400', text: 'text-white', ring: 'ring-2 ring-amber-300' },
  2: { bg: 'bg-gray-300', text: 'text-gray-700', ring: 'ring-2 ring-gray-200' },
  3: { bg: 'bg-orange-400', text: 'text-white', ring: 'ring-2 ring-orange-300' },
};

function rateColor(rate: number): string {
  if (rate > 80) return 'bg-emerald-500';
  if (rate > 60) return 'bg-amber-500';
  return 'bg-red-500';
}

function rateTextColor(rate: number): string {
  if (rate > 80) return 'text-emerald-600';
  if (rate > 60) return 'text-amber-600';
  return 'text-red-600';
}

export default function ReportsPage() {
  const [period, setPeriod] = useState<Period>('সব');

  return (
    <div className="space-y-6">
      {/* 1. Page Header */}
      <PageHeader
        title='রিপোর্ট ও বিশ্লেষণ'
        description='বেতাগী উপজেলার পরিসংখ্যান ও বিশ্লেষণ'
      />

      {/* 2. Period Selector */}
      <div className="flex items-center gap-2 animate-fade-in-up">
        {PERIODS.map(p => (
          <button
            key={p}
            onClick={() => setPeriod(p)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
              period === p
                ? 'bg-[#FF6B35] text-white shadow-md shadow-[#FF6B35]/25'
                : 'bg-muted/60 text-muted-foreground hover:bg-muted'
            }`}
          >
            {p}
          </button>
        ))}
      </div>

      {/* 3. Summary Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 animate-fade-in-up">
        {SUMMARY_STATS.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <Card
              key={stat.label}
              className={`rounded-[12px] border-l-4 ${stat.borderColor} hover:shadow-md transition-shadow ${
                i === 0 ? 'relative overflow-hidden' : ''
              }`}
            >
              {i === 0 && (
                <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-[#FF6B35] to-[#FF6B35]/30 rounded-t-[12px]" />
              )}
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className={`p-2.5 rounded-[10px] ${stat.iconBg}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-2xl font-bold ${stat.textColor} tabular-nums`}>
                      {stat.suffix
                        ? stat.value.toLocaleString('bn-BD') + stat.suffix
                        : stat.value.toLocaleString('bn-BD')
                      }
                    </p>
                    <p className="text-sm text-muted-foreground mt-0.5">{stat.label}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* 4. Complaints Trend + 5. Service Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 animate-fade-in-up">
        {/* Complaints Trend Bar Chart */}
        <Card className="rounded-[12px]">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold">মাসিক অভিযোগ প্রবণতা</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0 space-y-3">
            {COMPLAINT_TREND.map(item => {
              const pct = (item.count / MAX_COMPLAINT) * 100;
              const barColor = item.count > 30 ? 'bg-[#FF6B35]' : 'bg-[#1eb1b1]';
              return (
                <div key={item.month} className="flex items-center gap-3">
                  <span className="text-sm text-muted-foreground w-24 flex-shrink-0 text-right">{item.month}</span>
                  <div className="flex-1 h-8 bg-muted/50 rounded-[6px] overflow-hidden">
                    <div
                      className={`h-full ${barColor} rounded-[6px] transition-all duration-700 flex items-center justify-end pr-2`}
                      style={{ width: `${pct}%` }}
                    >
                      <span className="text-xs font-bold text-white">{item.count.toLocaleString('bn-BD')}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* Service Distribution Donut Chart */}
        <Card className="rounded-[12px]">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold">সেবা বিতরণ</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <div className="flex flex-col items-center">
              {/* CSS donut chart */}
              <div className="relative w-40 h-40 mb-6">
                <div
                  className="w-full h-full rounded-full"
                  style={{
                    background: `conic-gradient(${DONUT_GRADIENT})`,
                  }}
                />
                {/* Inner white circle to create donut */}
                <div className="absolute inset-0 m-auto w-24 h-24 bg-white dark:bg-card rounded-full flex items-center justify-center">
                  <span className="text-lg font-bold text-foreground">১০০%</span>
                </div>
              </div>

              {/* Legend */}
              <div className="grid grid-cols-2 gap-x-6 gap-y-2 w-full">
                {SERVICE_DISTRIBUTION.map(s => (
                  <div key={s.label} className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full flex-shrink-0"
                      style={{ backgroundColor: s.color }}
                    />
                    <span className="text-sm text-muted-foreground">{s.label}</span>
                    <span className="text-sm font-semibold text-foreground ml-auto">{s.pct}%</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 6. Union-wise Data Table */}
      <Card className="rounded-[12px] animate-fade-in-up">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold">ইউনিয়নভিত্তিক তথ্য</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-muted/50">
                  <th className="text-left text-xs font-semibold text-muted-foreground uppercase p-3 rounded-l-[12px]">ইউনিয়ন</th>
                  <th className="text-left text-xs font-semibold text-muted-foreground uppercase p-3">জনসংখ্যা</th>
                  <th className="text-left text-xs font-semibold text-muted-foreground uppercase p-3">অভিযোগ</th>
                  <th className="text-left text-xs font-semibold text-muted-foreground uppercase p-3">সমাধান হার</th>
                  <th className="text-left text-xs font-semibold text-muted-foreground uppercase p-3 rounded-r-[12px]">ব্যবসা</th>
                </tr>
              </thead>
              <tbody>
                {UNION_DATA.map((row) => (
                  <tr
                    key={row.name}
                    className="border-b last:border-b-0 hover:bg-muted/30 transition-colors duration-150"
                  >
                    <td className="p-3 text-sm font-medium">{row.name}</td>
                    <td className="p-3 text-sm tabular-nums">{row.population.toLocaleString('bn-BD')}</td>
                    <td className="p-3 text-sm tabular-nums">{row.complaints.toLocaleString('bn-BD')}</td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 max-w-[100px] h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${rateColor(row.rate)}`}
                            style={{ width: `${row.rate}%` }}
                          />
                        </div>
                        <span className={`text-xs font-semibold ${rateTextColor(row.rate)} tabular-nums w-10`}>{row.rate}%</span>
                      </div>
                    </td>
                    <td className="p-3 text-sm tabular-nums">{row.business.toLocaleString('bn-BD')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* 7. Top Performers */}
      <Card className="rounded-[12px] animate-fade-in-up">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <Trophy className="h-5 w-5 text-amber-500" />
            শীর্ষ কর্মকর্তা
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0 space-y-3">
          {TOP_PERFORMERS.map(officer => {
            const style = RANK_STYLES[officer.rank];
            return (
              <div
                key={officer.rank}
                className="flex items-center gap-4 p-3 rounded-[10px] bg-muted/30 hover:bg-muted/50 transition-colors"
              >
                <div className={`w-8 h-8 rounded-full ${style.bg} ${style.text} ${style.ring} flex items-center justify-center text-sm font-bold flex-shrink-0`}>
                  {officer.rank.toLocaleString('bn-BD')}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">{officer.name}</p>
                  <p className="text-xs text-muted-foreground">{officer.designation}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-lg font-bold text-[#FF6B35] tabular-nums">{officer.resolved.toLocaleString('bn-BD')}</p>
                  <p className="text-[10px] text-muted-foreground">সমাধানকৃত</p>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
