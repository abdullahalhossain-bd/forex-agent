'use client';

import React, { useState } from 'react';
import { Plus, Trash2, Bell, Check, CheckCheck } from 'lucide-react';
import { MOCK_NOTIFICATIONS, NOTIFICATION_TYPES } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, StatusBadge, ConfirmDialog } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import type { Notification } from '@/types/admin';

export default function NotificationsPage() {
  const { hasPermission, user } = useAuthStore();
  const [data, setData] = useState<Notification[]>(MOCK_NOTIFICATIONS);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editItem, setEditItem] = useState<Notification | null>(null);
  const [form, setForm] = useState({ title: '', message: '', type: 'সাধারণ' as Notification['type'], targetRole: 'সবাই' as string });

  const canAdd = hasPermission('notifications', 'add');
  const canDelete = hasPermission('notifications', 'delete');

  const openAdd = () => { setEditItem(null); setForm({ title: '', message: '', type: 'সাধারণ', targetRole: 'সবাই' }); setDialogOpen(true); };
  const handleSave = () => {
    if (!form.title || !form.message) { toast.error('শিরোনাম ও বার্তা দিন'); return; }
    setData(prev => [{ id: Date.now(), ...form, isRead: false, createdAt: new Date().toISOString() }, ...prev]);
    toast.success('নতুন নোটিফিকেশন পাঠানো হয়েছে');
    setDialogOpen(false);
  };
  const handleDelete = () => { if (editItem) { setData(prev => prev.filter(n => n.id !== editItem.id)); toast.success('মুছে ফেলা হয়েছে'); } setDeleteOpen(false); };
  const markRead = (id: number) => { setData(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n)); };
  const markAllRead = () => { setData(prev => prev.map(n => ({ ...n, isRead: true }))); toast.success('সব নোটিফিকেশন পড়া হয়েছে'); };

  const typeIcons: Record<string, string> = { 'তথ্য': 'bg-blue-50 text-blue-600', 'সতর্কতা': 'bg-amber-50 text-amber-600', 'জরুরি': 'bg-red-50 text-red-600', 'সাধারণ': 'bg-gray-50 text-gray-600' };

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="নোটিফিকেশন" description="নোটিফিকেশন পরিচালনা ও পাঠানো">
        {canAdd && <Button onClick={openAdd} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white"><Plus className="h-4 w-4 mr-1.5" />নতুন নোটিফিকেশন</Button>}
      </PageHeader>

      {data.some(n => !n.isRead) && (
        <div className="mb-4"><Button onClick={markAllRead} variant="outline" size="sm" className="rounded-[12px] text-xs"><CheckCheck className="h-3.5 w-3.5 mr-1.5" />সব পড়া হয়েছে হিসেবে চিহ্নিত</Button></div>
      )}

      <div className="space-y-3">
        {data.length === 0 ? <div className="text-center py-16 text-muted-foreground">কোনো নোটিফিকেশন নেই</div> : data.map(n => (
          <Card key={n.id} className={`rounded-[12px] border transition-all ${!n.isRead ? 'border-l-4 border-l-[#FF6B35]' : ''}`}>
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-[10px] mt-0.5 ${typeIcons[n.type] || typeIcons['সাধারণ']}`}>
                  <Bell className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className={`text-sm ${!n.isRead ? 'font-semibold' : 'font-medium'}`}>{n.title}</p>
                    {!n.isRead && <span className="w-2 h-2 rounded-full bg-[#FF6B35] animate-pulse-dot" />}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{n.message}</p>
                  <div className="flex items-center gap-3 mt-2">
                    <StatusBadge status={n.type} />
                    <span className="text-xs text-muted-foreground">{new Date(n.createdAt).toLocaleDateString('bn-BD')}</span>
                    {n.targetRole && <span className="text-xs text-muted-foreground">লক্ষ্য: {n.targetRole}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  {!n.isRead && <button onClick={() => markRead(n.id)} className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground" title="পড়া হয়েছে"><Check className="h-4 w-4" /></button>}
                  {canDelete && <button onClick={() => { setEditItem(n); setDeleteOpen(true); }} className="p-1.5 rounded-[8px] hover:bg-red-50 text-muted-foreground hover:text-red-600"><Trash2 className="h-4 w-4" /></button>}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="rounded-[12px] max-w-lg">
          <DialogHeader><DialogTitle>নতুন নোটিফিকেশন পাঠান</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2"><Label>শিরোনাম</Label><Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="শিরোনাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>বার্তা</Label><Textarea value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} placeholder="বার্তা লিখুন" rows={3} className="rounded-[12px]" /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>ধরন</Label>
                <Select value={form.type} onValueChange={v => setForm({ ...form, type: v as Notification['type'] })}>
                  <SelectTrigger className="rounded-[12px]"><SelectValue /></SelectTrigger>
                  <SelectContent>{NOTIFICATION_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2"><Label>লক্ষ্য ভূমিকা</Label>
                <Select value={form.targetRole} onValueChange={v => setForm({ ...form, targetRole: v })}>
                  <SelectTrigger className="rounded-[12px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="সবাই">সবাই</SelectItem>
                    <SelectItem value="admin">অ্যাডমিন</SelectItem>
                    <SelectItem value="uno">ইউএনও</SelectItem>
                    <SelectItem value="ict">আইসিটি</SelectItem>
                    <SelectItem value="developer">ডেভেলপার</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-[12px]">বাতিল</Button>
            <Button onClick={handleSave} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white">পাঠান</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={deleteOpen} onOpenChange={setDeleteOpen} title="নোটিফিকেশন মুছুন" description="আপনি কি এই নোটিফিকেশন মুছে ফেলতে চান?" onConfirm={handleDelete} />
    </div>
  );
}