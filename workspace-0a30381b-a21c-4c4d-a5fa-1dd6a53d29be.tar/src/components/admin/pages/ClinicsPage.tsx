'use client';

import React, { useState } from 'react';
import { Plus, Pencil, Trash2, MapPin } from 'lucide-react';
import { MOCK_CLINICS } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, DataTable, StatusBadge, ConfirmDialog } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import type { Clinic } from '@/types/admin';

export default function ClinicsPage() {
  const { hasPermission } = useAuthStore();
  const [data, setData] = useState<Clinic[]>(MOCK_CLINICS);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editItem, setEditItem] = useState<Clinic | null>(null);
  const [form, setForm] = useState({ name: '', type: '', address: '', phone: '', doctorName: '', specialization: '', schedule: '' });

  const canAdd = hasPermission('clinics', 'add');
  const canEdit = hasPermission('clinics', 'edit');
  const canDelete = hasPermission('clinics', 'delete');

  const openAdd = () => { setEditItem(null); setForm({ name: '', type: '', address: '', phone: '', doctorName: '', specialization: '', schedule: '' }); setDialogOpen(true); };
  const openEdit = (item: Clinic) => { setEditItem(item); setForm({ name: item.name, type: item.type, address: item.address, phone: item.phone, doctorName: item.doctorName || '', specialization: item.specialization || '', schedule: item.schedule || '' }); setDialogOpen(true); };
  const handleSave = () => {
    if (!form.name || !form.address) { toast.error('নাম ও ঠিকানা দিন'); return; }
    if (editItem) { setData(prev => prev.map(c => c.id === editItem.id ? { ...c, ...form } : c)); toast.success('ক্লিনিক আপডেট হয়েছে'); }
    else { setData(prev => [...prev, { id: Date.now(), ...form, status: 'সক্রিয়', createdAt: new Date().toISOString().slice(0, 10) }]); toast.success('নতুন ক্লিনিক যোগ হয়েছে'); }
    setDialogOpen(false);
  };
  const handleDelete = () => { if (editItem) { setData(prev => prev.filter(c => c.id !== editItem.id)); toast.success('ক্লিনিক মুছে ফেলা হয়েছে'); } setDeleteOpen(false); };

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="ক্লিনিক/হাসপাতাল" description="স্বাস্থ্য সেবা প্রতিষ্ঠানের তথ্য ব্যবস্থাপনা">
        {canAdd && <Button onClick={openAdd} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white"><Plus className="h-4 w-4 mr-1.5" />নতুন ক্লিনিক</Button>}
      </PageHeader>
      <DataTable
        headers={['#', 'নাম', 'ধরন', 'ঠিকানা', 'ফোন', 'চিকিৎসক', 'সূচি', 'অবস্থা', (canEdit || canDelete) ? 'অ্যাকশন' : '']}
        data={data}
        searchKeys={['name', 'type', 'address']}
        searchPlaceholder="ক্লিনিক খুঁজুন..."
        emptyMessage="কোনো ক্লিনিক পাওয়া যায়নি"
        exportConfig={{
          filename: 'ক্লিনিক',
          columns: [
            { key: 'id', label: 'ক্রমিক' },
            { key: 'name', label: 'নাম' },
            { key: 'type', label: 'ধরন' },
            { key: 'address', label: 'ঠিকানা' },
            { key: 'phone', label: 'ফোন' },
            { key: 'status', label: 'অবস্থা' },
          ],
        }}
        renderRow={(item: Clinic) => (
          <tr key={item.id} className="hover:bg-muted/50 transition-colors">
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.id}</td>
            <td className="px-4 py-3 text-sm font-medium">{item.name}</td>
            <td className="px-4 py-3"><span className={`text-xs px-2 py-1 rounded-full ${item.type === 'সরকারি' ? 'bg-teal-50 text-teal-700' : 'bg-orange-50 text-orange-700'}`}>{item.type}</span></td>
            <td className="px-4 py-3 text-sm text-muted-foreground max-w-[180px] truncate flex items-center gap-1"><MapPin className="h-3 w-3 flex-shrink-0" />{item.address}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.phone}</td>
            <td className="px-4 py-3 text-sm">{item.doctorName || '-'}</td>
            <td className="px-4 py-3 text-xs text-muted-foreground max-w-[150px] truncate">{item.schedule || '-'}</td>
            <td className="px-4 py-3"><StatusBadge status={item.status} /></td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-1">
                {canEdit && <button onClick={() => openEdit(item)} className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>}
                {canDelete && <button onClick={() => { setEditItem(item); setDeleteOpen(true); }} className="p-1.5 rounded-[8px] hover:bg-red-50 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>}
              </div>
            </td>
          </tr>
        )}
      />
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="rounded-[12px] max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'ক্লিনিক সম্পাদনা' : 'নতুন ক্লিনিক যোগ করুন'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="space-y-2 col-span-2"><Label>নাম</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="ক্লিনিক/হাসপাতালের নাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>ধরন</Label><Input value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} placeholder="সরকারি/বেসরকারি" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>ফোন</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="ফোন নম্বর" className="rounded-[12px]" /></div>
            <div className="space-y-2 col-span-2"><Label>ঠিকানা</Label><Input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="সম্পূর্ণ ঠিকানা" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>চিকিৎসক</Label><Input value={form.doctorName} onChange={e => setForm({ ...form, doctorName: e.target.value })} placeholder="চিকিৎসকের নাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>বিশেষজ্ঞতা</Label><Input value={form.specialization} onChange={e => setForm({ ...form, specialization: e.target.value })} placeholder="বিশেষজ্ঞতা" className="rounded-[12px]" /></div>
            <div className="space-y-2 col-span-2"><Label>সূচি</Label><Input value={form.schedule} onChange={e => setForm({ ...form, schedule: e.target.value })} placeholder="সপ্তাহের দিন ও সময়" className="rounded-[12px]" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-[12px]">বাতিল</Button>
            <Button onClick={handleSave} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white">সংরক্ষণ করুন</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={deleteOpen} onOpenChange={setDeleteOpen} title="ক্লিনিক মুছুন" description="আপনি কি এই ক্লিনিকের তথ্য মুছে ফেলতে চান?" onConfirm={handleDelete} />
    </div>
  );
}