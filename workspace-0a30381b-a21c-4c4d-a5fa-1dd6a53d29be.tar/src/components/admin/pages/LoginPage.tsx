'use client';

import React, { useState, useEffect } from 'react';
import { Zap, Eye, EyeOff, Loader2, Shield, UserCog, Monitor, Code, LandPlot } from 'lucide-react';
import { useAuthStore, useNavStore } from '@/stores/admin';
import { MOCK_USERS } from '@/lib/mock-data';
import { ROLE_LABELS, type UserRole } from '@/types/admin';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

const DEMO_ACCOUNTS = [
  {
    email: 'admin@betagi.gov.bd',
    password: 'admin',
    role: 'admin' as UserRole,
    label: 'সুপার অ্যাডমিন',
    desc: 'সম্পূর্ণ অ্যাক্সেস',
    borderColor: 'border-l-[#FF6B35]',
    icon: Shield,
    hoverBg: 'hover:bg-orange-50/80',
    textColor: 'text-[#FF6B35]',
    descColor: 'text-orange-600/60',
  },
  {
    email: 'uno@betagi.gov.bd',
    password: 'uno',
    role: 'uno' as UserRole,
    label: 'উপজেলা নির্বাহী অফিসার',
    desc: 'সম্পূর্ণ অ্যাক্সেস',
    borderColor: 'border-l-emerald-500',
    icon: UserCog,
    hoverBg: 'hover:bg-emerald-50/80',
    textColor: 'text-emerald-600',
    descColor: 'text-emerald-500/60',
  },
  {
    email: 'ict@betagi.gov.bd',
    password: 'ict',
    role: 'ict' as UserRole,
    label: 'আইসিটি অফিসার',
    desc: 'কন্টেন্ট ব্যবস্থাপনা',
    borderColor: 'border-l-sky-500',
    icon: Monitor,
    hoverBg: 'hover:bg-sky-50/80',
    textColor: 'text-sky-600',
    descColor: 'text-sky-500/60',
  },
  {
    email: 'dev@betagi.gov.bd',
    password: 'dev',
    role: 'developer' as UserRole,
    label: 'ডেভেলপার',
    desc: 'ডেটা ব্যবস্থাপনা',
    borderColor: 'border-l-violet-500',
    icon: Code,
    hoverBg: 'hover:bg-violet-50/80',
    textColor: 'text-violet-600',
    descColor: 'text-violet-500/60',
  },
  {
    email: 'acland@betagi.gov.bd',
    password: 'acland',
    role: 'acLand' as UserRole,
    label: 'সহকারী কমিশনার (ভূমি)',
    desc: 'ভূমি ও সেবা ব্যবস্থাপনা',
    borderColor: 'border-l-amber-500',
    icon: LandPlot,
    hoverBg: 'hover:bg-amber-50/80',
    textColor: 'text-amber-600',
    descColor: 'text-amber-500/60',
  },
];

export default function LoginPage() {
  const { login, isAuthenticated } = useAuthStore();
  const { navigate } = useNavStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isAuthenticated) navigate('dashboard');
  }, [isAuthenticated, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error('ইমেইল এবং পাসওয়ার্ড দিন');
      return;
    }
    setLoading(true);
    await new Promise(r => setTimeout(r, 800));
    const user = MOCK_USERS.find(u => u.email === email);
    if (user) {
      login(user, 'mock-jwt-token-' + Date.now());
      toast.success('সফলভাবে লগইন হয়েছে');
    } else {
      toast.error('ইমেইল বা পাসওয়ার্ড সঠিক নয়');
    }
    setLoading(false);
  };

  const quickLogin = (account: typeof DEMO_ACCOUNTS[0]) => {
    setEmail(account.email);
    setPassword(account.password);
    const user = MOCK_USERS.find(u => u.email === account.email);
    if (user) {
      login(user, 'mock-jwt-token-' + Date.now());
      toast.success(`${ROLE_LABELS[user.role]} হিসেবে লগইন হয়েছে`);
    }
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* ========== LEFT DECORATIVE PANEL (hidden on mobile) ========== */}
      <div
        className="hidden lg:flex lg:w-[52%] relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 40%, #0f3460 100%)',
        }}
      >
        {/* Geometric pattern overlay - CSS only repeating pattern */}
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: [
              'repeating-linear-gradient(0deg, transparent, transparent 40px, rgba(255, 107, 53, 0.03) 40px, rgba(255, 107, 53, 0.03) 41px)',
              'repeating-linear-gradient(90deg, transparent, transparent 40px, rgba(255, 107, 53, 0.03) 40px, rgba(255, 107, 53, 0.03) 41px)',
              'repeating-linear-gradient(45deg, transparent, transparent 56px, rgba(255, 255, 255, 0.012) 56px, rgba(255, 255, 255, 0.012) 57px)',
              'repeating-linear-gradient(-45deg, transparent, transparent 56px, rgba(255, 255, 255, 0.012) 56px, rgba(255, 255, 255, 0.012) 57px)',
            ].join(', '),
          }}
        />

        {/* Diagonal accent stripes */}
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              'linear-gradient(135deg, rgba(255, 107, 53, 0.06) 25%, transparent 25%, transparent 50%, rgba(255, 107, 53, 0.04) 50%, rgba(255, 107, 53, 0.04) 75%, transparent 75%)',
            backgroundSize: '80px 80px',
          }}
        />

        {/* Floating decorative orbs with low opacity */}
        <div
          className="absolute top-[12%] left-[10%] w-48 h-48 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(255, 107, 53, 0.06) 0%, transparent 70%)',
            animation: 'loginFloat 8s ease-in-out infinite',
          }}
        />
        <div
          className="absolute bottom-[18%] right-[12%] w-72 h-72 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(255, 107, 53, 0.04) 0%, transparent 70%)',
            animation: 'loginFloat 10s ease-in-out infinite 2s',
          }}
        />
        <div
          className="absolute top-[55%] left-[45%] w-36 h-36 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(255, 255, 255, 0.03) 0%, transparent 70%)',
            animation: 'loginFloat 7s ease-in-out infinite 1s',
          }}
        />
        <div
          className="absolute top-[8%] right-[20%] w-24 h-24 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(30, 177, 177, 0.06) 0%, transparent 70%)',
            animation: 'loginFloat 9s ease-in-out infinite 3s',
          }}
        />
        <div
          className="absolute bottom-[10%] left-[30%] w-28 h-28 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(255, 107, 53, 0.04) 0%, transparent 70%)',
            animation: 'loginFloat 11s ease-in-out infinite 4s',
          }}
        />

        {/* Content centered in left panel */}
        <div className="relative z-10 flex flex-col items-center justify-center w-full px-12 text-center">
          {/* Upazila emblem / logo mark */}
          <div
            className="w-20 h-20 rounded-2xl bg-white/[0.07] backdrop-blur-sm border border-white/[0.08] flex items-center justify-center mb-8"
            style={{ animation: 'loginFadeInUp 0.8s ease-out forwards' }}
          >
            <Zap className="h-10 w-10 text-[#FF6B35]" />
          </div>

          {/* Large Bengali text */}
          <h1
            className="text-5xl font-bold text-white leading-tight tracking-tight"
            style={{
              animation: 'loginFadeInUp 0.8s ease-out 0.15s forwards',
              opacity: 0,
            }}
          >
            বেতাগী উপজেলা
          </h1>

          {/* Thin orange separator line */}
          <div
            className="w-16 h-[3px] mt-6 mb-6"
            style={{
              background: 'linear-gradient(90deg, transparent, #FF6B35, transparent)',
              animation: 'loginFadeInUp 0.8s ease-out 0.25s forwards',
              opacity: 0,
            }}
          />

          {/* E-Sheba subtitle */}
          <p
            className="text-white/40 text-lg font-medium tracking-wide"
            style={{
              animation: 'loginFadeInUp 0.8s ease-out 0.3s forwards',
              opacity: 0,
            }}
          >
            ই-সেবা অ্যাডমিন পোর্টাল
          </p>

          {/* Motto - larger and prominent */}
          <p
            className="mt-10 text-2xl font-semibold text-white/85 leading-relaxed max-w-sm"
            style={{
              textShadow: '0 0 40px rgba(255, 107, 53, 0.12)',
              animation: 'loginFadeInUp 0.8s ease-out 0.45s forwards',
              opacity: 0,
            }}
          >
            জনসেবাই আমাদের লক্ষ্য
          </p>

          {/* Location info */}
          <p
            className="mt-4 text-sm text-white/25"
            style={{
              animation: 'loginFadeInUp 0.8s ease-out 0.55s forwards',
              opacity: 0,
            }}
          >
            বরগুনা, বরিশাল, বাংলাদেশ
          </p>
        </div>

        {/* Bottom edge gradient fade */}
        <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-black/20 to-transparent" />
      </div>

      {/* ========== RIGHT SIDE LOGIN FORM ========== */}
      <div
        className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8 relative min-h-screen lg:min-h-0"
        style={{
          background: '#fafaf9',
          backgroundImage:
            'radial-gradient(circle at 20% 80%, rgba(255, 107, 53, 0.03) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(255, 107, 53, 0.02) 0%, transparent 50%)',
        }}
      >
        {/* Mobile-only subtle background pattern */}
        <div
          className="lg:hidden absolute inset-0"
          style={{
            backgroundImage: [
              'repeating-linear-gradient(0deg, transparent, transparent 30px, rgba(255, 107, 53, 0.015) 30px, rgba(255, 107, 53, 0.015) 31px)',
              'repeating-linear-gradient(90deg, transparent, transparent 30px, rgba(255, 107, 53, 0.015) 30px, rgba(255, 107, 53, 0.015) 31px)',
            ].join(', '),
          }}
        />

        <div className="w-full max-w-md relative z-10">
          {/* Mobile logo - visible only on mobile */}
          <div className="lg:hidden text-center mb-6">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-[#FF6B35] shadow-lg shadow-[#FF6B35]/20">
              <Zap className="h-7 w-7 text-white" />
            </div>
          </div>

          {/* Login card with top accent bar */}
          <Card
            className="rounded-[12px] border border-black/[0.06] shadow-xl shadow-black/[0.04] overflow-hidden"
            style={{ animation: 'loginCardIn 0.6s ease-out forwards' }}
          >
            {/* Top accent bar - 3px orange gradient */}
            <div
              className="h-[3px] w-full"
              style={{
                background: 'linear-gradient(90deg, #FF6B35 0%, #FF8F5E 50%, #FF6B35 100%)',
              }}
            />

            <CardContent className="p-6 sm:p-8">
              {/* Header - hidden on mobile (mobile has external logo) */}
              <div className="hidden lg:block text-center mb-7">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-[#FF6B35]/10 border border-[#FF6B35]/10">
                  <Zap className="h-7 w-7 text-[#FF6B35]" />
                </div>
                <h2 className="mt-4 text-xl font-bold text-foreground">বেতাগী ই-সেবা</h2>
                <p className="text-sm text-muted-foreground mt-1">অ্যাডমিন পোর্টালে স্বাগতম</p>
              </div>

              {/* Mobile-only title */}
              <div className="lg:hidden text-center mb-6">
                <h2 className="text-xl font-bold text-foreground">বেতাগী ই-সেবা</h2>
                <p className="text-sm text-muted-foreground mt-1">অ্যাডমিন পোর্টালে স্বাগতম</p>
              </div>

              {/* Form */}
              <form onSubmit={handleLogin} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium text-foreground">
                    ইমেইল
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="আপনার ইমেইল লিখুন"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="h-11 rounded-[12px] border-black/[0.08] bg-white text-foreground placeholder:text-muted-foreground/60 transition-all duration-200 focus-visible:ring-[#FF6B35]/30 focus-visible:border-[#FF6B35]/50 focus-visible:ring-2"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium text-foreground">
                    পাসওয়ার্ড
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPass ? 'text' : 'password'}
                      placeholder="পাসওয়ার্ড লিখুন"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      className="h-11 rounded-[12px] pr-11 border-black/[0.08] bg-white text-foreground placeholder:text-muted-foreground/60 transition-all duration-200 focus-visible:ring-[#FF6B35]/30 focus-visible:border-[#FF6B35]/50 focus-visible:ring-2"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPass(!showPass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground/60 hover:text-[#FF6B35] transition-colors duration-200"
                      aria-label={showPass ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                    >
                      {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full h-11 rounded-[12px] font-semibold text-white transition-all duration-200 active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed cursor-pointer"
                  style={{
                    background: 'linear-gradient(135deg, #FF6B35, #E55A25)',
                    boxShadow:
                      '0 1px 3px rgba(255, 107, 53, 0.3), inset 0 1px 0 rgba(255,255,255,0.15)',
                  }}
                  onMouseEnter={e => {
                    const el = e.currentTarget;
                    if (!loading) {
                      el.style.background =
                        'linear-gradient(135deg, #E55A25, #D04E1C)';
                      el.style.boxShadow =
                        '0 4px 14px rgba(255, 107, 53, 0.35), inset 0 1px 0 rgba(255,255,255,0.15)';
                      el.style.transform = 'translateY(-1px)';
                    }
                  }}
                  onMouseLeave={e => {
                    const el = e.currentTarget;
                    el.style.background =
                      'linear-gradient(135deg, #FF6B35, #E55A25)';
                    el.style.boxShadow =
                      '0 1px 3px rgba(255, 107, 53, 0.3), inset 0 1px 0 rgba(255,255,255,0.15)';
                    el.style.transform = 'translateY(0)';
                  }}
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin inline" />
                      লগইন হচ্ছে...
                    </>
                  ) : (
                    'লগইন'
                  )}
                </button>
              </form>

              {/* Demo accounts section */}
              <div className="mt-7 pt-6 border-t border-black/[0.05]">
                <p className="text-xs text-center text-muted-foreground mb-4 font-medium">
                  ডেমো অ্যাকাউন্টে দ্রুত লগইন করুন
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {DEMO_ACCOUNTS.map(acc => {
                    const IconComp = acc.icon;
                    return (
                      <button
                        key={acc.email}
                        onClick={() => quickLogin(acc)}
                        className={`group relative p-3.5 rounded-[12px] border border-l-[3px] border-l-transparent border-black/[0.06] bg-white text-left transition-all duration-200 hover:shadow-md hover:shadow-black/[0.04] hover:-translate-y-0.5 active:translate-y-0 active:shadow-sm ${acc.borderColor} ${acc.hoverBg} cursor-pointer`}
                      >
                        <div className="flex items-start gap-2.5">
                          <div
                            className="mt-0.5 p-1.5 rounded-lg bg-white transition-colors"
                            style={{ borderLeft: 'none' }}
                          >
                            <IconComp
                              className={`h-3.5 w-3.5 ${acc.textColor}`}
                            />
                          </div>
                          <div className="min-w-0 flex-1">
                            <p
                              className={`text-xs font-semibold ${acc.textColor} truncate`}
                            >
                              {acc.label}
                            </p>
                            <p className={`text-[11px] mt-0.5 ${acc.descColor} truncate`}>
                              {acc.desc}
                            </p>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Footer text */}
          <p className="text-center text-[11px] text-muted-foreground/50 mt-5">
            © ২০২৫ বেতাগী উপজেলা প্রশাসন
          </p>
        </div>
      </div>

      {/* ========== INJECTED KEYFRAMES ========== */}
      <style jsx>{`
        @keyframes loginFloat {
          0%,
          100% {
            transform: translateY(0px) scale(1);
          }
          33% {
            transform: translateY(-18px) scale(1.02);
          }
          66% {
            transform: translateY(8px) scale(0.98);
          }
        }

        @keyframes loginFadeInUp {
          from {
            opacity: 0;
            transform: translateY(16px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes loginCardIn {
          from {
            opacity: 0;
            transform: translateY(20px) scale(0.98);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
      `}</style>
    </div>
  );
}
