'use client';

import React, { useState } from 'react';
import { Plus, Pencil, Trash2, Droplets } from 'lucide-react';
import { MOCK_DONORS, BLOOD_GROUPS } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, DataTable, StatusBadge, ConfirmDialog } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import type { Donor } from '@/types/admin';

export default function DonorsPage() {
  const { hasPermission } = useAuthStore();
  const [data, setData] = useState<Donor[]>(MOCK_DONORS);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editItem, setEditItem] = useState<Donor | null>(null);
  const [form, setForm] = useState({ name: '', phone: '', bloodGroup: '', address: '', lastDonation: '', totalDonation: 0 });

  const canAdd = hasPermission('donors', 'add');
  const canEdit = hasPermission('donors', 'edit');
  const canDelete = hasPermission('donors', 'delete');

  const openAdd = () => { setEditItem(null); setForm({ name: '', phone: '', bloodGroup: '', address: '', lastDonation: '', totalDonation: 0 }); setDialogOpen(true); };
  const openEdit = (item: Donor) => { setEditItem(item); setForm({ name: item.name, phone: item.phone, bloodGroup: item.bloodGroup, address: item.address || '', lastDonation: item.lastDonation || '', totalDonation: item.totalDonation || 0 }); setDialogOpen(true); };
  const handleSave = () => {
    if (!form.name || !form.phone || !form.bloodGroup) { toast.error('নাম, ফোন ও রক্তের গ্রুপ দিন'); return; }
    if (editItem) { setData(prev => prev.map(d => d.id === editItem.id ? { ...d, ...form } : d)); toast.success('দাতার তথ্য আপডেট হয়েছে'); }
    else { setData(prev => [...prev, { id: Date.now(), ...form, status: 'সক্রিয়', createdAt: new Date().toISOString().slice(0, 10) } as Donor]); toast.success('নতুন রক্তদাতা যোগ হয়েছে'); }
    setDialogOpen(false);
  };
  const handleDelete = () => { if (editItem) { setData(prev => prev.filter(d => d.id !== editItem.id)); toast.success('মুছে ফেলা হয়েছে'); } setDeleteOpen(false); };

  const bgColors: Record<string, string> = { 'A+': 'bg-red-100 text-red-700', 'A-': 'bg-red-50 text-red-600', 'B+': 'bg-blue-100 text-blue-700', 'B-': 'bg-blue-50 text-blue-600', 'AB+': 'bg-purple-100 text-purple-700', 'AB-': 'bg-purple-50 text-purple-600', 'O+': 'bg-emerald-100 text-emerald-700', 'O-': 'bg-emerald-50 text-emerald-600' };

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="রক্তদাতা" description="রক্তদাতাদের তথ্য ও ব্যবস্থাপনা">
        {canAdd && <Button onClick={openAdd} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white"><Plus className="h-4 w-4 mr-1.5" />নতুন দাতা</Button>}
      </PageHeader>
      <DataTable
        headers={['#', 'নাম', 'রক্তের গ্রুপ', 'ফোন', 'ঠিকানা', 'মোট দান', 'শেষ দান', 'অবস্থা', (canEdit || canDelete) ? 'অ্যাকশন' : '']}
        data={data}
        searchKeys={['name', 'phone', 'bloodGroup', 'address']}
        searchPlaceholder="রক্তদাতা খুঁজুন..."
        emptyMessage="কোনো রক্তদাতা পাওয়া যায়নি"
        exportConfig={{
          filename: 'রক্তদাতা',
          columns: [
            { key: 'id', label: 'ক্রমিক' },
            { key: 'name', label: 'নাম' },
            { key: 'bloodGroup', label: 'রক্তের গ্রুপ' },
            { key: 'phone', label: 'ফোন' },
            { key: 'address', label: 'ঠিকানা' },
            { key: 'totalDonation', label: 'মোট দান' },
            { key: 'status', label: 'অবস্থা' },
          ],
        }}
        renderRow={(item: Donor) => (
          <tr key={item.id} className="hover:bg-muted/50 transition-colors">
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.id}</td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-red-50 text-red-500 flex items-center justify-center flex-shrink-0"><Droplets className="h-4 w-4" /></div>
                <span className="text-sm font-medium">{item.name}</span>
              </div>
            </td>
            <td className="px-4 py-3"><span className={`text-xs px-2.5 py-1 rounded-full font-bold ${bgColors[item.bloodGroup] || 'bg-gray-100 text-gray-600'}`}>{item.bloodGroup}</span></td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.phone}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.address || '-'}</td>
            <td className="px-4 py-3 text-sm font-medium">{item.totalDonation || 0} বার</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.lastDonation || '-'}</td>
            <td className="px-4 py-3"><StatusBadge status={item.status} /></td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-1">
                {canEdit && <button onClick={() => openEdit(item)} className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>}
                {canDelete && <button onClick={() => { setEditItem(item); setDeleteOpen(true); }} className="p-1.5 rounded-[8px] hover:bg-red-50 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>}
              </div>
            </td>
          </tr>
        )}
      />
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="rounded-[12px] max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'দাতা সম্পাদনা' : 'নতুন রক্তদাতা যোগ করুন'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="space-y-2 col-span-2"><Label>নাম</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="পুরো নাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>ফোন</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="ফোন নম্বর" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>রক্তের গ্রুপ</Label>
              <Select value={form.bloodGroup} onValueChange={v => setForm({ ...form, bloodGroup: v })}>
                <SelectTrigger className="rounded-[12px]"><SelectValue placeholder="নির্বাচন" /></SelectTrigger>
                <SelectContent>{BLOOD_GROUPS.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>ঠিকানা</Label><Input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="ঠিকানা" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>মোট দান</Label><Input type="number" value={form.totalDonation} onChange={e => setForm({ ...form, totalDonation: Number(e.target.value) })} className="rounded-[12px]" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-[12px]">বাতিল</Button>
            <Button onClick={handleSave} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white">সংরক্ষণ করুন</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={deleteOpen} onOpenChange={setDeleteOpen} title="রক্তদাতা মুছুন" description="আপনি কি এই রক্তদাতার তথ্য মুছে ফেলতে চান?" onConfirm={handleDelete} />
    </div>
  );
}