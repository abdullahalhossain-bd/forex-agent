'use client';

import React, { useState } from 'react';
import { Eye, RefreshCw } from 'lucide-react';
import { MOCK_COMPLAINTS, COMPLAINT_STATUSES, COMPLAINT_PRIORITIES } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, DataTable, StatusBadge } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import type { Complaint } from '@/types/admin';

export default function ComplaintsPage() {
  const { hasPermission } = useAuthStore();
  const [data, setData] = useState<Complaint[]>(MOCK_COMPLAINTS);
  const [detailOpen, setDetailOpen] = useState(false);
  const [statusOpen, setStatusOpen] = useState(false);
  const [selected, setSelected] = useState<Complaint | null>(null);
  const [newStatus, setNewStatus] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('সব');

  const canEdit = hasPermission('complaints', 'edit');

  const filtered = statusFilter === 'সব' ? data : data.filter(c => c.status === statusFilter);
  const stats = { মোট: data.length, পেন্ডিং: data.filter(c => c.status === 'পেন্ডিং').length, পর্যালোচনাধীন: data.filter(c => c.status === 'পর্যালোচনাধীন').length, সমাধানকৃত: data.filter(c => c.status === 'সমাধানকৃত').length, বাতিল: data.filter(c => c.status === 'বাতিল').length };

  const openStatus = (item: Complaint) => { setSelected(item); setNewStatus(item.status); setStatusOpen(true); };
  const handleStatusChange = () => {
    if (selected && newStatus) {
      setData(prev => prev.map(c => c.id === selected.id ? { ...c, status: newStatus as Complaint['status'], updatedAt: new Date().toISOString().slice(0, 10) } : c));
      toast.success('অভিযোগের অবস্থা আপডেট হয়েছে');
      setStatusOpen(false);
    }
  };

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="অভিযোগ ব্যবস্থাপনা" description="নাগরিকদের অভিযোগ পর্যালোচনা ও সমাধান">
        <Button onClick={() => setData(MOCK_COMPLAINTS)} variant="outline" className="rounded-[12px]"><RefreshCw className="h-4 w-4 mr-1.5" />রিফ্রেশ</Button>
      </PageHeader>

      {/* Stats cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-5">
        {Object.entries(stats).map(([key, val]) => (
          <div key={key} onClick={() => setStatusFilter(key === 'মোট' ? 'সব' : key)} className={`p-3 rounded-[12px] border text-center cursor-pointer transition-all ${statusFilter === (key === 'মোট' ? 'সব' : key) ? 'border-[#FF6B35] bg-orange-50' : 'hover:bg-muted/50'}`}>
            <p className="text-xl font-bold">{val}</p>
            <p className="text-xs text-muted-foreground">{key}</p>
          </div>
        ))}
      </div>

      <DataTable
        headers={['#', 'বিষয়', 'আবেদনকারী', 'ইউনিয়ন', 'অগ্রাধিকার', 'অবস্থা', 'তারিখ', 'অ্যাকশন']}
        data={filtered}
        searchKeys={['subject', 'name', 'union', 'category']}
        searchPlaceholder="অভিযোগ খুঁজুন..."
        emptyMessage="কোনো অভিযোগ পাওয়া যায়নি"
        exportConfig={{
          filename: 'অভিযোগ',
          columns: [
            { key: 'id', label: 'ক্রমিক' },
            { key: 'name', label: 'নাম' },
            { key: 'union', label: 'ইউনিয়ন' },
            { key: 'subject', label: 'বিষয়' },
            { key: 'status', label: 'অবস্থা' },
            { key: 'priority', label: 'অগ্রাধিকার' },
          ],
        }}
        renderRow={(item: Complaint) => (
          <tr key={item.id} className="hover:bg-muted/50 transition-colors">
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.id}</td>
            <td className="px-4 py-3"><p className="text-sm font-medium max-w-[200px] truncate">{item.subject}</p><p className="text-[11px] text-muted-foreground mt-0.5 max-w-[200px] truncate">{item.description}</p></td>
            <td className="px-4 py-3 text-sm">{item.name}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.union}</td>
            <td className="px-4 py-3"><StatusBadge status={item.priority} /></td>
            <td className="px-4 py-3"><StatusBadge status={item.status} /></td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.createdAt}</td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-1">
                <button onClick={() => { setSelected(item); setDetailOpen(true); }} className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground"><Eye className="h-3.5 w-3.5" /></button>
                {canEdit && <button onClick={() => openStatus(item)} className="p-1.5 rounded-[8px] hover:bg-orange-50 text-muted-foreground hover:text-[#FF6B35]"><RefreshCw className="h-3.5 w-3.5" /></button>}
              </div>
            </td>
          </tr>
        )}
      />

      {/* Detail dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="rounded-[12px] max-w-lg">
          <DialogHeader><DialogTitle>অভিযোগের বিস্তারিত</DialogTitle></DialogHeader>
          {selected && (
            <div className="space-y-3 py-2">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><span className="text-muted-foreground">বিষয়:</span><p className="font-medium mt-0.5">{selected.subject}</p></div>
                <div><span className="text-muted-foreground">বিভাগ:</span><p className="font-medium mt-0.5">{selected.category}</p></div>
                <div><span className="text-muted-foreground">আবেদনকারী:</span><p className="font-medium mt-0.5">{selected.name}</p></div>
                <div><span className="text-muted-foreground">ফোন:</span><p className="font-medium mt-0.5">{selected.phone}</p></div>
                <div><span className="text-muted-foreground">ইউনিয়ন:</span><p className="font-medium mt-0.5">{selected.union}</p></div>
                <div><span className="text-muted-foreground">অগ্রাধিকার:</span><div className="mt-0.5"><StatusBadge status={selected.priority} /></div></div>
                <div><span className="text-muted-foreground">অবস্থা:</span><div className="mt-0.5"><StatusBadge status={selected.status} /></div></div>
                <div><span className="text-muted-foreground">তারিখ:</span><p className="font-medium mt-0.5">{selected.createdAt}</p></div>
              </div>
              <div><span className="text-muted-foreground text-sm">বিবরণ:</span><p className="text-sm mt-1 p-3 bg-muted/50 rounded-[10px]">{selected.description}</p></div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Status change dialog */}
      <Dialog open={statusOpen} onOpenChange={setStatusOpen}>
        <DialogContent className="rounded-[12px] max-w-sm">
          <DialogHeader><DialogTitle>অবস্থা পরিবর্তন</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2"><Label>নতুন অবস্থা</Label>
              <Select value={newStatus} onValueChange={setNewStatus}>
                <SelectTrigger className="rounded-[12px]"><SelectValue /></SelectTrigger>
                <SelectContent>{COMPLAINT_STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setStatusOpen(false)} className="rounded-[12px]">বাতিল</Button>
            <Button onClick={handleStatusChange} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white">আপডেট</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}