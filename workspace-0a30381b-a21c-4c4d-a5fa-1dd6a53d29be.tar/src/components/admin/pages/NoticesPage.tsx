'use client';

import React, { useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { MOCK_NOTICES } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, DataTable, StatusBadge, ConfirmDialog, EmptyState } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import type { Notice } from '@/types/admin';
import { NOTICE_CATEGORIES } from '@/lib/mock-data';

export default function NoticesPage() {
  const { hasPermission } = useAuthStore();
  const [data, setData] = useState<Notice[]>(MOCK_NOTICES);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editItem, setEditItem] = useState<Notice | null>(null);
  const [form, setForm] = useState({ title: '', description: '', category: 'সাধারণ' as Notice['category'] });
  const [filter, setFilter] = useState<string>('সব');

  const canAdd = hasPermission('notices', 'add');
  const canEdit = hasPermission('notices', 'edit');
  const canDelete = hasPermission('notices', 'delete');

  const filtered = filter === 'সব' ? data : data.filter(n => n.category === filter);

  const openAdd = () => { setEditItem(null); setForm({ title: '', description: '', category: 'সাধারণ' }); setDialogOpen(true); };
  const openEdit = (item: Notice) => { setEditItem(item); setForm({ title: item.title, description: item.description, category: item.category }); setDialogOpen(true); };
  const handleSave = () => {
    if (!form.title) { toast.error('শিরোনাম দিন'); return; }
    if (editItem) {
      setData(prev => prev.map(n => n.id === editItem.id ? { ...n, ...form, updatedAt: new Date().toISOString().slice(0, 10) } : n));
      toast.success('নোটিশ আপডেট হয়েছে');
    } else {
      setData(prev => [...prev, { id: Date.now(), ...form, status: 'সক্রিয়', createdAt: new Date().toISOString().slice(0, 10), updatedAt: new Date().toISOString().slice(0, 10) }]);
      toast.success('নতুন নোটিশ যোগ হয়েছে');
    }
    setDialogOpen(false);
  };
  const handleDelete = () => {
    if (editItem) {
      setData(prev => prev.filter(n => n.id !== editItem.id));
      toast.success('নোটিশ মুছে ফেলা হয়েছে');
    }
    setDeleteOpen(false);
  };

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="নোটিশ বোর্ড" description="বেতাগী উপজেলার সকল বিজ্ঞপ্তি ও নোটিশ ব্যবস্থাপনা করুন">
        {canAdd && <Button onClick={openAdd} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white"><Plus className="h-4 w-4 mr-1.5" />নতুন নোটিশ</Button>}
      </PageHeader>

      {/* Category filter chips */}
      <div className="flex flex-wrap gap-2 mb-5">
        {['সব', ...NOTICE_CATEGORIES].map(cat => (
          <button key={cat} onClick={() => setFilter(cat)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all ${filter === cat ? 'bg-[#FF6B35] text-white' : 'bg-muted text-muted-foreground hover:bg-muted/80'}`}>
            {cat}
          </button>
        ))}
      </div>

      <DataTable
        headers={['#', 'শিরোনাম', 'বিভাগ', 'অবস্থা', 'তারিখ', canEdit || canDelete ? 'অ্যাকশন' : '']}
        data={filtered}
        searchKeys={['title', 'description']}
        searchPlaceholder="নোটিশ খুঁজুন..."
        emptyMessage="কোনো নোটিশ পাওয়া যায়নি"
        exportConfig={{
          filename: 'নোটিশ',
          columns: [
            { key: 'id', label: 'ক্রমিক' },
            { key: 'title', label: 'শিরোনাম' },
            { key: 'category', label: 'বিভাগ' },
            { key: 'status', label: 'অবস্থা' },
            { key: 'createdAt', label: 'তারিখ' },
          ],
        }}
        renderRow={(item: Notice) => (
          <tr key={item.id} className="hover:bg-muted/50 transition-colors">
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.id}</td>
            <td className="px-4 py-3"><p className="text-sm font-medium max-w-xs truncate">{item.title}</p></td>
            <td className="px-4 py-3"><StatusBadge status={item.category} /></td>
            <td className="px-4 py-3"><StatusBadge status={item.status} /></td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.createdAt}</td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-1">
                {canEdit && <button onClick={() => openEdit(item)} className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>}
                {canDelete && <button onClick={() => { setEditItem(item); setDeleteOpen(true); }} className="p-1.5 rounded-[8px] hover:bg-red-50 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>}
              </div>
            </td>
          </tr>
        )}
      />

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="rounded-[12px] max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'নোটিশ সম্পাদনা' : 'নতুন নোটিশ যোগ করুন'}</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2"><Label>শিরোনাম</Label><Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="নোটিশের শিরোনাম লিখুন" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>বিভাগ</Label><Select value={form.category} onValueChange={v => setForm({ ...form, category: v as Notice['category'] })}><SelectTrigger className="rounded-[12px]"><SelectValue /></SelectTrigger><SelectContent>{NOTICE_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select></div>
            <div className="space-y-2"><Label>বিবরণ</Label><Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="নোটিশের বিবরণ লিখুন" rows={4} className="rounded-[12px]" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-[12px]">বাতিল</Button>
            <Button onClick={handleSave} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white">সংরক্ষণ করুন</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog open={deleteOpen} onOpenChange={setDeleteOpen} title="নোটিশ মুছুন" description="আপনি কি এই নোটিশ মুছে ফেলতে চান? এই কাজ পূর্বাবস্থায় ফেরত আনা যাবে না।" onConfirm={handleDelete} />
    </div>
  );
}