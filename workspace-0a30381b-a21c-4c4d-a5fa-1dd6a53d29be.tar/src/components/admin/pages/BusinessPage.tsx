'use client';

import React, { useState } from 'react';
import { Plus, Pencil, Trash2, Store } from 'lucide-react';
import { MOCK_BUSINESS, BUSINESS_CATEGORIES } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, DataTable, StatusBadge, ConfirmDialog } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import type { BusinessItem } from '@/types/admin';

export default function BusinessPage() {
  const { hasPermission } = useAuthStore();
  const [data, setData] = useState<BusinessItem[]>(MOCK_BUSINESS);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editItem, setEditItem] = useState<BusinessItem | null>(null);
  const [form, setForm] = useState({ name: '', category: '', ownerName: '', phone: '', address: '', description: '' });

  const canAdd = hasPermission('business', 'add');
  const canEdit = hasPermission('business', 'edit');
  const canDelete = hasPermission('business', 'delete');

  const openAdd = () => { setEditItem(null); setForm({ name: '', category: '', ownerName: '', phone: '', address: '', description: '' }); setDialogOpen(true); };
  const openEdit = (item: BusinessItem) => { setEditItem(item); setForm({ name: item.name, category: item.category, ownerName: item.ownerName, phone: item.phone, address: item.address, description: item.description || '' }); setDialogOpen(true); };
  const handleSave = () => {
    if (!form.name || !form.ownerName) { toast.error('নাম ও মালিকের নাম দিন'); return; }
    if (editItem) { setData(prev => prev.map(b => b.id === editItem.id ? { ...b, ...form } : b)); toast.success('ব্যবসা আপডেট হয়েছে'); }
    else { setData(prev => [...prev, { id: Date.now(), ...form, status: 'সক্রিয়', createdAt: new Date().toISOString().slice(0, 10) }]); toast.success('নতুন ব্যবসা যোগ হয়েছে'); }
    setDialogOpen(false);
  };
  const handleDelete = () => { if (editItem) { setData(prev => prev.filter(b => b.id !== editItem.id)); toast.success('মুছে ফেলা হয়েছে'); } setDeleteOpen(false); };

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="ব্যবসা প্রতিষ্ঠান" description="বেতাগীর ব্যবসা প্রতিষ্ঠানের তথ্য ব্যবস্থাপনা">
        {canAdd && <Button onClick={openAdd} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white"><Plus className="h-4 w-4 mr-1.5" />নতুন ব্যবসা</Button>}
      </PageHeader>
      <DataTable
        headers={['#', 'নাম', 'বিভাগ', 'মালিক', 'ফোন', 'ঠিকানা', 'অবস্থা', (canEdit || canDelete) ? 'অ্যাকশন' : '']}
        data={data}
        searchKeys={['name', 'category', 'ownerName']}
        searchPlaceholder="ব্যবসা খুঁজুন..."
        emptyMessage="কোনো ব্যবসা পাওয়া যায়নি"
        exportConfig={{
          filename: 'ব্যবসা',
          columns: [
            { key: 'id', label: 'ক্রমিক' },
            { key: 'name', label: 'নাম' },
            { key: 'category', label: 'বিভাগ' },
            { key: 'ownerName', label: 'মালিক' },
            { key: 'phone', label: 'ফোন' },
            { key: 'status', label: 'অবস্থা' },
          ],
        }}
        renderRow={(item: BusinessItem) => (
          <tr key={item.id} className="hover:bg-muted/50 transition-colors">
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.id}</td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center flex-shrink-0"><Store className="h-4 w-4" /></div>
                <span className="text-sm font-medium">{item.name}</span>
              </div>
            </td>
            <td className="px-4 py-3 text-sm">{item.category}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.ownerName}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground">{item.phone}</td>
            <td className="px-4 py-3 text-sm text-muted-foreground max-w-[180px] truncate">{item.address}</td>
            <td className="px-4 py-3"><StatusBadge status={item.status} /></td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-1">
                {canEdit && <button onClick={() => openEdit(item)} className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>}
                {canDelete && <button onClick={() => { setEditItem(item); setDeleteOpen(true); }} className="p-1.5 rounded-[8px] hover:bg-red-50 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>}
              </div>
            </td>
          </tr>
        )}
      />
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="rounded-[12px] max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'ব্যবসা সম্পাদনা' : 'নতুন ব্যবসা যোগ করুন'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="space-y-2 col-span-2"><Label>প্রতিষ্ঠানের নাম</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="প্রতিষ্ঠানের নাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>বিভাগ</Label>
              <Select value={form.category} onValueChange={v => setForm({ ...form, category: v })}>
                <SelectTrigger className="rounded-[12px]"><SelectValue placeholder="বিভাগ নির্বাচন" /></SelectTrigger>
                <SelectContent>{BUSINESS_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>মালিকের নাম</Label><Input value={form.ownerName} onChange={e => setForm({ ...form, ownerName: e.target.value })} placeholder="মালিকের নাম" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>ফোন</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="ফোন নম্বর" className="rounded-[12px]" /></div>
            <div className="space-y-2"><Label>ঠিকানা</Label><Input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="ঠিকানা" className="rounded-[12px]" /></div>
            <div className="space-y-2 col-span-2"><Label>বিবরণ</Label><Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="বিবরণ" rows={2} className="rounded-[12px]" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-[12px]">বাতিল</Button>
            <Button onClick={handleSave} className="rounded-[12px] bg-[#FF6B35] hover:bg-[#E55A25] text-white">সংরক্ষণ করুন</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={deleteOpen} onOpenChange={setDeleteOpen} title="ব্যবসা মুছুন" description="আপনি কি এই ব্যবসার তথ্য মুছে ফেলতে চান?" onConfirm={handleDelete} />
    </div>
  );
}