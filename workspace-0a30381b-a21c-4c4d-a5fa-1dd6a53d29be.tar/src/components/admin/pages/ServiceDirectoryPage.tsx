'use client';

import React, { useState, useMemo } from 'react';
import {
  Plus, Pencil, Trash2, HeartPulse, Building2, MapPin, Wrench, Siren,
  Scale, GraduationCap, Sprout, Users, Home, Bus, BookOpen,
  ChevronRight, Eye, EyeOff, Search, Layers, Phone, Hash
} from 'lucide-react';
import { MOCK_SERVICE_DIRECTORY, SERVICE_DIRECTORY_CATEGORIES } from '@/lib/mock-data';
import { useAuthStore } from '@/stores/admin';
import { PageHeader, StatusBadge, ConfirmDialog } from '@/components/admin/common/shared';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import type { ServiceDirectoryItem } from '@/types/admin';

// Category icon & color mapping
const CATEGORY_CONFIG: Record<string, { icon: React.ComponentType<{ className?: string }>; color: string; bg: string; border: string; darkBg: string }> = {
  'স্বাস্থ্য সেবা': { icon: HeartPulse, color: 'text-rose-600', bg: 'bg-rose-50', border: 'border-rose-200', darkBg: 'dark:bg-rose-500/10' },
  'সাধারণ সেবা': { icon: Building2, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-200', darkBg: 'dark:bg-blue-500/10' },
  'ইতিহাস ও ঐতিহ্য': { icon: BookOpen, color: 'text-amber-700', bg: 'bg-amber-50', border: 'border-amber-200', darkBg: 'dark:bg-amber-500/10' },
  'মিস্ত্রি সেবা': { icon: Wrench, color: 'text-orange-600', bg: 'bg-orange-50', border: 'border-orange-200', darkBg: 'dark:bg-orange-500/10' },
  'জরুরি সেবা': { icon: Siren, color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200', darkBg: 'dark:bg-red-500/10' },
  'আইন ও বিচার': { icon: Scale, color: 'text-indigo-600', bg: 'bg-indigo-50', border: 'border-indigo-200', darkBg: 'dark:bg-indigo-500/10' },
  'শিক্ষা': { icon: GraduationCap, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200', darkBg: 'dark:bg-emerald-500/10' },
  'কৃষি': { icon: Sprout, color: 'text-green-600', bg: 'bg-green-50', border: 'border-green-200', darkBg: 'dark:bg-green-500/10' },
  'নারী ও পরিবার কল্যাণ': { icon: Users, color: 'text-pink-600', bg: 'bg-pink-50', border: 'border-pink-200', darkBg: 'dark:bg-pink-500/10' },
  'সামাজিক সংগঠন': { icon: Users, color: 'text-cyan-600', bg: 'bg-cyan-50', border: 'border-cyan-200', darkBg: 'dark:bg-cyan-500/10' },
  'গৃহ ও দৈনন্দিন সেবা': { icon: Home, color: 'text-violet-600', bg: 'bg-violet-50', border: 'border-violet-200', darkBg: 'dark:bg-violet-500/10' },
  'পরিবহন': { icon: Bus, color: 'text-teal-600', bg: 'bg-teal-50', border: 'border-teal-200', darkBg: 'dark:bg-teal-500/10' },
};

const DEFAULT_CONFIG = { icon: Layers, color: 'text-gray-600', bg: 'bg-gray-50', border: 'border-gray-200', darkBg: 'dark:bg-gray-500/10' };

export default function ServiceDirectoryPage() {
  const { hasPermission } = useAuthStore();
  const [data, setData] = useState<ServiceDirectoryItem[]>(MOCK_SERVICE_DIRECTORY);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editItem, setEditItem] = useState<ServiceDirectoryItem | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('সকল');
  const [search, setSearch] = useState('');
  const [showInactive, setShowInactive] = useState(false);
  const [form, setForm] = useState({
    name: '', nameEn: '', category: '', categoryGroup: '', description: '', phone: '', address: '', contactPerson: '', totalEntries: 0,
  });

  const canAdd = hasPermission('serviceDirectory', 'add');
  const canEdit = hasPermission('serviceDirectory', 'edit');
  const canDelete = hasPermission('serviceDirectory', 'delete');

  // Filtered data
  const filtered = useMemo(() => {
    let result = data;
    if (!showInactive) result = result.filter(s => s.status === 'সক্রিয়');
    if (activeCategory !== 'সকল') result = result.filter(s => s.category === activeCategory);
    if (search) result = result.filter(s =>
      s.name.includes(search) || (s.nameEn && s.nameEn.toLowerCase().includes(search.toLowerCase())) || s.category.includes(search)
    );
    return result;
  }, [data, activeCategory, search, showInactive]);

  // Category stats
  const categoryStats = useMemo(() => {
    const stats: Record<string, { total: number; entries: number }> = {};
    data.filter(s => s.status === 'সক্রিয়').forEach(s => {
      if (!stats[s.category]) stats[s.category] = { total: 0, entries: 0 };
      stats[s.category].total += 1;
      stats[s.category].entries += s.totalEntries || 0;
    });
    return stats;
  }, [data]);

  const openAdd = () => {
    setEditItem(null);
    setForm({ name: '', nameEn: '', category: '', categoryGroup: '', description: '', phone: '', address: '', contactPerson: '', totalEntries: 0 });
    setDialogOpen(true);
  };

  const openEdit = (item: ServiceDirectoryItem) => {
    setEditItem(item);
    setForm({
      name: item.name, nameEn: item.nameEn || '', category: item.category, categoryGroup: item.categoryGroup,
      description: item.description || '', phone: item.phone || '', address: item.address || '',
      contactPerson: item.contactPerson || '', totalEntries: item.totalEntries || 0,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!form.name || !form.category) { toast.error('সার্ভিসের নাম ও ক্যাটাগরি দিন'); return; }
    if (editItem) {
      setData(prev => prev.map(s => s.id === editItem.id ? {
        ...s, name: form.name, nameEn: form.nameEn, category: form.category, categoryGroup: form.categoryGroup,
        description: form.description, phone: form.phone, address: form.address, contactPerson: form.contactPerson, totalEntries: form.totalEntries,
      } : s));
      toast.success('সার্ভিস আপডেট হয়েছে');
    } else {
      setData(prev => [...prev, {
        id: Date.now(), ...form, status: 'সক্রিয়', createdAt: new Date().toISOString().slice(0, 10),
      }]);
      toast.success('নতুন সার্ভিস যোগ হয়েছে');
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (editItem) {
      setData(prev => prev.filter(s => s.id !== editItem.id));
      toast.success('সার্ভিস মুছে ফেলা হয়েছে');
    }
    setDeleteOpen(false);
  };

  const handleCategoryChange = (cat: string) => {
    const groupMap: Record<string, string> = {
      'স্বাস্থ্য সেবা': 'health', 'সাধারণ সেবা': 'general', 'ইতিহাস ও ঐতিহ্য': 'history',
      'মিস্ত্রি সেবা': 'technician', 'জরুরি সেবা': 'emergency', 'আইন ও বিচার': 'law',
      'শিক্ষা': 'education', 'কৃষি': 'agriculture', 'নারী ও পরিবার কল্যাণ': 'women',
      'সামাজিক সংগঠন': 'social', 'গৃহ ও দৈনন্দিন সেবা': 'home', 'পরিবহন': 'transport',
    };
    setForm(f => ({ ...f, category: cat, categoryGroup: groupMap[cat] || 'general' }));
  };

  const totalServices = data.filter(s => s.status === 'সক্রিয়').length;
  const totalEntries = data.filter(s => s.status === 'সক্রিয়').reduce((a, s) => a + (s.totalEntries || 0), 0);
  const totalCategories = [...new Set(data.filter(s => s.status === 'সক্রিয়').map(s => s.category))].length;

  return (
    <div className="animate-fade-in-up">
      <PageHeader title="সার্ভিস ডিরেক্টরি" description="উপজেলার সকল সেবার সমন্বিত ডিরেক্টরি ও ব্যবস্থাপনা">
        {canAdd && <Button onClick={openAdd} className="rounded-[12px] bg-[#1eb1b1] hover:bg-[#189696] text-white"><Plus className="h-4 w-4 mr-1.5" />নতুন সার্ভিস</Button>}
      </PageHeader>

      {/* Stats bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        {[
          { label: 'মোট সার্ভিস', value: totalServices, icon: Layers, color: 'text-[#FF6B35]', bg: 'bg-[#FF6B35]/10' },
          { label: 'মোট এন্ট্রি', value: totalEntries, icon: Hash, color: 'text-[#1eb1b1]', bg: 'bg-[#1eb1b1]/10' },
          { label: 'ক্যাটাগরি', value: totalCategories, icon: MapPin, color: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-500/10' },
          { label: 'নিষ্ক্রিয়', value: data.filter(s => s.status === 'নিষ্ক্রিয়').length, icon: EyeOff, color: 'text-gray-500', bg: 'bg-gray-50 dark:bg-gray-500/10' },
        ].map((stat, i) => (
          <div key={i} className="rounded-[12px] border bg-white dark:bg-card p-4 flex items-center gap-3">
            <div className={`p-2 rounded-[10px] ${stat.bg}`}><stat.icon className={`h-5 w-5 ${stat.color}`} /></div>
            <div>
              <p className="text-lg font-bold text-foreground">{stat.value.toLocaleString('bn-BD')}</p>
              <p className="text-[11px] text-muted-foreground">{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Search & filter bar */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-5">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/40" />
          <Input
            placeholder="সার্ভিস খুঁজুন (বাংলা বা English)..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="rounded-[12px] pl-9"
          />
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant={showInactive ? 'default' : 'outline'}
            size="sm"
            onClick={() => setShowInactive(!showInactive)}
            className={`rounded-[8px] text-xs gap-1.5 ${!showInactive ? '' : 'bg-gray-700 dark:bg-gray-600'}`}
          >
            {showInactive ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
            {showInactive ? 'সব দেখান' : 'সক্রিয়'}
          </Button>
          <Badge variant="outline" className="rounded-[8px] text-xs font-normal text-muted-foreground">
            {filtered.length.toLocaleString('bn-BD')} টি সার্ভিস
          </Badge>
        </div>
      </div>

      {/* Category tabs - scrollable */}
      <div className="flex gap-2 overflow-x-auto pb-3 mb-5 scrollbar-none">
        <button
          onClick={() => setActiveCategory('সকল')}
          className={`flex-shrink-0 px-4 py-2 rounded-[10px] text-xs font-medium transition-all duration-200 border ${
            activeCategory === 'সকল'
              ? 'bg-[#FF6B35] text-white border-[#FF6B35] shadow-sm shadow-[#FF6B35]/20'
              : 'bg-white dark:bg-card text-muted-foreground hover:text-foreground border-transparent hover:border-border'
          }`}
        >
          সকল ({data.filter(s => s.status === 'সক্রিয়').length.toLocaleString('bn-BD')})
        </button>
        {SERVICE_DIRECTORY_CATEGORIES.map(cat => {
          const cfg = CATEGORY_CONFIG[cat] || DEFAULT_CONFIG;
          const Icon = cfg.icon;
          const count = categoryStats[cat]?.total || 0;
          if (count === 0 && !showInactive) return null;
          return (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-[10px] text-xs font-medium transition-all duration-200 border ${
                activeCategory === cat
                  ? 'bg-foreground text-background border-foreground shadow-sm'
                  : 'bg-white dark:bg-card text-muted-foreground hover:text-foreground border-transparent hover:border-border'
              }`}
            >
              <Icon className={`h-3.5 w-3.5 ${activeCategory === cat ? '' : cfg.color}`} />
              {cat} ({count.toLocaleString('bn-BD')})
            </button>
          );
        })}
      </div>

      {/* Service cards grid */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
          <div className="p-4 rounded-full bg-muted/50 mb-4"><Layers className="h-10 w-10 opacity-40" /></div>
          <p className="text-sm font-medium">কোনো সার্ভিস পাওয়া যায়নি</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map(item => {
            const cfg = CATEGORY_CONFIG[item.category] || DEFAULT_CONFIG;
            const Icon = cfg.icon;
            return (
              <Card key={item.id} className={`rounded-[12px] border bg-white dark:bg-card overflow-hidden group hover:shadow-md transition-all duration-200 ${item.status === 'নিষ্ক্রিয়' ? 'opacity-60' : ''}`}>
                <CardContent className="p-0">
                  {/* Card header with category color stripe */}
                  <div className={`h-1 w-full ${cfg.bg.replace('/50', '')} ${cfg.bg.includes('rose') ? 'bg-rose-400' : cfg.bg.includes('blue') ? 'bg-blue-400' : cfg.bg.includes('amber') ? 'bg-amber-400' : cfg.bg.includes('orange') ? 'bg-orange-400' : cfg.bg.includes('red') ? 'bg-red-400' : cfg.bg.includes('indigo') ? 'bg-indigo-400' : cfg.bg.includes('emerald') ? 'bg-emerald-400' : cfg.bg.includes('green') ? 'bg-green-400' : cfg.bg.includes('pink') ? 'bg-pink-400' : cfg.bg.includes('cyan') ? 'bg-cyan-400' : cfg.bg.includes('violet') ? 'bg-violet-400' : cfg.bg.includes('teal') ? 'bg-teal-400' : 'bg-gray-400'}`} />
                  <div className="p-4">
                    {/* Top row: icon + status + actions */}
                    <div className="flex items-start justify-between mb-3">
                      <div className={`p-2 rounded-[10px] ${cfg.bg} ${cfg.darkBg} ${cfg.border} border`}>
                        <Icon className={`h-5 w-5 ${cfg.color}`} />
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {(canEdit) && (
                          <button onClick={() => openEdit(item)} className="p-1.5 rounded-[8px] hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                            <Pencil className="h-3.5 w-3.5" />
                          </button>
                        )}
                        {(canDelete) && (
                          <button onClick={() => { setEditItem(item); setDeleteOpen(true); }} className="p-1.5 rounded-[8px] hover:bg-red-50 dark:hover:bg-red-500/10 text-muted-foreground hover:text-red-600 transition-colors">
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Service name */}
                    <h3 className="text-sm font-bold text-foreground leading-tight mb-0.5">{item.name}</h3>
                    {item.nameEn && <p className="text-[11px] text-muted-foreground mb-2">{item.nameEn}</p>}

                    {/* Category badge */}
                    <div className="mb-3">
                      <span className={`inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full ${cfg.bg} ${cfg.darkBg} ${cfg.color}`}>
                        <Icon className="h-3 w-3" />
                        {item.category}
                      </span>
                    </div>

                    {/* Description */}
                    {item.description && (
                      <p className="text-xs text-muted-foreground leading-relaxed mb-3 line-clamp-2">{item.description}</p>
                    )}

                    {/* Footer: entries + phone + status */}
                    <div className="flex items-center justify-between pt-3 border-t dark:border-white/5">
                      <div className="flex items-center gap-3">
                        {item.totalEntries ? (
                          <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                            <Hash className="h-3 w-3" />
                            {item.totalEntries.toLocaleString('bn-BD')} এন্ট্রি
                          </span>
                        ) : null}
                        {item.phone ? (
                          <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                            <Phone className="h-3 w-3" />
                            {item.phone}
                          </span>
                        ) : null}
                      </div>
                      <StatusBadge status={item.status} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="rounded-[12px] max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editItem ? 'সার্ভিস সম্পাদনা' : 'নতুন সার্ভিস যোগ করুন'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="space-y-2 col-span-2">
              <Label>সার্ভিসের নাম (বাংলা)</Label>
              <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="যেমন: হাসপাতাল" className="rounded-[12px]" />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>সার্ভিসের নাম (English)</Label>
              <Input value={form.nameEn} onChange={e => setForm({ ...form, nameEn: e.target.value })} placeholder="e.g. Hospital" className="rounded-[12px]" />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>ক্যাটাগরি</Label>
              <Select value={form.category} onValueChange={handleCategoryChange}>
                <SelectTrigger className="rounded-[12px]"><SelectValue placeholder="ক্যাটাগরি নির্বাচন করুন" /></SelectTrigger>
                <SelectContent>
                  {SERVICE_DIRECTORY_CATEGORIES.map(cat => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 col-span-2">
              <Label>বিবরণ</Label>
              <Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="সার্ভিসের বিবরণ" rows={2} className="rounded-[12px]" />
            </div>
            <div className="space-y-2">
              <Label>ফোন নম্বর</Label>
              <Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="ফোন নম্বর" className="rounded-[12px]" />
            </div>
            <div className="space-y-2">
              <Label>মোট এন্ট্রি</Label>
              <Input type="number" value={form.totalEntries || ''} onChange={e => setForm({ ...form, totalEntries: Number(e.target.value) || 0 })} placeholder="০" className="rounded-[12px]" />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>ঠিকানা</Label>
              <Input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="ঠিকানা" className="rounded-[12px]" />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>যোগাযোগকারী</Label>
              <Input value={form.contactPerson} onChange={e => setForm({ ...form, contactPerson: e.target.value })} placeholder="দায়িত্বপ্রাপ্ত ব্যক্তি" className="rounded-[12px]" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-[12px]">বাতিল</Button>
            <Button onClick={handleSave} className="rounded-[12px] bg-[#1eb1b1] hover:bg-[#189696] text-white">সংরক্ষণ করুন</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <ConfirmDialog open={deleteOpen} onOpenChange={setDeleteOpen} title="সার্ভিস মুছুন" description={`"${editItem?.name}" সার্ভিসটি মুছে ফেলতে চান? এই কাজ পূর্বাবস্থায় ফেরানো যাবে না।`} onConfirm={handleDelete} />
    </div>
  );
}