// Betagi E-Sheba Admin Portal Types

export type UserRole = 'admin' | 'uno' | 'ict' | 'acLand' | 'developer';

export interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  union?: string;
  avatar?: string;
  createdAt: string;
}

export interface Notice {
  id: number;
  title: string;
  description: string;
  category: 'গুরুত্বপূর্ণ' | 'সাধারণ' | 'ইভেন্ট' | 'ছুটি' | 'অন্যান্য';
  image?: string;
  status: 'সক্রিয়' | 'নিষ্ক্রিয়';
  createdAt: string;
  updatedAt: string;
}

export interface GovtOfficer {
  id: number;
  name: string;
  designation: string;
  department: string;
  phone: string;
  email?: string;
  office?: string;
  address?: string;
  image?: string;
  status: 'সক্রিয়' | 'নিষ্ক্রিয়';
  createdAt: string;
}

export interface GovtServiceItem {
  id: number;
  name: string;
  nameEn?: string;
  category: string;
  description?: string;
  fee: number;
  requiredDocs?: string;
  process?: string;
  status: 'সক্রিয়' | 'নিষ্ক্রিয়';
  createdAt: string;
}

export interface Clinic {
  id: number;
  name: string;
  type: string;
  address: string;
  phone: string;
  doctorName?: string;
  specialization?: string;
  schedule?: string;
  latitude?: number;
  longitude?: number;
  image?: string;
  status: 'সক্রিয়' | 'নিষ্ক্রিয়';
  createdAt: string;
}

export interface Doctor {
  id: number;
  name: string;
  specialization: string;
  qualification?: string;
  phone: string;
  email?: string;
  chamber?: string;
  schedule?: string;
  fee?: number;
  image?: string;
  bloodGroup?: string;
  status: 'সক্রিয়' | 'নিষ্ক্রিয়';
  createdAt: string;
}

export interface Donor {
  id: number;
  name: string;
  phone: string;
  bloodGroup: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  address?: string;
  lastDonation?: string;
  totalDonation?: number;
  status: 'সক্রিয়' | 'নিষ্ক্রিয়';
  createdAt: string;
}

export interface BusinessItem {
  id: number;
  name: string;
  category: string;
  ownerName: string;
  phone: string;
  address: string;
  description?: string;
  image?: string;
  status: 'সক্রিয়' | 'নিষ্ক্রিয়';
  createdAt: string;
}

export interface Person {
  id: number;
  name: string;
  designation?: string;
  category: string;
  phone?: string;
  address?: string;
  details?: string;
  image?: string;
  status: 'সক্রিয়' | 'নিষ্ক্রিয়';
  createdAt: string;
}

export interface Complaint {
  id: number;
  name: string;
  phone: string;
  union: string;
  category: string;
  subject: string;
  description: string;
  status: 'পেন্ডিং' | 'পর্যালোচনাধীন' | 'সমাধানকৃত' | 'বাতিল';
  priority: 'উচ্চ' | 'মাঝারি' | 'নিম্ন';
  createdAt: string;
  updatedAt: string;
}

export interface BudgetItem {
  id: number;
  category: string;
  allocated: number;
  spent: number;
  fiscalYear: string;
  description?: string;
  createdAt: string;
}

export interface EmergencyNumber {
  id: number;
  name: string;
  number: string;
  category: string;
  description?: string;
  status: 'সক্রিয়' | 'নিষ্ক্রিয়';
  createdAt: string;
}

export interface ServiceDirectoryItem {
  id: number;
  name: string;
  nameEn?: string;
  category: string;
  categoryGroup: string;
  description?: string;
  phone?: string;
  address?: string;
  contactPerson?: string;
  status: 'সক্রিয়' | 'নিষ্ক্রিয়';
  totalEntries?: number;
  createdAt: string;
}

export interface Notification {
  id: number;
  title: string;
  message: string;
  type: 'তথ্য' | 'সতর্কতা' | 'জরুরি' | 'সাধারণ';
  targetRole?: UserRole | 'সবাই';
  isRead: boolean;
  createdAt: string;
}

export interface DashboardStats {
  totalCitizens: number;
  totalOfficers: number;
  totalClinics: number;
  totalDoctors: number;
  totalDonors: number;
  totalBusiness: number;
  totalComplaints: number;
  resolvedComplaints: number;
  pendingComplaints: number;
  totalNotices: number;
  totalBudget: number;
  spentBudget: number;
}

// RBAC Permissions
export interface RolePermissions {
  [key: string]: {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
  };
}

export const ROLE_LABELS: Record<UserRole, string> = {
  admin: 'সুপার অ্যাডমিন',
  uno: 'উপজেলা নির্বাহী অফিসার',
  ict: 'আইসিটি অফিসার',
  acLand: 'সহকারী কমিশনার (ভূমি)',
  developer: 'ডেভেলপার',
};

// Permission matrix for each module
export const PERMISSIONS: Record<UserRole, Record<string, RolePermissions>> = {
  admin: {
    dashboard: { view: true, add: true, edit: true, delete: true },
    notices: { view: true, add: true, edit: true, delete: true },
    officers: { view: true, add: true, edit: true, delete: true },
    serviceItems: { view: true, add: true, edit: true, delete: true },
    clinics: { view: true, add: true, edit: true, delete: true },
    doctors: { view: true, add: true, edit: true, delete: true },
    donors: { view: true, add: true, edit: true, delete: true },
    business: { view: true, add: true, edit: true, delete: true },
    persons: { view: true, add: true, edit: true, delete: true },
    complaints: { view: true, add: true, edit: true, delete: true },
    budget: { view: true, add: true, edit: true, delete: true },
    emergency: { view: true, add: true, edit: true, delete: true },
    notifications: { view: true, add: true, edit: true, delete: true },
    users: { view: true, add: true, edit: true, delete: true },
    serviceDirectory: { view: true, add: true, edit: true, delete: true },
    profile: { view: true, add: true, edit: true, delete: false },
  },
  uno: {
    dashboard: { view: true, add: true, edit: true, delete: true },
    notices: { view: true, add: true, edit: true, delete: true },
    officers: { view: true, add: true, edit: true, delete: true },
    serviceItems: { view: true, add: true, edit: true, delete: true },
    clinics: { view: true, add: true, edit: true, delete: true },
    doctors: { view: true, add: true, edit: true, delete: true },
    donors: { view: true, add: true, edit: true, delete: true },
    business: { view: true, add: true, edit: true, delete: true },
    persons: { view: true, add: true, edit: true, delete: true },
    complaints: { view: true, add: true, edit: true, delete: true },
    budget: { view: true, add: true, edit: true, delete: true },
    emergency: { view: true, add: true, edit: true, delete: true },
    notifications: { view: true, add: true, edit: true, delete: true },
    users: { view: true, add: true, edit: true, delete: true },
    serviceDirectory: { view: true, add: true, edit: true, delete: true },
    profile: { view: true, add: true, edit: true, delete: false },
  },
  ict: {
    dashboard: { view: true, add: false, edit: false, delete: false },
    notices: { view: true, add: true, edit: true, delete: true },
    officers: { view: true, add: true, edit: true, delete: false },
    serviceItems: { view: true, add: true, edit: true, delete: false },
    clinics: { view: true, add: true, edit: true, delete: false },
    doctors: { view: true, add: true, edit: true, delete: false },
    donors: { view: true, add: true, edit: true, delete: false },
    business: { view: true, add: true, edit: true, delete: false },
    persons: { view: true, add: true, edit: true, delete: false },
    complaints: { view: true, add: false, edit: false, delete: false },
    budget: { view: true, add: false, edit: false, delete: false },
    emergency: { view: true, add: true, edit: true, delete: false },
    notifications: { view: true, add: true, edit: true, delete: true },
    users: { view: true, add: false, edit: false, delete: false },
    serviceDirectory: { view: true, add: true, edit: true, delete: false },
    profile: { view: true, add: true, edit: true, delete: false },
  },
  acLand: {
    dashboard: { view: true, add: false, edit: false, delete: false },
    notices: { view: true, add: true, edit: true, delete: false },
    officers: { view: true, add: false, edit: false, delete: false },
    serviceItems: { view: true, add: true, edit: true, delete: false },
    clinics: { view: true, add: false, edit: false, delete: false },
    doctors: { view: true, add: false, edit: false, delete: false },
    donors: { view: true, add: false, edit: false, delete: false },
    business: { view: true, add: false, edit: false, delete: false },
    persons: { view: true, add: false, edit: false, delete: false },
    complaints: { view: true, add: true, edit: true, delete: false },
    budget: { view: true, add: false, edit: false, delete: false },
    emergency: { view: true, add: false, edit: false, delete: false },
    notifications: { view: true, add: true, edit: false, delete: false },
    users: { view: true, add: false, edit: false, delete: false },
    serviceDirectory: { view: true, add: true, edit: true, delete: true },
    profile: { view: true, add: true, edit: true, delete: false },
  },
  developer: {
    dashboard: { view: true, add: false, edit: false, delete: false },
    notices: { view: true, add: true, edit: true, delete: true },
    officers: { view: true, add: true, edit: true, delete: true },
    serviceItems: { view: true, add: true, edit: true, delete: true },
    clinics: { view: true, add: true, edit: true, delete: true },
    doctors: { view: true, add: true, edit: true, delete: true },
    donors: { view: true, add: true, edit: true, delete: true },
    business: { view: true, add: true, edit: true, delete: true },
    persons: { view: true, add: true, edit: true, delete: true },
    complaints: { view: true, add: false, edit: false, delete: false },
    budget: { view: true, add: false, edit: false, delete: false },
    emergency: { view: true, add: true, edit: true, delete: true },
    notifications: { view: true, add: true, edit: true, delete: true },
    users: { view: true, add: false, edit: false, delete: false },
    serviceDirectory: { view: true, add: true, edit: true, delete: true },
    profile: { view: true, add: true, edit: true, delete: false },
  },
};

// Sidebar menu items with RBAC
export interface MenuItem {
  id: string;
  label: string;
  icon: string;
  module?: string;
  children?: MenuItem[];
  roles?: UserRole[];
}

export const SIDEBAR_MENU: MenuItem[] = [
  {
    id: 'dashboard',
    label: 'ড্যাশবোর্ড',
    icon: 'LayoutDashboard',
    module: 'dashboard',
  },
  {
    id: 'notices',
    label: 'নোটিশ বোর্ড',
    icon: 'Megaphone',
    module: 'notices',
  },
  {
    id: 'service-directory',
    label: 'সার্ভিস ডিরেক্টরি',
    icon: 'FolderTree',
    module: 'serviceDirectory',
  },
  {
    id: 'govt-services',
    label: 'সরকারি সেবা',
    icon: 'Landmark',
    children: [
      { id: 'officers', label: 'সরকারি কর্মকর্তা', icon: 'UserCheck', module: 'officers' },
      { id: 'service-items', label: 'সেবা আইটেম', icon: 'FileText', module: 'serviceItems' },
      { id: 'emergency', label: 'জরুরি নম্বর', icon: 'PhoneCall', module: 'emergency' },
    ],
  },
  {
    id: 'health',
    label: 'স্বাস্থ্য সেবা',
    icon: 'HeartPulse',
    children: [
      { id: 'clinics', label: 'ক্লিনিক/হাসপাতাল', icon: 'Building2', module: 'clinics' },
      { id: 'doctors', label: 'বিশেষজ্ঞ চিকিৎসক', icon: 'Stethoscope', module: 'doctors' },
    ],
  },
  {
    id: 'community',
    label: 'সম্প্রদায়',
    icon: 'Users',
    children: [
      { id: 'donors', label: 'রক্তদাতা', icon: 'Droplets', module: 'donors' },
      { id: 'business', label: 'ব্যবসা প্রতিষ্ঠান', icon: 'Store', module: 'business' },
      { id: 'persons', label: 'বিশিষ্ট ব্যক্তি', icon: 'Award', module: 'persons' },
      { id: 'complaints', label: 'অভিযোগ ব্যবস্থাপনা', icon: 'MessageSquareWarning', module: 'complaints' },
    ],
  },
  {
    id: 'admin',
    label: 'প্রশাসন',
    icon: 'Shield',
    children: [
      { id: 'reports', label: 'রিপোর্ট', icon: 'BarChart3', module: 'dashboard' },
      { id: 'budget', label: 'বাজেট ও উন্নয়ন', icon: 'PieChart', module: 'budget' },
      { id: 'notifications', label: 'নোটিফিকেশন', icon: 'Bell', module: 'notifications' },
      { id: 'users', label: 'ব্যবহারকারী', icon: 'UserCog', module: 'users' },
      { id: 'auditLog', label: 'সিস্টেম লগ', icon: 'Activity', module: 'users' },
      { id: 'settings', label: 'সেটিংস', icon: 'Settings', module: 'dashboard' },
    ],
  },
  {
    id: 'profile',
    label: 'প্রোফাইল',
    icon: 'CircleUserRound',
    module: 'profile',
  },
];