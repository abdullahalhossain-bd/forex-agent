// Mock data for Betagi E-Sheba Admin Portal

import type {
  User, Notice, GovtOfficer, GovtServiceItem, Clinic, Doctor,
  Donor, BusinessItem, Person, Complaint, BudgetItem, EmergencyNumber,
  Notification, DashboardStats, ServiceDirectoryItem
} from '@/types/admin';

export const MOCK_USERS: User[] = [
  { id: 1, name: 'মোঃ আব্দুল করিম', email: 'admin@betagi.gov.bd', phone: '01711111111', role: 'admin', union: 'বেতাগী সদর', createdAt: '2024-01-15' },
  { id: 2, name: 'মোসাঃ ফাতেমা বেগম', email: 'uno@betagi.gov.bd', phone: '01722222222', role: 'uno', union: 'বেতাগী সদর', createdAt: '2024-02-10' },
  { id: 3, name: 'মোঃ রহিম হোসেন', email: 'ict@betagi.gov.bd', phone: '01733333333', role: 'ict', union: 'বেতাগী সদর', createdAt: '2024-03-05' },
  { id: 4, name: 'মোঃ সোহেল রানা', email: 'dev@betagi.gov.bd', phone: '01744444444', role: 'developer', union: 'চরবাড়ি', createdAt: '2024-04-20' },
  { id: 7, name: 'মোঃ জাহিদ হোসেন', email: 'acland@betagi.gov.bd', phone: '01777777777', role: 'acLand', union: 'বেতাগী সদর', createdAt: '2024-04-01' },
  { id: 5, name: 'মোসাঃ নাসরিন আক্তার', email: 'nasrin@betagi.gov.bd', phone: '01755555555', role: 'ict', union: 'বেতাগী সদর', createdAt: '2024-05-12' },
  { id: 6, name: 'মোঃ কামরুজ্জামান', email: 'kamru@betagi.gov.bd', phone: '01766666666', role: 'uno', union: 'পাতারহাট', createdAt: '2024-06-01' },
];

export const MOCK_NOTICES: Notice[] = [
  { id: 1, title: 'উপজেলা প্রশাসনের নিয়মিত সভা', description: 'আগামী রবিবার সকাল ১০টায় উপজেলা পরিষদ মিলনায়তনে নিয়মিত সভা অনুষ্ঠিত হবে। সকল বিভাগীয় প্রধানদের উপস্থিত থাকতে অনুরোধ করা হচ্ছে।', category: 'গুরুত্বপূর্ণ', status: 'সক্রিয়', createdAt: '2025-07-20', updatedAt: '2025-07-20' },
  { id: 2, title: 'ডেঙ্গু প্রতিরোধে পরিচ্ছন্নতা অভিযান', description: 'ডেঙ্গু মৌসুমে পরিচ্ছন্নতা অভিযান পরিচালনার জন্য সকল ইউনিয়ন পরিষদকে প্রস্তুত থাকতে নির্দেশ দেওয়া হলো।', category: 'গুরুত্বপূর্ণ', status: 'সক্রিয়', createdAt: '2025-07-18', updatedAt: '2025-07-18' },
  { id: 3, title: 'ঈদুল আযহা ছুটি বিজ্ঞপ্তি', description: 'আগামী ঈদুল আযহা উপলক্ষে উপজেলা কার্যালয় ৫ দিন বন্ধ থাকবে।', category: 'ছুটি', status: 'সক্রিয়', createdAt: '2025-07-15', updatedAt: '2025-07-15' },
  { id: 4, title: 'বৃক্ষরোপণ কর্মসূচি ২০২৫', description: 'জাতীয় বৃক্ষরোপণ অভিযান উপলক্ষে আগামী ১৬ জুলাই উপজেলা পরিষদ প্রাঙ্গণে বৃক্ষরোপণ কর্মসূচি পালিত হবে।', category: 'ইভেন্ট', status: 'সক্রিয়', createdAt: '2025-07-10', updatedAt: '2025-07-10' },
  { id: 5, title: 'জন্ম নিবন্ধন সেবা সময়সূচি পরিবর্তন', description: 'জন্ম নিবন্ধন সেবা এখন থেকে রবি ও বুধবার সকাল ৯টা থেকে বিকাল ৩টা পর্যন্ত প্রদান করা হবে।', category: 'সাধারণ', status: 'সক্রিয়', createdAt: '2025-07-08', updatedAt: '2025-07-08' },
  { id: 6, title: 'মাসিক সমন্বয় সভার তারিখ ঘোষণা', description: 'আগামী মাসের সমন্বয় সভা ৫ তারিখ অনুষ্ঠিত হবে। সকল সদস্যদের রিপোর্ট প্রস্তুত রাখতে অনুরোধ।', category: 'সাধারণ', status: 'নিষ্ক্রিয়', createdAt: '2025-06-25', updatedAt: '2025-07-01' },
];

export const MOCK_OFFICERS: GovtOfficer[] = [
  { id: 1, name: 'মোঃ আনোয়ার হোসেন', designation: 'উপজেলা নির্বাহী অফিসার', department: 'প্রশাসন', phone: '0434561001', email: 'uno@betagi.gov.bd', office: 'উপজেলা নির্বাহী অফিসারের কার্যালয়', address: 'বেতাগী, বরিশাল', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 2, name: 'মোঃ শফিকুল ইসলাম', designation: 'আইসিটি অফিসার', department: 'তথ্য ও যোগাযোগ প্রযুক্তি', phone: '0434561002', email: 'ict@betagi.gov.bd', office: 'উপজেলা আইসিটি সেল', address: 'বেতাগী, বরিশাল', status: 'সক্রিয়', createdAt: '2024-02-01' },
  { id: 3, name: 'মোসাঃ রেহানা বেগম', designation: 'উপজেলা কৃষি অফিসার', department: 'কৃষি', phone: '0434561003', email: 'agri@betagi.gov.bd', office: 'উপজেলা কৃষি অফিস', address: 'বেতাগী, বরিশাল', status: 'সক্রিয়', createdAt: '2024-02-15' },
  { id: 4, name: 'ডাঃ মোঃ কামরুল হাসান', designation: 'উপজেলা স্বাস্থ্য ও পরিবার পরিকল্পনা কর্মকর্তা', department: 'স্বাস্থ্য', phone: '0434561004', email: 'uhfpo@betagi.gov.bd', office: 'উপজেলা স্বাস্থ্য কমপ্লেক্স', address: 'বেতাগী, বরিশাল', status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 5, name: 'মোঃ আবদুল্লাহ আল মামুন', designation: 'উপজেলা শিক্ষা অফিসার', department: 'শিক্ষা', phone: '0434561005', email: 'edu@betagi.gov.bd', office: 'উপজেলা শিক্ষা অফিস', address: 'বেতাগী, বরিশাল', status: 'সক্রিয়', createdAt: '2024-03-15' },
  { id: 6, name: 'মোঃ জাহিদ হোসেন', designation: 'সহকারী কমিশনার (ভূমি)', department: 'ভূমি', phone: '0434561006', email: 'land@betagi.gov.bd', office: 'সহকারী কমিশনারের কার্যালয়', address: 'বেতাগী, বরিশাল', status: 'সক্রিয়', createdAt: '2024-04-01' },
];

export const MOCK_SERVICE_ITEMS: GovtServiceItem[] = [
  { id: 1, name: 'জন্ম নিবন্ধন', nameEn: 'Birth Registration', category: 'নিবন্ধন', description: 'নতুন জন্ম নিবন্ধন ও সংশোধন', fee: 0, requiredDocs: 'জন্মের প্রমাণপত্র, অভিভাবকের এনআইডি', process: 'আবেদন → যাচাই → প্রদান', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 2, name: 'মৃত্যু নিবন্ধন', nameEn: 'Death Registration', category: 'নিবন্ধন', description: 'মৃত্যু নিবন্ধন সেবা', fee: 0, requiredDocs: 'মৃত্যু সনদপত্র, আবেদনকারীর এনআইডি', process: 'আবেদন → যাচাই → প্রদান', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 3, name: 'চারিত্রিক সনদপত্র', nameEn: 'Character Certificate', category: 'সনদপত্র', description: 'চারিত্রিক সনদপত্র প্রদান', fee: 50, requiredDocs: 'আবেদন ফরম, এনআইডি কপি', process: 'আবেদন → পুলিশ যাচাই → প্রদান', status: 'সক্রিয়', createdAt: '2024-01-20' },
  { id: 4, name: 'নাগরিকত্ব সনদপত্র', nameEn: 'Citizenship Certificate', category: 'সনদপত্র', description: 'নাগরিকত্ব সনদপত্র প্রদান', fee: 50, requiredDocs: 'আবেদন ফরম, এনআইডি, পিতামাতার তথ্য', process: 'আবেদন → যাচাই → প্রদান', status: 'সক্রিয়', createdAt: '2024-01-20' },
  { id: 5, name: 'ওয়ারিশ সনদপত্র', nameEn: 'Heir Certificate', category: 'সনদপত্র', description: 'ওয়ারিশ সনদপত্র প্রদান', fee: 100, requiredDocs: 'মৃত ব্যক্তির মৃত্যু সনদ, আবেদনকারীদের এনআইডি', process: 'আবেদন → তদন্ত → প্রদান', status: 'সক্রিয়', createdAt: '2024-02-01' },
  { id: 6, name: 'ভূমিহীন সনদপত্র', nameEn: 'Landless Certificate', category: 'সনদপত্র', description: 'ভূমিহীন প্রমাণপত্র', fee: 50, requiredDocs: 'আবেদন ফরম, এনআইডি, ওয়ার্ড কাউন্সিলরের প্রত্যয়ন', process: 'আবেদন → যাচাই → প্রদান', status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 7, name: 'বিবাহিত সনদপত্র', nameEn: 'Marriage Certificate', category: 'সনদপত্র', description: 'বিবাহিত সনদপত্র', fee: 50, requiredDocs: 'আবেদন ফরম, এনআইডি, কাজীর নামা', process: 'আবেদন → যাচাই → প্রদান', status: 'সক্রিয়', createdAt: '2024-02-15' },
  { id: 8, name: 'ট্রেড লাইসেন্স', nameEn: 'Trade License', category: 'লাইসেন্স', description: 'ব্যবসায়িক ট্রেড লাইসেন্স', fee: 500, requiredDocs: 'আবেদন ফরম, প্রতিষ্ঠানের নাম, ঠিকানা', process: 'আবেদন → পরিদর্শন → প্রদান', status: 'সক্রিয়', createdAt: '2024-03-01' },
];

export const MOCK_CLINICS: Clinic[] = [
  { id: 1, name: 'বেতাগী উপজেলা স্বাস্থ্য কমপ্লেক্স', type: 'সরকারি', address: 'বেতাগী, বরিশাল', phone: '0434561100', doctorName: 'ডাঃ কামরুল হাসান', specialization: 'সাধারণ চিকিৎসা', schedule: 'সকাল ৮টা - বিকাল ৫টা', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 2, name: 'বেতাগী মডেল ক্লিনিক', type: 'বেসরকারি', address: 'বেতাগী বাজার, বরিশাল', phone: '01712345001', doctorName: 'ডাঃ মাহমুদুল হক', specialization: 'মেডিসিন', schedule: 'সকাল ৯টা - রাত ১০টা', status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 3, name: 'চরবাড়ি ইউনিয়ন স্বাস্থ্য কেন্দ্র', type: 'সরকারি', address: 'চরবাড়ি, বেতাগী', phone: '0434561101', doctorName: 'ডাঃ সাইদুর রহমান', specialization: 'সাধারণ চিকিৎসা', schedule: 'সকাল ৯টা - বিকাল ৪টা', status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 4, name: 'পাতারহাট কমিউনিটি ক্লিনিক', type: 'সরকারি', address: 'পাতারহাট, বেতাগী', phone: '0434561102', specialization: 'মাতৃস্বাস্থ্য', schedule: 'সকাল ৯টা - বিকাল ৩টা', status: 'সক্রিয়', createdAt: '2024-03-15' },
  { id: 5, name: 'আল-আমিন ডায়াগনস্টিক সেন্টার', type: 'বেসরকারি', address: 'বেতাগী বাসস্ট্যান্ড, বরিশাল', phone: '01712345002', doctorName: 'ডাঃ আশরাফুল হক', specialization: 'ডায়াগনস্টিক', schedule: 'সকাল ৮টা - রাত ১২টা', status: 'সক্রিয়', createdAt: '2024-04-01' },
];

export const MOCK_DOCTORS: Doctor[] = [
  { id: 1, name: 'ডাঃ কামরুল হাসান', specialization: 'মেডিসিন', qualification: 'এমবিবিএস, এফসিপিএস', phone: '01712345601', chamber: 'উপজেলা স্বাস্থ্য কমপ্লেক্স', schedule: 'সকাল ৮টা - বিকাল ৫টা', fee: 0, bloodGroup: 'B+', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 2, name: 'ডাঃ মাহমুদুল হক', specialization: 'গাইনি', qualification: 'এমবিবিএস, ডিজিও', phone: '01712345602', chamber: 'বেতাগী মডেল ক্লিনিক', schedule: 'সন্ধ্যা ৬টা - রাত ১০টা', fee: 500, bloodGroup: 'O+', status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 3, name: 'ডাঃ সাইদুর রহমান', specialization: 'শিশু রোগ', qualification: 'এমবিবিএস, এমডি', phone: '01712345603', chamber: 'চরবাড়ি স্বাস্থ্য কেন্দ্র', schedule: 'সকাল ৯টা - বিকাল ৪টা', fee: 0, bloodGroup: 'A+', status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 4, name: 'ডাঃ আশরাফুল হক', specialization: 'অর্থোপেডিক্স', qualification: 'এমবিবিএস, এমএস', phone: '01712345604', chamber: 'আল-আমিন ডায়াগনস্টিক', schedule: 'বিকাল ৪টা - রাত ৯টা', fee: 600, bloodGroup: 'AB+', status: 'সক্রিয়', createdAt: '2024-04-01' },
  { id: 5, name: 'ডাঃ নাজমা বেগম', specialization: 'চক্ষু রোগ', qualification: 'এমবিবিএস, ডিও', phone: '01712345605', chamber: 'নাজমা আই কেয়ার', schedule: 'সকাল ১০টা - বিকাল ৫টা', fee: 400, bloodGroup: 'A-', status: 'সক্রিয়', createdAt: '2024-05-01' },
];

export const MOCK_DONORS: Donor[] = [
  { id: 1, name: 'মোঃ রাসেল মিয়া', phone: '01711112222', bloodGroup: 'A+', address: 'বেতাগী সদর', lastDonation: '2025-05-15', totalDonation: 5, status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 2, name: 'মোঃ সাগর হোসেন', phone: '01722223333', bloodGroup: 'B+', address: 'পাতারহাট', lastDonation: '2025-06-01', totalDonation: 3, status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 3, name: 'মোঃ ফারুক হোসেন', phone: '01733334444', bloodGroup: 'O+', address: 'চরবাড়ি', lastDonation: '2025-03-20', totalDonation: 8, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 4, name: 'মোসাঃ তাসনিম আক্তার', phone: '01744445555', bloodGroup: 'AB+', address: 'বেতাগী সদর', lastDonation: '2025-04-10', totalDonation: 2, status: 'সক্রিয়', createdAt: '2024-04-15' },
  { id: 5, name: 'মোঃ ইমরান হোসেন', phone: '01755556666', bloodGroup: 'O-', address: 'হলদিয়া', lastDonation: '2025-06-20', totalDonation: 12, status: 'সক্রিয়', createdAt: '2024-05-10' },
  { id: 6, name: 'মোঃ নাজমুল ইসলাম', phone: '01766667777', bloodGroup: 'B-', address: 'বেতাগী সদর', lastDonation: '2024-12-05', totalDonation: 1, status: 'নিষ্ক্রিয়', createdAt: '2024-06-01' },
];

export const MOCK_BUSINESS: BusinessItem[] = [
  { id: 1, name: 'বেতাগী মডেল মার্কেট', category: 'শপিং মল', ownerName: 'মোঃ আলম হোসেন', phone: '01710001001', address: 'বেতাগী বাজার', description: 'বিভিন্ন পণ্যের শপিং মল', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 2, name: 'আল-আমিন ডায়াগনস্টিক সেন্টার', category: 'স্বাস্থ্য সেবা', ownerName: 'ডাঃ আশরাফুল হক', phone: '01712345002', address: 'বেতাগী বাসস্ট্যান্ড', status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 3, name: 'গ্রীন টি হাউজ', category: 'খাদ্য ও পানীয়', ownerName: 'মোঃ কামরুল ইসলাম', phone: '01710001002', address: 'বেতাগী কলেজ রোড', description: 'চা ও স্ন্যাকস', status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 4, name: 'সেন্ট্রাল ফার্মেসি', category: 'ওষুধ', ownerName: 'মোঃ জাহিদ হাসান', phone: '01710001003', address: 'বেতাগী বাজার', description: 'সকল ধরনের ওষুধ প্রাপ্য', status: 'সক্রিয়', createdAt: '2024-03-15' },
  { id: 5, name: 'বরিশাল রেস্টুরেন্ট', category: 'খাদ্য ও পানীয়', ownerName: 'মোঃ সোহেল রানা', phone: '01710001004', address: 'বেতাগী বাসস্ট্যান্ড', description: 'বাঙালি ও চাইনিজ খাবার', status: 'সক্রিয়', createdAt: '2024-04-01' },
];

export const MOCK_PERSONS: Person[] = [
  { id: 1, name: 'মোঃ আব্দুল লতিফ তালুকদার', designation: 'সাবেক চেয়ারম্যান', category: 'রাজনীতিবিদ', phone: '01781110001', address: 'বেতাগী সদর', details: 'বেতাগী উপজেলার সাবেক চেয়ারম্যান', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 2, name: 'প্রফেসর মোঃ আনোয়ারুল ইসলাম', designation: 'শিক্ষাবিদ', category: 'শিক্ষাবিদ', phone: '01781110002', address: 'পাতারহাট', details: 'বেতাগী কলেজের সাবেক অধ্যক্ষ', status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 3, name: 'মোসাঃ সালেহা বেগম', designation: 'সমাজসেবী', category: 'সমাজসেবী', phone: '01781110003', address: 'চরবাড়ি', details: 'নারী উন্নয়নে অবদান', status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 4, name: 'মোঃ শাহজাহান মিয়া', designation: 'মুক্তিযোদ্ধা', category: 'মুক্তিযোদ্ধা', phone: '01781110004', address: 'বেতাগী সদর', status: 'সক্রিয়', createdAt: '2024-03-15' },
];

export const MOCK_COMPLAINTS: Complaint[] = [
  { id: 1, name: 'মোঃ হাবিবুর রহমান', phone: '01790001001', union: 'বেতাগী সদর', category: 'রাস্তা ও অবকাঠামো', subject: 'পানি নিষ্কাশনের সমস্যা', description: 'বর্ষামৌসুমে পানি নিষ্কাশন ব্যবস্থা ভেঙে পড়ে। রাস্তায় পানি জমে থাকে।', status: 'পর্যালোচনাধীন', priority: 'উচ্চ', createdAt: '2025-07-18', updatedAt: '2025-07-19' },
  { id: 2, name: 'মোসাঃ রহিমা বেগম', phone: '01790001002', union: 'চরবাড়ি', category: 'স্বাস্থ্য সেবা', subject: 'স্বাস্থ্য কেন্দ্রে ওষুধের অভাব', description: 'চরবাড়ি ইউনিয়ন স্বাস্থ্য কেন্দ্রে নিয়মিত ওষুধ পাওয়া যায় না।', status: 'পেন্ডিং', priority: 'উচ্চ', createdAt: '2025-07-17', updatedAt: '2025-07-17' },
  { id: 3, name: 'মোঃ জাহিদ হোসেন', phone: '01790001003', union: 'পাতারহাট', category: 'শিক্ষা', subject: 'স্কুলের ভবন মেরামত প্রয়োজন', description: 'পাতারহাট সরকারি প্রাথমিক বিদ্যালয়ের ছাদ ফাটল হয়ে গেছে।', status: 'সমাধানকৃত', priority: 'মাঝারি', createdAt: '2025-07-10', updatedAt: '2025-07-15' },
  { id: 4, name: 'মোঃ নাসির উদ্দিন', phone: '01790001004', union: 'বেতাগী সদর', category: 'পানি সরবরাহ', subject: 'পানির সংযোগ নেই', description: 'আমাদের এলাকায় এখনো বিশুদ্ধ পানির সংযোগ দেওয়া হয়নি।', status: 'পেন্ডিং', priority: 'উচ্চ', createdAt: '2025-07-15', updatedAt: '2025-07-15' },
  { id: 5, name: 'মোঃ আলী আকবর', phone: '01790001005', union: 'হলদিয়া', category: 'অন্যান্য', subject: 'বাজারে অসাধু ব্যবসা', description: 'বেতাগী বাজারে কিছু ব্যবসায়ী মূল্য তালিকা মানছে না।', status: 'বাতিল', priority: 'নিম্ন', createdAt: '2025-07-05', updatedAt: '2025-07-12' },
];

export const MOCK_BUDGET: BudgetItem[] = [
  { id: 1, category: 'রাস্তা ও অবকাঠামো', allocated: 182000000, spent: 128400000, fiscalYear: '2024-2025', description: 'সড়ক নির্মাণ, সংস্কার ও ব্রিজ', createdAt: '2024-07-01' },
  { id: 2, category: 'শিক্ষা', allocated: 130000000, spent: 95000000, fiscalYear: '2024-2025', description: 'বিদ্যালয় নির্মাণ, মেরামত ও শিক্ষা উপকরণ', createdAt: '2024-07-01' },
  { id: 3, category: 'স্বাস্থ্য', allocated: 104000000, spent: 68000000, fiscalYear: '2024-2025', description: 'স্বাস্থ্য কমপ্লেক্স, ক্লিনিক ও ওষুধ', createdAt: '2024-07-01' },
  { id: 4, category: 'কৃষি', allocated: 62400000, spent: 32000000, fiscalYear: '2024-2025', description: 'কৃষি উপকরণ, সেচ ব্যবস্থা ও প্রশিক্ষণ', createdAt: '2024-07-01' },
  { id: 5, category: 'সমাজসেবা', allocated: 41600000, spent: 29000000, fiscalYear: '2024-2025', description: 'ভাতা, প্রশিক্ষণ ও কল্যাণ কর্মসূচি', createdAt: '2024-07-01' },
];

export const MOCK_EMERGENCY: EmergencyNumber[] = [
  { id: 1, name: 'জাতীয় জরুরি সেবা', number: '৯৯৯', category: 'জরুরি', description: 'পুলিশ, ফায়ার সার্ভিস ও অ্যাম্বুলেন্স', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 2, name: 'আইটি সাপোর্ট হেল্পলাইন', number: '১০৯', category: 'তথ্য প্রযুক্তি', description: 'তথ্য ও যোগাযোগ প্রযুক্তি সহায়তা', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 3, name: 'স্বাস্থ্য সেবা হেল্পলাইন', number: '১৬২৬৩', category: 'স্বাস্থ্য', description: 'স্বাস্থ্য বিষয়ক তথ্য ও সেবা', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 4, name: 'উপজেলা নির্বাহী অফিসার', number: '০৪৩৪৫৬১০০১', category: 'প্রশাসন', description: 'উপজেলা প্রশাসন', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 5, name: 'ফায়ার সার্ভিস', number: '০৪৩৪৫৬১১১১', category: 'জরুরি', description: 'অগ্নি নির্বাপণ সেবা', status: 'সক্রিয়', createdAt: '2024-02-01' },
  { id: 6, name: 'থানা', number: '০৪৩৪৫৬১২২২', category: 'আইন শৃঙ্খলা', description: 'থানা পুলিশ', status: 'সক্রিয়', createdAt: '2024-02-01' },
  { id: 7, name: 'বিদ্যুৎ সমস্যা', number: '১৬১৬২', category: 'সেবা', description: 'বিদ্যুৎ সংযোগ ও সমস্যা', status: 'সক্রিয়', createdAt: '2024-03-01' },
];

export const MOCK_NOTIFICATIONS: Notification[] = [
  { id: 1, title: 'নতুন অভিযোগ জমা হয়েছে', message: 'রাস্তা ও অবকাঠামো বিভাগে নতুন অভিযোগ জমা হয়েছে।', type: 'তথ্য', targetRole: 'admin', isRead: false, createdAt: '2025-07-20T10:30:00' },
  { id: 2, title: 'সভার অনুস্মারক', message: 'আগামীকাল সকাল ১০টায় সমন্বয় সভা অনুষ্ঠিত হবে।', type: 'সতর্কতা', targetRole: 'uno', isRead: false, createdAt: '2025-07-20T09:00:00' },
  { id: 3, title: 'সিস্টেম আপডেট', message: 'বেতাগী ই-সেবা অ্যাপ ভার্সন ২.০ আপডেট প্রকাশিত হয়েছে।', type: 'সাধারণ', targetRole: 'ict', isRead: true, createdAt: '2025-07-19T15:00:00' },
  { id: 4, title: 'বাজেট অনুমোদন', message: '২০২৪-২৫ অর্থবছরের বাজেট চূড়ান্ত অনুমোদন দেওয়া হয়েছে।', type: 'তথ্য', targetRole: 'admin', isRead: true, createdAt: '2025-07-18T11:00:00' },
  { id: 5, title: 'ডেঙ্গু সতর্কতা', message: 'ডেঙ্গু প্রতিরোধে সকল ইউনিয়নে পরিচ্ছন্নতা অভিযান শুরু করুন।', type: 'জরুরি', targetRole: 'সবাই', isRead: false, createdAt: '2025-07-18T08:00:00' },
];

export const MOCK_DASHBOARD_STATS: DashboardStats = {
  totalCitizens: 12450,
  totalOfficers: 6,
  totalClinics: 5,
  totalDoctors: 5,
  totalDonors: 6,
  totalBusiness: 5,
  totalComplaints: 5,
  resolvedComplaints: 1,
  pendingComplaints: 2,
  totalNotices: 6,
  totalBudget: 520000000,
  spentBudget: 352400000,
};

export const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as const;
export const NOTICE_CATEGORIES = ['গুরুত্বপূর্ণ', 'সাধারণ', 'ইভেন্ট', 'ছুটি', 'অন্যান্য'] as const;
export const COMPLAINT_STATUSES = ['পেন্ডিং', 'পর্যালোচনাধীন', 'সমাধানকৃত', 'বাতিল'] as const;
export const COMPLAINT_PRIORITIES = ['উচ্চ', 'মাঝারি', 'নিম্ন'] as const;
export const BUSINESS_CATEGORIES = ['শপিং মল', 'স্বাস্থ্য সেবা', 'খাদ্য ও পানীয়', 'ওষুধ', 'শিক্ষা', 'কৃষি', 'পোশাক', 'ইলেকট্রনিক্স', 'অন্যান্য'] as const;
export const EMERGENCY_CATEGORIES = ['জরুরি', 'স্বাস্থ্য', 'প্রশাসন', 'আইন শৃঙ্খলা', 'তথ্য প্রযুক্তি', 'সেবা', 'অন্যান্য'] as const;
export const PERSON_CATEGORIES = ['রাজনীতিবিদ', 'শিক্ষাবিদ', 'সমাজসেবী', 'মুক্তিযোদ্ধা', 'সাংস্কৃতিক ব্যক্তিত্ব', 'ক্রীড়াবিদ', 'ব্যবসায়ী', 'অন্যান্য'] as const;
export const NOTIFICATION_TYPES = ['তথ্য', 'সতর্কতা', 'জরুরি', 'সাধারণ'] as const;

export const SERVICE_DIRECTORY_CATEGORIES = [
  'স্বাস্থ্য সেবা',
  'সাধারণ সেবা',
  'ইতিহাস ও ঐতিহ্য',
  'মিস্ত্রি সেবা',
  'জরুরি সেবা',
  'আইন ও বিচার',
  'শিক্ষা',
  'কৃষি',
  'নারী ও পরিবার কল্যাণ',
  'সামাজিক সংগঠন',
  'গৃহ ও দৈনন্দিন সেবা',
  'পরিবহন',
] as const;

export const MOCK_SERVICE_DIRECTORY: ServiceDirectoryItem[] = [
  // ====== স্বাস্থ্য সেবা (Health Services) ======
  { id: 1, name: 'হাসপাতাল', nameEn: 'Hospital', category: 'স্বাস্থ্য সেবা', categoryGroup: 'health', description: 'উপজেলার সকল সরকারি ও বেসরকারি হাসপাতালের তালিকা', totalEntries: 3, status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 2, name: 'ক্লিনিক', nameEn: 'Clinic', category: 'স্বাস্থ্য সেবা', categoryGroup: 'health', description: 'বেসরকারি ক্লিনিক ও ডায়াগনস্টিক সেন্টার', totalEntries: 7, status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 3, name: 'উপজেলা ডাক্তার', nameEn: 'Upazila Doctor', category: 'স্বাস্থ্য সেবা', categoryGroup: 'health', description: 'উপজেলা স্বাস্থ্য কমপ্লেক্সের নিয়োজিত চিকিৎসক', totalEntries: 4, status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 4, name: 'ডাক্তার', nameEn: 'Doctor', category: 'স্বাস্থ্য সেবা', categoryGroup: 'health', description: 'বিশেষজ্ঞ চিকিৎসকদের তালিকা ও চেম্বার সময়সূচি', totalEntries: 12, status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 5, name: 'পশু ডাক্তার', nameEn: 'Veterinarian', category: 'স্বাস্থ্য সেবা', categoryGroup: 'health', description: 'পশু চিকিৎসক ও ভেটেরিনারি সেবা', phone: '০৪৩৪৫৬১১০৫', totalEntries: 3, status: 'সক্রিয়', createdAt: '2024-02-01' },
  { id: 6, name: 'নার্স সেবা', nameEn: 'Nurse Service', category: 'স্বাস্থ্য সেবা', categoryGroup: 'health', description: 'গৃহ পরিচর্যা ও নার্সিং সেবা প্রদানকারী', totalEntries: 8, status: 'সক্রিয়', createdAt: '2024-02-01' },
  { id: 7, name: 'ফার্মেসি', nameEn: 'Pharmacy', category: 'স্বাস্থ্য সেবা', categoryGroup: 'health', description: 'ওষুধের দোকান ও ফার্মেসির তালিকা', totalEntries: 15, status: 'সক্রিয়', createdAt: '2024-01-20' },
  { id: 8, name: 'অ্যাম্বুলেন্স', nameEn: 'Ambulance', category: 'স্বাস্থ্য সেবা', categoryGroup: 'health', description: 'অ্যাম্বুলেন্স সেবা ও জরুরি রোগী পরিবহন', phone: '০৪৩৪৫৬১১০৬', totalEntries: 5, status: 'সক্রিয়', createdAt: '2024-01-20' },
  { id: 9, name: 'ব্লাড ডোনার', nameEn: 'Blood Donor', category: 'স্বাস্থ্য সেবা', categoryGroup: 'health', description: 'রক্তদাতাদের তালিকা ও রক্তের গ্রুপ অনুযায়ী তথ্য', totalEntries: 45, status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 10, name: 'নার্সিং হোম', nameEn: 'Nursing Home', category: 'স্বাস্থ্য সেবা', categoryGroup: 'health', description: 'নার্সিং হোম ও মাতৃস্বাস্থ্য কেন্দ্র', totalEntries: 2, status: 'সক্রিয়', createdAt: '2024-03-01' },

  // ====== সাধারণ সেবা (General Services) ======
  { id: 11, name: 'দর্শনীয় স্থান', nameEn: 'Tourist Spot', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'উপজেলার দর্শনীয় স্থান ও পর্যটন কেন্দ্র', totalEntries: 6, status: 'সক্রিয়', createdAt: '2024-02-01' },
  { id: 12, name: 'হোটেল', nameEn: 'Hotel', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'হোটেল, মোটেল ও আবাসিক হোটেল', totalEntries: 4, status: 'সক্রিয়', createdAt: '2024-02-01' },
  { id: 13, name: 'পত্রিকা', nameEn: 'Newspaper', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'স্থানীয় পত্রিকা ও সাংবাদিকতা', totalEntries: 3, status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 14, name: 'উপজেলা তথ্য', nameEn: 'Upazila Info', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'উপজেলা সম্পর্কে সাধারণ তথ্য', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 15, name: 'নার্সারি দোকান', nameEn: 'Nursery Shop', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'প্রজনন ও বীজের নার্সারি', totalEntries: 8, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 16, name: 'কুরিয়ার সার্ভিস', nameEn: 'Courier Service', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'কুরিয়ার ও পার্সেল সার্ভিস', totalEntries: 5, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 17, name: 'পোষ্ট অফিস', nameEn: 'Post Office', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'পোস্ট অফিস ও ডাক সেবা', phone: '০৪৩৪৫৬১০৭০', totalEntries: 2, status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 18, name: 'শিক্ষা প্রতিষ্ঠান', nameEn: 'Educational Institution', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'বিদ্যালয়, কলেজ, মাদরাসা ও অন্যান্য শিক্ষা প্রতিষ্ঠান', totalEntries: 35, status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 19, name: 'ব্যাংক', nameEn: 'Bank', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'ব্যাংক ও আর্থিক প্রতিষ্ঠানের শাখা', totalEntries: 6, status: 'সক্রিয়', createdAt: '2024-01-20' },
  { id: 20, name: 'রেস্টুরেন্ট', nameEn: 'Restaurant', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'রেস্টুরেন্ট ও খাবারের দোকান', totalEntries: 10, status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 21, name: 'বিউটি পার্লার', nameEn: 'Beauty Parlor', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'বিউটি পার্লার ও সেলুন', totalEntries: 12, status: 'সক্রিয়', createdAt: '2024-02-15' },
  { id: 22, name: 'প্রশিক্ষণ কেন্দ্র', nameEn: 'Training Center', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'বিভিন্ন প্রশিক্ষণ কেন্দ্র ও ট্রেনিং ইনস্টিটিউট', totalEntries: 4, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 23, name: 'বিয়ের ঘটক', nameEn: 'Wedding Matchmaker', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'বিয়ের ঘটক ও ম্যাচমেকিং সেবা', totalEntries: 6, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 24, name: 'পল্লি বিদ্যুৎ', nameEn: 'Rural Electricity', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'বাংলাদেশ পল্লি বিদ্যুৎ সমিতি', phone: '০৪৩৪৫৬১০৮০', totalEntries: 1, status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 25, name: 'সাংবাদিক', nameEn: 'Journalist', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'স্থানীয় সাংবাদিকদের তালিকা ও যোগাযোগ', totalEntries: 15, status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 26, name: 'দোকান-শোরুম', nameEn: 'Shop & Showroom', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'বিভিন্ন ধরনের দোকান ও শোরুম', totalEntries: 50, status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 27, name: 'অনলাইন সার্ভিস', nameEn: 'Online Service', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'অনলাইন ভিত্তিক সেবা প্রদানকারী', totalEntries: 8, status: 'সক্রিয়', createdAt: '2024-03-15' },
  { id: 28, name: 'কোচিং সেন্টার', nameEn: 'Coaching Center', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'কোচিং সেন্টার ও টিউশন সেন্টার', totalEntries: 20, status: 'সক্রিয়', createdAt: '2024-02-01' },
  { id: 29, name: 'দলিল লেখক', nameEn: 'Deed Writer', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'দলিল লেখক ও নথি সহকারী', totalEntries: 10, status: 'সক্রিয়', createdAt: '2024-02-15' },
  { id: 30, name: 'সার্ভেয়ার', nameEn: 'Surveyor', category: 'সাধারণ সেবা', categoryGroup: 'general', description: 'জরিপকারক ও সার্ভেয়ার', totalEntries: 4, status: 'সক্রিয়', createdAt: '2024-02-15' },

  // ====== ইতিহাস ও ঐতিহ্য (History & Heritage) ======
  { id: 31, name: 'জুলাই বিপ্লব', nameEn: 'July Revolution', category: 'ইতিহাস ও ঐতিহ্য', categoryGroup: 'history', description: 'জুলাই ২০২৪ গণঅভ্যুত্থানের ইতিহাস', status: 'সক্রিয়', createdAt: '2024-08-01' },
  { id: 32, name: 'সকল সামরিক অভ্যুত্থান', nameEn: 'Military Coups', category: 'ইতিহাস ও ঐতিহ্য', categoryGroup: 'history', description: 'বাংলাদেশের ইতিহাসে সামরিক অভ্যুত্থানসমূহ', status: 'সক্রিয়', createdAt: '2024-08-01' },
  { id: 33, name: 'মহান মুক্তিযুদ্ধ', nameEn: 'Liberation War', category: 'ইতিহাস ও ঐতিহ্য', categoryGroup: 'history', description: '১৯৭১ সালের মহান মুক্তিযুদ্ধের ইতিহাস', status: 'সক্রিয়', createdAt: '2024-08-01' },

  // ====== মিস্ত্রি সেবা (Technician Services) ======
  { id: 34, name: 'কাঠের মিস্ত্রি', nameEn: 'Carpenter', category: 'মিস্ত্রি সেবা', categoryGroup: 'technician', description: 'কাঠের কাজ ও আসবাবপত্র তৈরি', totalEntries: 12, status: 'সক্রিয়', createdAt: '2024-02-01' },
  { id: 35, name: 'রাজমিস্ত্রি', nameEn: 'Mason', category: 'মিস্ত্রি সেবা', categoryGroup: 'technician', description: 'ভবন নির্মাণ ও মেরামতের কাজ', totalEntries: 15, status: 'সক্রিয়', createdAt: '2024-02-01' },
  { id: 36, name: 'রং মিস্ত্রি', nameEn: 'Painter', category: 'মিস্ত্রি সেবা', categoryGroup: 'technician', description: 'ঘরবাড়ি ও ভবন রং করার কাজ', totalEntries: 10, status: 'সক্রিয়', createdAt: '2024-02-01' },
  { id: 37, name: 'গাড়ি মেকার', nameEn: 'Car Mechanic', category: 'মিস্ত্রি সেবা', categoryGroup: 'technician', description: 'গাড়ি মেরামত ও সার্ভিসিং', totalEntries: 8, status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 38, name: 'ইলেক্ট্রনিকাল মেকার', nameEn: 'Electrical Repairer', category: 'মিস্ত্রি সেবা', categoryGroup: 'technician', description: 'ইলেকট্রনিক্স মেরামত ও সার্ভিসিং', totalEntries: 6, status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 39, name: 'দর্জি কারিগর', nameEn: 'Tailor', category: 'মিস্ত্রি সেবা', categoryGroup: 'technician', description: 'পোশাক তৈরি ও মেরামতের কাজ', totalEntries: 20, status: 'সক্রিয়', createdAt: '2024-02-10' },

  // ====== জরুরি সেবা (Emergency Services) ======
  { id: 40, name: 'জরুরি সেবা', nameEn: 'Emergency Service', category: 'জরুরি সেবা', categoryGroup: 'emergency', description: 'জরুরি সেবা প্রদানকারী সংস্থা', phone: '৯৯৯', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 41, name: 'জরুরী তথ্য', nameEn: 'Emergency Info', category: 'জরুরি সেবা', categoryGroup: 'emergency', description: 'জরুরি পরিস্থিতিতে প্রয়োজনীয় তথ্য', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 42, name: 'জরুরী নম্বার', nameEn: 'Emergency Number', category: 'জরুরি সেবা', categoryGroup: 'emergency', description: 'জরুরি যোগাযোগের নম্বর', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 43, name: 'থানা পুলিশ', nameEn: 'Police Station', category: 'জরুরি সেবা', categoryGroup: 'emergency', description: 'থানা পুলিশ ও আইন শৃঙ্খলা রক্ষাকারী বাহিনী', phone: '০৪৩৪৫৬১২২২', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 44, name: 'ফায়ার সার্ভিস', nameEn: 'Fire Service', category: 'জরুরি সেবা', categoryGroup: 'emergency', description: 'ফায়ার সার্ভিস ও সিভিল ডিফেন্স', phone: '০৪৩৪৫৬১১১১', status: 'সক্রিয়', createdAt: '2024-01-15' },
  { id: 45, name: 'সকল সিমের কোড', nameEn: 'SIM Codes', category: 'জরুরি সেবা', categoryGroup: 'emergency', description: 'সকল মোবাইল অপারেটরের কোড ও হেল্পলাইন', status: 'সক্রিয়', createdAt: '2024-02-01' },

  // ====== আইন ও বিচার (Law & Justice) ======
  { id: 46, name: 'আইনজীবী তালিকা', nameEn: 'Lawyer List', category: 'আইন ও বিচার', categoryGroup: 'law', description: 'আইনজীবী ও আইনি সহায়তা প্রদানকারী', totalEntries: 8, status: 'সক্রিয়', createdAt: '2024-02-15' },

  // ====== শিক্ষা (Education) ======
  { id: 47, name: 'পাবলিক লাইব্রেরি', nameEn: 'Public Library', category: 'শিক্ষা', categoryGroup: 'education', description: 'পাবলিক লাইব্রেরি ও পাঠাগার', totalEntries: 2, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 48, name: 'কম্পিউটার প্রশিক্ষণ কেন্দ্র', nameEn: 'Computer Training Center', category: 'শিক্ষা', categoryGroup: 'education', description: 'কম্পিউটার ও আইটি প্রশিক্ষণ কেন্দ্র', totalEntries: 5, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 49, name: 'প্রতিবন্ধী শিক্ষা প্রতিষ্ঠান', nameEn: 'Disability Education', category: 'শিক্ষা', categoryGroup: 'education', description: 'প্রতিবন্ধী শিক্ষা ও পুনর্বাসন কেন্দ্র', totalEntries: 1, status: 'সক্রিয়', createdAt: '2024-03-01' },

  // ====== কৃষি (Agriculture) ======
  { id: 50, name: 'সার ডিলার', nameEn: 'Fertilizer Dealer', category: 'কৃষি', categoryGroup: 'agriculture', description: 'সার ও কৃষি উপকরণ বিক্রেতা', totalEntries: 10, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 51, name: 'বীজ ভাণ্ডার', nameEn: 'Seed Store', category: 'কৃষি', categoryGroup: 'agriculture', description: 'বীজ ভাণ্ডার ও বীজ বিতরণ কেন্দ্র', totalEntries: 6, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 52, name: 'কীটনাশক দোকান', nameEn: 'Pesticide Shop', category: 'কৃষি', categoryGroup: 'agriculture', description: 'কীটনাশক ও কৃষি সুরক্ষা সামগ্রী', totalEntries: 8, status: 'সক্রিয়', createdAt: '2024-03-01' },

  // ====== নারী ও পরিবার কল্যাণ (Women & Family Welfare) ======
  { id: 53, name: 'নারী উদ্যোক্তা কেন্দ্র', nameEn: 'Women Entrepreneur Center', category: 'নারী ও পরিবার কল্যাণ', categoryGroup: 'women', description: 'নারী উদ্যোক্তা উন্নয়ন ও সহায়তা কেন্দ্র', totalEntries: 3, status: 'সক্রিয়', createdAt: '2024-03-15' },

  // ====== সামাজিক সংগঠন (Social Organizations) ======
  { id: 54, name: 'যুব ক্লাব', nameEn: 'Youth Club', category: 'সামাজিক সংগঠন', categoryGroup: 'social', description: 'যুব ক্লাব ও সামাজিক সংগঠন', totalEntries: 25, status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 55, name: 'স্বেচ্ছাসেবী সংগঠন', nameEn: 'Volunteer Organization', category: 'সামাজিক সংগঠন', categoryGroup: 'social', description: 'স্বেচ্ছাসেবী ও সামাজিক কল্যাণ সংগঠন', totalEntries: 10, status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 56, name: 'উদ্যোক্তা উন্নয়ন কেন্দ্র', nameEn: 'Entrepreneur Development Center', category: 'সামাজিক সংগঠন', categoryGroup: 'social', description: 'উদ্যোক্তা উন্নয়ন ও ব্যবসায়িক সহায়তা কেন্দ্র', totalEntries: 2, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 57, name: 'এতিমখানা', nameEn: 'Orphanage', category: 'সামাজিক সংগঠন', categoryGroup: 'social', description: 'এতিমখানা ও শিশু কল্যাণ কেন্দ্র', totalEntries: 3, status: 'সক্রিয়', createdAt: '2024-02-15' },
  { id: 58, name: 'রক্তদান সংগঠন', nameEn: 'Blood Donation Organization', category: 'সামাজিক সংগঠন', categoryGroup: 'social', description: 'রক্তদান সংগঠন ও স্বেচ্ছাসেবী রক্তদান কার্যক্রম', totalEntries: 4, status: 'সক্রিয়', createdAt: '2024-02-15' },
  { id: 59, name: 'স্পোর্টস ক্লাব', nameEn: 'Sports Club', category: 'সামাজিক সংগঠন', categoryGroup: 'social', description: 'স্পোর্টস ক্লাব ও ক্রীড়া সংগঠন', totalEntries: 15, status: 'সক্রিয়', createdAt: '2024-02-10' },
  { id: 60, name: 'সাংস্কৃতিক সংগঠন', nameEn: 'Cultural Organization', category: 'সামাজিক সংগঠন', categoryGroup: 'social', description: 'সাংস্কৃতিক সংগঠন ও সৃজনশীল কার্যক্রম', totalEntries: 8, status: 'সক্রিয়', createdAt: '2024-03-01' },

  // ====== গৃহ ও দৈনন্দিন সেবা (Home & Daily Life) ======
  { id: 61, name: 'গৃহকর্মী সার্ভিস', nameEn: 'Domestic Worker Service', category: 'গৃহ ও দৈনন্দিন সেবা', categoryGroup: 'home', description: 'গৃহকর্মী ও সাহায্যকারী সেবা', totalEntries: 10, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 62, name: 'হাউস পেইন্টিং সার্ভিস', nameEn: 'House Painting Service', category: 'গৃহ ও দৈনন্দিন সেবা', categoryGroup: 'home', description: 'ঘরবাড়ি পেইন্টিং ও সৌন্দর্যবর্ধন সেবা', totalEntries: 6, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 63, name: 'এটিএম বুথ তালিকা', nameEn: 'ATM Booth List', category: 'গৃহ ও দৈনন্দিন সেবা', categoryGroup: 'home', description: 'এটিএম বুথ ও ব্যাংকিং সেবা', totalEntries: 4, status: 'সক্রিয়', createdAt: '2024-03-15' },
  { id: 64, name: 'ভাড়া বাসা জমি তথ্য', nameEn: 'Rent House & Land Info', category: 'গৃহ ও দৈনন্দিন সেবা', categoryGroup: 'home', description: 'ভাড়া বাসা ও জমির তথ্য', totalEntries: 20, status: 'সক্রিয়', createdAt: '2024-03-15' },
  { id: 65, name: 'কমিউনিটি সেন্টার', nameEn: 'Community Center', category: 'গৃহ ও দৈনন্দিন সেবা', categoryGroup: 'home', description: 'কমিউনিটি সেন্টার ও অনুষ্ঠান ভেন্যু', totalEntries: 5, status: 'সক্রিয়', createdAt: '2024-03-01' },
  { id: 66, name: 'পাবলিক টয়লেট', nameEn: 'Public Toilet', category: 'গৃহ ও দৈনন্দিন সেবা', categoryGroup: 'home', description: 'পাবলিক টয়লেট ও স্যানিটেশন সুবিধা', totalEntries: 8, status: 'সক্রিয়', createdAt: '2024-03-01' },

  // ====== পরিবহন (Transport) ======
  { id: 67, name: 'বাস', nameEn: 'Bus', category: 'পরিবহন', categoryGroup: 'transport', description: 'বাস সার্ভিস ও যাত্রী পরিবহন', totalEntries: 12, status: 'সক্রিয়', createdAt: '2024-02-01' },
];
