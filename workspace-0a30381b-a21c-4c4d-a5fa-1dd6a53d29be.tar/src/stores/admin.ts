import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { PERMISSIONS, type User, type UserRole, type DashboardStats } from '@/types/admin';

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (user: User, token: string) => void;
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;
  hasPermission: (module: string, action: 'view' | 'add' | 'edit' | 'delete') => boolean;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      isAuthenticated: false,

      login: (user, token) => {
        set({ user, token, isAuthenticated: true });
      },

      logout: () => {
        set({ user: null, token: null, isAuthenticated: false });
      },

      updateProfile: (data) => {
        const currentUser = get().user;
        if (currentUser) {
          set({ user: { ...currentUser, ...data } });
        }
      },

      hasPermission: (module, action) => {
        const { user } = get();
        if (!user) return false;
        if (user.role === 'admin') return true;

        const rolePerms = PERMISSIONS[user.role];
        if (!rolePerms || !rolePerms[module]) return false;
        return rolePerms[module][action] || false;
      },
    }),
    {
      name: 'betagi-admin-auth',
      partialize: (state) => ({
        user: state.user,
        token: state.token,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);

// Navigation state
interface NavState {
  currentPage: string;
  sidebarOpen: boolean;
  sidebarMobileOpen: boolean;
  navigate: (page: string) => void;
  toggleSidebar: () => void;
  toggleMobileSidebar: () => void;
  closeMobileSidebar: () => void;
}

export const useNavStore = create<NavState>((set) => ({
  currentPage: 'dashboard',
  sidebarOpen: true,
  sidebarMobileOpen: false,

  navigate: (page) => {
    set({ currentPage: page, sidebarMobileOpen: false });
  },

  toggleSidebar: () => {
    set((s) => ({ sidebarOpen: !s.sidebarOpen }));
  },

  toggleMobileSidebar: () => {
    set((s) => ({ sidebarMobileOpen: !s.sidebarMobileOpen }));
  },

  closeMobileSidebar: () => {
    set({ sidebarMobileOpen: false });
  },
}));

// Dashboard data store
interface DashboardState {
  stats: DashboardStats | null;
  loading: boolean;
  setStats: (stats: DashboardStats) => void;
  setLoading: (loading: boolean) => void;
}

export const useDashboardStore = create<DashboardState>((set) => ({
  stats: null,
  loading: false,
  setStats: (stats) => set({ stats }),
  setLoading: (loading) => set({ loading }),
}));