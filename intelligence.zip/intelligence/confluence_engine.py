"""
intelligence/confluence_engine.py — Multi-Factor Confluence Engine
====================================================================

Day 67 — The brain of the professional decision-making system.

Collects ALL analysis outputs from the AnalysisAgent's 12-step pipeline
and computes a single weighted confluence score. Then runs validation
gates (5+ factor rule, contradiction detector, news block, etc.) and
produces a final decision:

    A+ Setup  →  6-7 factors aligned, net score ≥ 50  → trade with full size
    A Setup   →  5-6 factors aligned, net score ≥ 35  → trade with normal size
    B Setup   →  5 factors aligned, net score ≥ 20    → trade with reduced size
    AVOID     →  <5 factors, contradiction, or news block → WAIT

Pipeline:
    AnalysisAgent outputs (12 contexts)
        ↓
    ConfluenceEngine.collect_factors()
        ↓
    DecisionScorer.score()  →  ConfluenceScore
        ↓
    ConfidenceCalibrator.calibrate()  →  calibrated confidence
        ↓
    SignalValidator.validate_all()  →  final pass/block
        ↓
    Final decision (BUY/SELL/WAIT + quality + factors breakdown)
"""

from __future__ import annotations

import json
import logging
import threading
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from utils.logger import get_logger
from core.constants import MEMORY_DIR

try:
    from intelligence.decision_score import (
        ConfluenceScore, FactorScore, DecisionScorer, get_scorer,
    )
except ImportError:
    # Dummy classes/functions so code doesn't crash if decision_score unavailable
    class ConfluenceScore: pass
    class FactorScore: pass
    class DecisionScorer: pass
    def get_scorer(): return None

try:
    from intelligence.signal_validator import SignalValidator, get_signal_validator
except ImportError:
    class SignalValidator: pass
    def get_signal_validator(): return None

try:
    from intelligence.confidence_calibrator import get_calibrator
except ImportError:
    def get_calibrator(): return None

log = get_logger("confluence_engine")

DECISION_HISTORY_PATH = MEMORY_DIR / "decision_history.jsonl"


@dataclass
class ConfluenceDecision:
    """The final output of the ConfluenceEngine."""
    pair: str
    timeframe: str
    direction: str                # BUY / SELL / NEUTRAL / WAIT
    confidence: float             # 0-100 (calibrated)
    setup_quality: str            # A+ / A / B / AVOID
    aligned_factors: int
    total_factors: int
    buy_score: float
    sell_score: float
    net_score: float
    factors: List[Dict[str, Any]] = field(default_factory=list)
    market_story: str = ""
    risks: List[str] = field(default_factory=list)
    validation_gates: List[Dict[str, Any]] = field(default_factory=list)
    raw_setup_quality: str = ""   # A+ / A / B / C / D — scorer's grade BEFORE gate overwrite to AVOID
    should_trade: bool = False
    block_reason: str = ""
    calibration: Dict[str, Any] = field(default_factory=dict)
    generated_at: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_telegram_alert(self) -> Optional[str]:
        """Format a Telegram signal alert. Returns None if not tradeable."""
        if not self.should_trade:
            return None
        quality_emoji = {"A+": "🌟", "A": "✅", "B": "⚠️"}.get(self.setup_quality, "❓")
        dir_emoji = "🟢" if self.direction == "BUY" else "🔴"
        factors_str = "\n".join(
            f"  {'✅' if f['direction'] == self.direction else '❌'} {f['name']}: {f['direction']} ({f['strength']:.0f}%)"
            for f in self.factors
        )
        return (
            f"{dir_emoji} FOREX AI SIGNAL — {self.setup_quality}\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"Pair: {self.pair} ({self.timeframe})\n"
            f"Direction: {self.direction}\n"
            f"Confidence: {self.confidence:.0f}%\n"
            f"Aligned Factors: {self.aligned_factors}/{self.total_factors}\n"
            f"Quality: {quality_emoji} {self.setup_quality}\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"Factors:\n{factors_str}\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"Story: {self.market_story[:200]}\n"
            f"━━━━━━━━━━━━━━━━━━━━━"
        )


class ConfluenceEngine:
    """Collects all analyses → computes confluence → validates → decides."""

    def __init__(self):
        self.scorer = get_scorer()
        self.validator = get_signal_validator()
        self.calibrator = get_calibrator()
        self._lock = threading.RLock()

    def evaluate(
        self,
        pair: str,
        timeframe: str,
        analysis_out: Dict[str, Any],
        news_blocked_pairs: Optional[Dict[str, str]] = None,
        risk_approved: bool = True,
        correlation_blocked: bool = False,
    ) -> ConfluenceDecision:
        """Run the full pipeline on a single pair's analysis output."""
        factors = self._collect_factors(analysis_out)
        score = self.scorer.score(factors)

        # Calibrate confidence based on historical accuracy
        calibration = self.calibrator.calibrate(score.confidence)
        calibrated_conf = calibration["calibrated"]
        score.confidence = calibrated_conf

        # Run validation gates
        validation = self.validator.validate_all(
            score=score,
            pair=pair,
            news_blocked_pairs=news_blocked_pairs or {},
            correlation_blocked=correlation_blocked,
            risk_approved=risk_approved,
        )

        # Build final decision
        should_trade = validation["should_trade"]
        direction = score.final_direction if should_trade else "WAIT"
        if score.final_direction == "NEUTRAL":
            direction = "WAIT"

        # Build market story (top 2-3 factors)
        top_factors = sorted(
            [f for f in score.factors if f.direction == score.final_direction and f.is_meaningful],
            key=lambda x: x.weighted_score, reverse=True,
        )[:3]
        story_parts = []
        for f in top_factors:
            story_parts.append(f"{f.name} {f.direction.lower()} ({f.reasoning[:40]})")
        market_story = " | ".join(story_parts) if story_parts else "No strong confluence"

        # Risks (factors opposing the decision)
        risks = []
        for f in score.factors:
            if f.direction != score.final_direction and f.direction != "NEUTRAL" and f.is_meaningful:
                risks.append(f"{f.name} {f.direction.lower()} ({f.reasoning[:40]})")

        decision = ConfluenceDecision(
            pair=pair,
            timeframe=timeframe,
            direction=direction,
            confidence=calibrated_conf,
            setup_quality=score.setup_quality if should_trade else "AVOID",
            raw_setup_quality=score.setup_quality,
            aligned_factors=score.aligned_factors,
            total_factors=score.total_factors,
            buy_score=score.buy_score,
            sell_score=score.sell_score,
            net_score=score.net_score,
            factors=[f.to_dict() for f in score.factors],
            market_story=market_story,
            risks=risks[:3],
            validation_gates=validation["gates"],
            should_trade=should_trade,
            block_reason=validation["block_reason"],
            calibration=calibration,
            generated_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        )

        # Record to decision history
        self._record_decision(decision)

        return decision

    # ── Factor collectors ───────────────────────────────────────────

    def _collect_factors(self, analysis_out: Dict[str, Any]) -> List[FactorScore]:
        """Extract 7 factor scores from the AnalysisAgent's output dict."""
        factors: List[FactorScore] = []
        factors.append(self._smc_factor(analysis_out))
        factors.append(self._liquidity_factor(analysis_out))
        factors.append(self._session_factor(analysis_out))
        factors.append(self._currency_strength_factor(analysis_out))
        factors.append(self._intermarket_factor(analysis_out))
        factors.append(self._news_factor(analysis_out))
        factors.append(self._technical_factor(analysis_out))
        return [f for f in factors if f is not None]

    def _smc_factor(self, a: Dict[str, Any]) -> FactorScore:
        """Factor 1: Market Structure (SMC) — BOS / CHoCH / OB / FVG.

        BUGFIX (confluence key-mismatch, found while debugging "0 factors,
        AVOID"): the raw SMC result (a["smc"]) uses plain keys
        (signal/confluence_score/grade/analysis), but a["smc_ctx"]
        (built by SMCEngine.get_ai_context()) renames every key with a
        "smc_" prefix (smc_signal/smc_score/smc_grade/smc_analysis).
        The old code did `a.get("smc_ctx") or a.get("smc")` — since
        smc_ctx is always a non-empty dict, the fallback to the
        correctly-keyed "smc" dict never triggered, so signal/conf/grade
        were always "" / 0 / "" here. That pinned this factor (25% of
        total weight) at NEUTRAL/0 on every single evaluation, regardless
        of what the SMC engine actually found. Fix: read from the raw
        "smc" dict first (correct keys), and also accept the prefixed
        smc_ctx keys as a fallback so this stays robust either way.
        """
        raw = a.get("smc") or {}
        ctx = a.get("smc_ctx") or {}

        signal = (raw.get("signal") or ctx.get("smc_signal") or "").upper()
        conf = float(
            raw.get("confluence_score")
            if raw.get("confluence_score") is not None
            else (ctx.get("smc_score") if ctx.get("smc_score") is not None else 0)
        )
        grade = (raw.get("grade") or ctx.get("smc_grade") or "").upper()
        direction_raw = (raw.get("direction") or ctx.get("smc_direction") or "").upper()

        direction = "NEUTRAL"
        strength = conf
        if signal in ("BUY", "BULLISH") or direction_raw in ("BUY", "BULLISH"):
            direction = "BUY"
        elif signal in ("SELL", "BEARISH") or direction_raw in ("SELL", "BEARISH"):
            direction = "SELL"

        # Grade bonus
        if grade in ("A+", "A"):
            strength = min(100, strength + 15)

        reasoning = (
            raw.get("analysis") or ctx.get("smc_analysis")
            or f"SMC {signal or direction_raw} {grade}"
        )
        return FactorScore(
            name="smc", direction=direction, strength=min(100, strength),
            confidence=70, weight=25, reasoning=str(reasoning)[:100],
            details={"signal": signal, "grade": grade, "score": conf},
        )

    def _liquidity_factor(self, a: Dict[str, Any]) -> FactorScore:
        """Factor 2: Liquidity — sweep / equal highs-lows / stop hunt.

        BUGFIX (same key-mismatch family as _smc_factor): this only ever
        looked at a["smc_ctx"], which doesn't carry a "liquidity_sweep"
        or "sweep" key at all (SMCEngine.get_ai_context() drops that
        info). Even when a sweep dict was found, the code checked
        sweep.get("swept") / sweep.get("direction") — but the real
        sweep detector (mtf_analyzer._detect_liquidity_sweep) returns
        {"type": "BULLISH_SWEEP" | "BEARISH_SWEEP" | "NONE"}, with no
        "swept" or "direction" key ever. Net effect: this factor (20%
        weight) could never produce BUY/SELL, only NEUTRAL. Fix: read
        the H4 (preferred) / M15 sweep dicts from the raw a["smc"]
        result and branch on the actual "type" field.
        """
        smc_raw = a.get("smc") or {}
        h4 = smc_raw.get("h4") or {}
        m15 = smc_raw.get("m15") or {}
        h4_sweep = h4.get("liquidity_sweep") or {}
        m15_sweep = m15.get("liquidity_sweep") or {}

        session = a.get("session_ctx") or {}
        fusion = session.get("fusion") if isinstance(session, dict) else {}

        direction = "NEUTRAL"
        strength = 30.0
        reasoning = "no clear liquidity signal"

        # H4 sweep preferred (bigger timeframe = stronger signal), M15 fallback
        sweep_type = h4_sweep.get("type") if h4_sweep.get("type") not in (None, "NONE") else m15_sweep.get("type")
        sweep_note = h4_sweep.get("note") or m15_sweep.get("note") or ""

        if sweep_type == "BULLISH_SWEEP":
            direction = "BUY"
            strength = 70
            reasoning = f"sell-side liquidity sweep → bullish reversal ({sweep_note})"
        elif sweep_type == "BEARISH_SWEEP":
            direction = "SELL"
            strength = 70
            reasoning = f"buy-side liquidity sweep → bearish reversal ({sweep_note})"
        else:
            # Fallback: SMC confluence_factors may mark liquidity_sweep True
            # even when nested type string is missing on some paths.
            _factors = smc_raw.get("confluence_factors") or {}
            if isinstance(_factors, dict) and _factors.get("liquidity_sweep"):
                _smc_dir = (smc_raw.get("direction") or smc_raw.get("signal") or "").upper()
                if _smc_dir in ("BUY", "BULLISH"):
                    direction = "BUY"
                    strength = 55
                    reasoning = "SMC confluence_factors.liquidity_sweep + structure BUY"
                elif _smc_dir in ("SELL", "BEARISH"):
                    direction = "SELL"
                    strength = 55
                    reasoning = "SMC confluence_factors.liquidity_sweep + structure SELL"
            elif not smc_raw:
                log.warning("[Confluence] liquidity factor: analysis_out['smc'] empty — NEUTRAL")

        # Session-gated SMC confluence can add liquidity context.
        # Renamed from fusion_score (2026-08): this is the raw SMC
        # confluence score gated by session rules, not a session+SMC blend —
        # see session_analyzer.session_smc_fusion().
        if isinstance(fusion, dict) and fusion.get("smc_confluence_score", 0) >= 60:
            strength = min(100, strength + 10)

        return FactorScore(
            name="liquidity", direction=direction, strength=strength,
            confidence=60, weight=20, reasoning=reasoning[:150],
            details={"sweep_type": sweep_type or "NONE"},
        )

    def _session_factor(self, a: Dict[str, Any]) -> FactorScore:
        """Factor 3: Session — London/NY = strong, Asian = range, dead zone = avoid."""
        session = a.get("session_ctx") or {}
        current = (session.get("current_session") or "").upper()
        # NOTE: session.get("trade_quality") / session.get("trade_allowed")
        # below are aliased onto the real keys session_grade /
        # session_trade_allowed (session_analyzer.get_ai_context() never
        # emits "trade_quality" or "trade_allowed" directly — those old
        # lookups always returned "" / default True, which meant the
        # OVERLAP/GOOD/CAUTION quality bonuses below never fired).
        trade_quality = (session.get("trade_quality") or session.get("session_grade") or "").upper()
        trade_allowed = session.get("trade_allowed", session.get("session_trade_allowed", True))

        direction = "NEUTRAL"
        strength = 50
        reasoning = f"session={current} quality={trade_quality}"

        is_overlap = bool(session.get("is_overlap"))
        if not trade_allowed or current == "DEAD_ZONE":
            strength = 0
            reasoning = "dead zone — no trades"
        elif is_overlap or "OVERLAP" in current or trade_quality in ("BEST", "A+"):
            strength = 80
            reasoning = f"{current} overlap — premium liquidity"
        elif trade_quality in ("GOOD", "A"):
            strength = 60
        elif trade_quality in ("CAUTION", "B"):
            strength = 35
        else:
            strength = 25

        # DESIGN: Session is direction-neutral by intent — it never increments
        # aligned_factors (only BUY/SELL + strength>=30 count). Strength still
        # affects weighted scores. Do NOT invent BUY/SELL here (parity).
        return FactorScore(
            name="session", direction="NEUTRAL", strength=strength,
            confidence=70, weight=5, reasoning=reasoning,
            details={"session": current, "quality": trade_quality, "aligned_capable": False},
        )

    def _currency_strength_factor(self, a: Dict[str, Any]) -> FactorScore:
        """Factor 4: Currency Strength — relative strength model."""
        inter = a.get("intermarket_ctx") or {}
        sent = a.get("sentiment_ctx") or {}
        cs_ctx = a.get("currency_strength_ctx") or {}
        macro_pair_bias = (inter.get("macro_pair_bias") or "").upper() if isinstance(inter, dict) else ""

        direction = "NEUTRAL"
        strength = 30
        reasoning = "no currency strength data"

        if macro_pair_bias in ("BULLISH", "BUY"):
            direction = "BUY"
            strength = 60
            reasoning = "macro_pair_bias BULLISH"
        elif macro_pair_bias in ("BEARISH", "SELL"):
            direction = "SELL"
            strength = 60
            reasoning = "macro_pair_bias BEARISH"

        # Day-64 matrix / sentiment currency_bias (parity: same keys live uses)
        if direction == "NEUTRAL" and isinstance(cs_ctx, dict):
            pair_bias = (cs_ctx.get("pair_bias") or cs_ctx.get("bias") or "").upper()
            if pair_bias in ("BULLISH", "BUY", "STRONG_BULLISH"):
                direction = "BUY"
                strength = 55
                reasoning = f"currency_strength_ctx bias={pair_bias}"
            elif pair_bias in ("BEARISH", "SELL", "STRONG_BEARISH"):
                direction = "SELL"
                strength = 55
                reasoning = f"currency_strength_ctx bias={pair_bias}"
            else:
                # derive from base vs quote strengths when available
                strengths = cs_ctx.get("currency_strengths") or cs_ctx.get("strengths") or {}
                pair = (a.get("symbol") or a.get("pair") or "")
                if isinstance(strengths, dict) and len(pair) >= 6:
                    base, quote = pair[:3].upper(), pair[3:6].upper()
                    sb, sq = strengths.get(base), strengths.get(quote)
                    if sb is not None and sq is not None:
                        diff = float(sb) - float(sq)
                        if diff >= 8:
                            direction = "BUY"
                            strength = min(80, 40 + abs(diff))
                            reasoning = f"{base}({sb})>{quote}({sq}) Δ={diff:.1f}"
                        elif diff <= -8:
                            direction = "SELL"
                            strength = min(80, 40 + abs(diff))
                            reasoning = f"{base}({sb})<{quote}({sq}) Δ={diff:.1f}"

        if isinstance(sent, dict):
            sent_score = sent.get("final_score", 0) or sent.get("sentiment_score", 0) or 0
            cur_bias = (sent.get("currency_bias") or "").upper()
            if cur_bias in ("BULLISH", "BUY") and direction == "NEUTRAL":
                direction = "BUY"
                strength = 50
                reasoning = f"sentiment currency_bias={cur_bias}"
            elif cur_bias in ("BEARISH", "SELL") and direction == "NEUTRAL":
                direction = "SELL"
                strength = 50
                reasoning = f"sentiment currency_bias={cur_bias}"
            if sent_score > 20 and direction == "BUY":
                strength = min(80, strength + 15)
            elif sent_score < -20 and direction == "SELL":
                strength = min(80, strength + 15)

        if direction == "NEUTRAL" and not macro_pair_bias and not cs_ctx:
            log.debug("[Confluence] currency_strength: no intermarket/cs_ctx — NEUTRAL")

        return FactorScore(
            name="currency_strength", direction=direction, strength=strength,
            confidence=60, weight=15, reasoning=reasoning[:100],
            details={"macro_pair_bias": macro_pair_bias, "cs_ctx_keys": list(cs_ctx.keys())[:8] if isinstance(cs_ctx, dict) else []},
        )

    def _intermarket_factor(self, a: Dict[str, Any]) -> FactorScore:
        """Factor 5: Intermarket — DXY / Gold / VIX / US10Y / SP500."""
        inter = a.get("intermarket_ctx") or {}
        if not isinstance(inter, dict):
            return FactorScore(name="intermarket", direction="NEUTRAL", strength=0,
                               confidence=0, weight=15, reasoning="no intermarket data")

        macro_score = float(inter.get("macro_score") or 0)
        macro_regime = (inter.get("macro_regime") or "").upper()
        cross_confirmed = inter.get("cross_asset_confirmed", False)

        direction = "NEUTRAL"
        strength = abs(macro_score) * 0.8
        reasoning = f"macro_score={macro_score} regime={macro_regime}"

        if macro_score > 20:
            direction = "BUY"
        elif macro_score < -20:
            direction = "SELL"

        if cross_confirmed:
            strength = min(100, strength + 15)
            reasoning += " | cross-asset confirmed"

        return FactorScore(
            name="intermarket", direction=direction, strength=min(100, strength),
            confidence=65, weight=15, reasoning=reasoning[:100],
            details={"macro_score": macro_score, "regime": macro_regime,
                     "cross_confirmed": cross_confirmed},
        )

    def _news_factor(self, a: Dict[str, Any]) -> FactorScore:
        """Factor 6: News Intelligence — Day 66 bias."""
        news_intel = a.get("news_intelligence") or {}
        if not isinstance(news_intel, dict) or news_intel.get("blocked"):
            return FactorScore(
                name="news", direction="NEUTRAL", strength=0, confidence=0, weight=10,
                reasoning="news blocked" if news_intel.get("blocked") else "no news data",
                details=news_intel if isinstance(news_intel, dict) else {},
            )

        news_bias = (news_intel.get("news_bias") or "NEUTRAL").upper()
        adj = news_intel.get("confidence_change", 0)

        direction = "NEUTRAL"
        strength = 30
        reasoning = news_intel.get("adjustment_reason") or "neutral news"

        if news_bias == "BULLISH":
            direction = "BUY"
            strength = 50 + abs(adj) * 2
        elif news_bias == "BEARISH":
            direction = "SELL"
            strength = 50 + abs(adj) * 2

        return FactorScore(
            name="news", direction=direction, strength=min(100, strength),
            confidence=70, weight=10, reasoning=reasoning[:100],
            details={"news_bias": news_bias, "adjustment": adj},
        )

    def _technical_factor(self, a: Dict[str, Any]) -> FactorScore:
        """Factor 7: Technical — RSI / MACD / EMA / Pattern."""
        signal = a.get("signal") or {}
        bias = a.get("bias_ctx") or {}
        bias_direction = (bias.get("bias") or signal.get("signal") or "NEUTRAL").upper()
        rule_conf = float(signal.get("confidence") or 0)

        direction = "NEUTRAL"
        if bias_direction in ("BUY", "BULLISH"):
            direction = "BUY"
        elif bias_direction in ("SELL", "BEARISH"):
            direction = "SELL"

        strength = rule_conf
        reasoning = signal.get("reasons") or f"rule signal {bias_direction}"
        if isinstance(reasoning, list):
            reasoning = "; ".join(str(r) for r in reasoning[:2])

        return FactorScore(
            name="technical", direction=direction, strength=min(100, strength),
            confidence=65, weight=10, reasoning=str(reasoning)[:100],
            details={"rule_signal": bias_direction, "rule_confidence": rule_conf},
        )

    # ── Decision history persistence ────────────────────────────────

    def _record_decision(self, decision: ConfluenceDecision) -> None:
        """Append the decision to memory/decision_history.jsonl for later learning."""
        try:
            DECISION_HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
            entry = {
                "ts": decision.generated_at,
                "pair": decision.pair,
                "timeframe": decision.timeframe,
                "direction": decision.direction,
                "confidence": decision.confidence,
                "setup_quality": decision.setup_quality,
                "aligned_factors": decision.aligned_factors,
                "total_factors": decision.total_factors,
                "buy_score": decision.buy_score,
                "sell_score": decision.sell_score,
                "net_score": decision.net_score,
                "should_trade": decision.should_trade,
                "block_reason": decision.block_reason,
                "factors": [
                    {"name": f["name"], "direction": f["direction"], "strength": f["strength"]}
                    for f in decision.factors
                ],
            }
            with DECISION_HISTORY_PATH.open("a", encoding="utf-8") as f:
                f.write(json.dumps(entry, default=str) + "\n")
        except Exception as e:
            log.debug(f"[Confluence] decision history write failed: {e}")

    def record_outcome(self, pair: str, direction: str, confidence: float, won: bool) -> None:
        """Record a closed-trade outcome for confidence calibration."""
        try:
            self.calibrator.record_outcome(predicted_confidence=confidence, won=won)
        except Exception as e:
            log.debug(f"[Confluence] outcome record failed: {e}")

    def stats(self) -> Dict[str, Any]:
        """Return confluence + calibration stats."""
        return {
            "calibration": self.calibrator.status(),
        }


# ── singleton ───────────────────────────────────────────────────────
_ENGINE: Optional[ConfluenceEngine] = None


def get_confluence_engine() -> ConfluenceEngine:
    global _ENGINE
    if _ENGINE is None:
        _ENGINE = ConfluenceEngine()
    return _ENGINE