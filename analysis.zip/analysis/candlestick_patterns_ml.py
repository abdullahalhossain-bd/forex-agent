# analysis/candlestick_patterns_ml.py — Candlestick pattern detectors for ML
# =============================================================================
# Ported from: https://github.com/MaxwellMendenhall/ml_backtest
# Original: ml_backtest/data/data.py → CandleStickPatterns class
# Original author: Maxwell Mendenhall — MIT license
#
# Simple boolean candlestick pattern detectors. Each returns True/False —
# these are the SIGNAL generators, not feature extractors (those are in
# ml/pattern_features.py).
#
# These complement analysis/candlestick_patterns_mw.py (the 33-pattern
# MotiveWave port). The differences:
#
#   - This module: 8 patterns, boolean output (is/isn't), used as entry triggers.
#   - MotiveWave port: 33 patterns, named output, used as a broad scanner.
#
# The two can coexist. The Mendenhall patterns are tuned slightly differently
# (e.g., Hammer requires total_range > 3*body, vs MotiveWave's body/range<0.1
# + lower>2*body). They will sometimes agree, sometimes disagree — both
# perspectives are useful.
# =============================================================================

from __future__ import annotations


class CandleStickPatterns:
    """8 candlestick pattern detectors — boolean output."""

    # ── 1-bar patterns ───────────────────────────────────────────────────────

    @staticmethod
    def is_inverted_hammer(current_open, current_close, current_high, current_low):
        """
        Inverted Hammer / Shooting Star.
        Total range > 3x body, upper shadow > 60% of range, lower shadow < 40%.
        """
        body_length = abs(current_open - current_close)
        upper_shadow = current_high - max(current_open, current_close)
        total_length = current_high - current_low
        lower_shadow = min(current_open, current_close) - current_low
        return (
            (total_length > 3 * body_length)
            and (upper_shadow / (0.001 + total_length) > 0.6)
            and (lower_shadow / (0.001 + total_length) < 0.4)
        )

    @staticmethod
    def is_hammer(current_open, current_close, current_high, current_low):
        """
        Hammer / Hanging Man.
        Total range > 3x body, close in upper 60% of range, open in upper 60%.
        """
        return (
            ((current_high - current_low) > 3 * abs(current_open - current_close))
            and ((current_close - current_low) / (0.001 + current_high - current_low) > 0.6)
            and ((current_open - current_low) / (0.001 + current_high - current_low) > 0.6)
        )

    @staticmethod
    def is_dragonfly_doji(current_open, current_close, current_high, current_low):
        """
        Dragonfly Doji.
        Body < 10% of range, lower shadow > 60% of range, upper shadow <
        10% of range (all ratios taken against the candle's own total
        range, so the definition is scale-independent — works the same
        on EURUSD, USDJPY, or XAUUSD).

        Bug fix (audit Part 2B): the original condition compared the
        upper shadow to the *body* (`upper_shadow < body_range`) instead
        of to the total range. That is not scale-independent: as soon as
        a candle's body approaches zero (which is exactly what makes it
        doji-like in the first place), the threshold it's being compared
        against also approaches zero, so the check degenerates into
        "is the upper wick smaller than an already-microscopic body" —
        a razor's-edge comparison that real (and even textbook-literal)
        dragonfly dojis fail on floating-point noise alone. This mirrors
        the already-correct, range-relative formula used by
        `candlestick_patterns_mw.py::_check_dragonfly_doji`.
        """
        body_range = abs(current_close - current_open)
        total_range = current_high - current_low
        if total_range <= 0:
            return False
        upper_shadow = current_high - max(current_close, current_open)
        lower_shadow = min(current_close, current_open) - current_low
        return (
            (body_range / total_range < 0.1)
            and (lower_shadow / total_range > 0.6)
            and (upper_shadow / total_range < 0.1)
        )

    @staticmethod
    def is_gravestone_doji(current_open, current_close, current_high, current_low):
        """
        Gravestone Doji (the bearish mirror image of Dragonfly Doji).
        Body < 10% of range, upper shadow > 60% of range, lower shadow <
        10% of range — all range-relative, so scale-independent.

        Bug fix (audit Part 2C): this detector did not exist at all in
        this module — `candlestick_patterns_mw.py` has one
        (`_check_gravestone_doji`), but this ml/boolean-detector module
        did not, forcing callers/tests needing a scalar boolean check to
        hand-roll the shape math inline (and get it wrong: an earlier
        inline version of this check in `test_candlestick_architecture.py`
        compared the lower shadow to the body rather than to the total
        range, which is the same non-scale-independent mistake fixed in
        `is_dragonfly_doji` above). Added here as the ml-module's own
        implementation, defined the same way as `_check_gravestone_doji`
        in `candlestick_patterns_mw.py` so the two modules agree.
        """
        body_range = abs(current_close - current_open)
        total_range = current_high - current_low
        if total_range <= 0:
            return False
        upper_shadow = current_high - max(current_close, current_open)
        lower_shadow = min(current_close, current_open) - current_low
        return (
            (body_range / total_range < 0.1)
            and (upper_shadow / total_range > 0.6)
            and (lower_shadow / total_range < 0.1)
        )

    # ── 2-bar patterns ───────────────────────────────────────────────────────

    @staticmethod
    def is_bullish_engulfing(current_open, current_close, prev_open, prev_close):
        """
        Bullish Engulfing.
        prev bearish, current bullish, current body engulfs prev body.
        """
        return (
            current_close >= prev_open > prev_close >= current_open
            and current_close > current_open
            and (current_close - current_open) > (prev_open - prev_close)
        )

    @staticmethod
    def is_bullish_harami(current_open, current_close, prev_open, prev_close):
        """
        Bullish Harami.
        prev bearish large body, current bullish small body contained within prev body.
        """
        return (
            prev_open > prev_close
            and prev_close <= current_open < current_close <= prev_open
            and (current_close - current_open) < (prev_open - prev_close)
        )

    @staticmethod
    def is_piercing_pattern(current_open, current_close, prev_open, prev_close):
        """
        Piercing Line.
        prev bearish, current bullish, opens below prev close, closes above prev midpoint
        but below prev open.
        """
        if not (prev_close < prev_open and current_close > current_open):
            return False
        prev_mid = (prev_open + prev_close) / 2.0
        return (
            current_open < prev_close
            and current_close > prev_mid
            and current_close < prev_open
        )

    # ── 3-bar patterns ───────────────────────────────────────────────────────

    @staticmethod
    def is_morning_star(b_prev_open, b_prev_close,
                        prev_open, prev_close,
                        current_open, current_close):
        """
        Morning Star.
        1st: large bearish, 2nd: small body (star), 3rd: large bullish closing
        above midpoint of 1st.
        """
        # 1st bearish, 3rd bullish
        if not (b_prev_close < b_prev_open and current_close > current_open):
            return False
        first_body = abs(b_prev_close - b_prev_open)
        second_body = abs(prev_close - prev_open)
        third_body = abs(current_close - current_open)
        # 2nd small body
        if second_body >= first_body * 0.5:
            return False
        # 3rd closes above midpoint of 1st
        first_mid = (b_prev_open + b_prev_close) / 2.0
        return (current_close > first_mid) and (third_body > first_body * 0.5)

    @staticmethod
    def is_morning_star_doji(b_prev_open, b_prev_close,
                             prev_open, prev_close, prev_high, prev_low,
                             current_open, current_close):
        """
        Morning Doji Star.
        Like Morning Star but middle candle is a doji (body < 10% of its range).
        """
        # 1st bearish, 3rd bullish
        if not (b_prev_close < b_prev_open and current_close > current_open):
            return False
        # Middle is doji
        second_body = abs(prev_close - prev_open)
        second_range = prev_high - prev_low
        if second_range == 0 or second_body / (second_range + 0.001) >= 0.1:
            return False
        # 3rd closes above 1st's close (gap-recovery)
        return current_close > b_prev_close


# ── Whole-DataFrame vectorized wrapper ───────────────────────────────────────
# analysis/candlestick_engine.py calls `ml.detect_all(df)` expecting a
# DataFrame of per-bar booleans (one column per `is_*` detector above), but
# this function never existed — CandleStickPatterns only exposed per-bar
# scalar detectors. Every call into `_events_from_ml()` therefore raised
# `AttributeError: module 'analysis.candlestick_patterns_ml' has no attribute
# 'detect_all'`, which meant the entire unified candlestick engine crashed
# the moment ML-port patterns were enabled (the default: EngineConfig.use_ml
# defaults to True).
#
# This is a straightforward per-bar loop rather than a fully vectorized
# pandas expression: several of the detectors above (morning star / doji)
# need 2-3 bars of lookback with intermediate branching logic that doesn't
# translate cleanly to vector ops without duplicating the detector logic.
# Looping here matches the cost profile candlestick_engine.py already pays
# elsewhere (e.g. its own `ctx.trend_label(i)` per-bar loop), so this is not
# a new performance regression relative to the rest of the engine.
def detect_all(df) -> "pd.DataFrame":
    """Run every CandleStickPatterns detector across the whole DataFrame.

    Returns a DataFrame (same index as `df`) with one boolean column per
    detector: is_inverted_hammer, is_hammer, is_dragonfly_doji,
    is_bullish_engulfing, is_bullish_harami, is_piercing_pattern,
    is_morning_star, is_morning_star_doji. A detector that needs N bars of
    history is False for any bar with fewer than N-1 preceding bars.
    """
    import pandas as pd

    p = CandleStickPatterns
    n = len(df)
    o = df["open"].to_numpy(dtype=float)
    h = df["high"].to_numpy(dtype=float)
    l = df["low"].to_numpy(dtype=float)
    c = df["close"].to_numpy(dtype=float)

    cols = {
        "is_inverted_hammer": [False] * n,
        "is_hammer": [False] * n,
        "is_dragonfly_doji": [False] * n,
        "is_bullish_engulfing": [False] * n,
        "is_bullish_harami": [False] * n,
        "is_piercing_pattern": [False] * n,
        "is_morning_star": [False] * n,
        "is_morning_star_doji": [False] * n,
    }

    for i in range(n):
        # 1-bar patterns.
        cols["is_inverted_hammer"][i] = bool(p.is_inverted_hammer(o[i], c[i], h[i], l[i]))
        cols["is_hammer"][i] = bool(p.is_hammer(o[i], c[i], h[i], l[i]))
        cols["is_dragonfly_doji"][i] = bool(p.is_dragonfly_doji(o[i], c[i], h[i], l[i]))

        # 2-bar patterns.
        if i >= 1:
            cols["is_bullish_engulfing"][i] = bool(
                p.is_bullish_engulfing(o[i], c[i], o[i - 1], c[i - 1])
            )
            cols["is_bullish_harami"][i] = bool(
                p.is_bullish_harami(o[i], c[i], o[i - 1], c[i - 1])
            )
            cols["is_piercing_pattern"][i] = bool(
                p.is_piercing_pattern(o[i], c[i], o[i - 1], c[i - 1])
            )

        # 3-bar patterns.
        if i >= 2:
            cols["is_morning_star"][i] = bool(
                p.is_morning_star(
                    o[i - 2], c[i - 2], o[i - 1], c[i - 1], o[i], c[i]
                )
            )
            cols["is_morning_star_doji"][i] = bool(
                p.is_morning_star_doji(
                    o[i - 2], c[i - 2], o[i - 1], c[i - 1], h[i - 1], l[i - 1], o[i], c[i]
                )
            )

    return pd.DataFrame(cols, index=df.index)


# ── Smoke test ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Hammer: total range > 3x body, close in upper 60%, open in upper 60%
    # body=0.05, need range > 0.15 → low=0.85, high=1.06, range=0.21 ✓
    # close=1.05, low=0.85 → (1.05-0.85)/(0.001+0.21)=0.95 > 0.6 ✓
    # open=1.0, low=0.85 → (1.0-0.85)/(0.001+0.21)=0.71 > 0.6 ✓
    assert CandleStickPatterns.is_hammer(1.0, 1.05, 1.06, 0.85)
    print("OK Hammer")

    # Inverted Hammer: upper shadow dominant
    # body=0.01, range=0.11, body*3=0.03 < 0.11 ✓
    # upper=1.10-1.01=0.09, upper/(0.001+0.11)=0.81 > 0.6 ✓
    # lower=1.0-0.99=0.01, lower/(0.001+0.11)=0.09 < 0.4 ✓
    assert CandleStickPatterns.is_inverted_hammer(1.0, 1.01, 1.10, 0.99)
    print("OK Inverted Hammer")

    # Bullish Engulfing: prev bearish, current bullish, current body engulfs prev body
    # Need: current_close >= prev_open > prev_close >= current_open
    # prev_open=1.05, prev_close=0.95 (bearish)
    # current_open=0.95, current_close=1.10 (bullish, engulfs)
    # Check: 1.10>=1.05 ✓, 1.05>0.95 ✓, 0.95>=0.95 ✓
    assert CandleStickPatterns.is_bullish_engulfing(
        current_open=0.95, current_close=1.10, prev_open=1.05, prev_close=0.95
    )
    print("OK Bullish Engulfing")

    # Bullish Harami
    assert CandleStickPatterns.is_bullish_harami(
        current_open=0.95, current_close=1.00, prev_open=1.10, prev_close=0.90
    )
    print("OK Bullish Harami")

    # Piercing Pattern
    assert CandleStickPatterns.is_piercing_pattern(
        current_open=0.85, current_close=1.05, prev_open=1.10, prev_close=0.90
    )
    print("OK Piercing Pattern")

    # Morning Star: large bearish, small star, large bullish closing above midpoint
    assert CandleStickPatterns.is_morning_star(
        b_prev_open=1.20, b_prev_close=1.00,   # 1st: body=0.20, mid=1.10
        prev_open=0.99, prev_close=1.00,        # 2nd: body=0.01 (small)
        current_open=1.00, current_close=1.15,  # 3rd: body=0.15 (>0.20*0.5=0.10), close 1.15 > mid 1.10
    )
    print("OK Morning Star")

    # Morning Doji Star: middle candle must be a doji (body/range < 0.1)
    # prev_open=1.000, prev_close=1.001 (body=0.001), prev_high=1.05, prev_low=0.95 (range=0.10)
    # body/range = 0.001/0.101 = 0.0099 < 0.1 ✓
    assert CandleStickPatterns.is_morning_star_doji(
        b_prev_open=1.20, b_prev_close=1.00,
        prev_open=1.000, prev_close=1.001, prev_high=1.05, prev_low=0.95,
        current_open=1.00, current_close=1.15,
    )
    print("OK Morning Doji Star")

    print("\nAll candlestick pattern (ML port) smoke tests passed.")