# core/trader.py  —  Day 37 | Full Integration (Week 3 + Day 31 + Day 36 wired in)
#
# Changes vs the Day 21 version:
#   - AITrader now routes every order through ExecutionRouter (paper / mt5_demo)
#     instead of calling PaperTrader directly, so EXECUTION_MODE in .env
#     actually switches backends without touching this file again.
#   - CircuitBreaker (kill switch) and ApprovalMode (Mode 1/2/3 human approval)
#     are real gates in run_cycle() now, not just standalone unused modules.
#   - CorrelationFilter is folded into the Safety Guard step alongside the
#     existing TradePermission checks (news/confidence/session/duplicate).
#   - AutonomousTraderSystem can pull its per-cycle pair list from
#     MarketScanner instead of a fixed SYMBOLS list (falls back safely if
#     the MT5 market-data adapter isn't wired yet).
#   - CircuitBreaker + ApprovalMode are created ONCE in AutonomousTraderSystem
#     and shared across every symbol's AITrader — both persist to a single
#     global state file (memory/circuit_breaker_state.json,
#     memory/pending_approvals.json), so per-symbol instances would silently
#     stomp on each other's state. Standalone AITrader usage still works:
#     if you don't pass one in, it creates its own.
#
#   - Day 37 hotfix: `vec_ctx` is now initialized to `{}` BEFORE the
#     `if memory_ctx["total_trades"] > 0:` block in run_cycle(). Previously
#     it was only assigned inside that block, so on a fresh symbol with no
#     trade history yet (total_trades == 0), `result["memory_context"] =
#     vec_ctx` further down raised UnboundLocalError and killed the whole
#     cycle for every symbol in the same run.
#
#   - Day 37+ runtime-unified hotfix (this revision): `_start_telegram_commands`
#     had a body indented at the SAME level as its `def` line (instead of one
#     level deeper), which is a syntax error in Python and also caused
#     `_notify_warning` to be swallowed as part of that broken block. Fixed
#     indentation restores both as proper, separate methods of
#     AutonomousTraderSystem.

import asyncio
import json
import os
import re
import shutil
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from agents.analysis_agent import AnalysisAgent
from agents.decision_agent import DecisionAgent
from agents.learning_agent import LearningAgent
from agents.market_agent import MarketAgent
from config import EXECUTION_MODE
from core.approval_mode import ApprovalMode
from core.devils_advocate import DevilsAdvocateGate
from database.db import TraderDB
from execution.execution_router import ExecutionRouter
from execution.paper_trader import PaperTrader
from memory.history import AnalysisHistory
from memory.learning import LearningEngine
from memory.trade_memory import TradeMemory
from risk.circuit_breaker import CircuitBreaker
from risk.risk_engine import RiskEngine
from risk.trade_permission import TradePermission
from scanner.correlation_filter import CorrelationFilter
from core.constants import clean_symbol, MEMORY_DIR, DATABASE_DIR, BACKUPS_DIR, REPORTS_DIR
from utils.logger import get_logger
from analysis.session_analyzer import SessionAnalyzer
from visualization.chart import ChartEngine

# ── MT5 availability guard (Bug fix: MT5_AVAILABLE was not defined) ──
try:
    import MetaTrader5 as _mt5_module
    MT5_AVAILABLE = True
except (ImportError, OSError, Exception):
    MT5_AVAILABLE = False
    _mt5_module = None

# ── Runtime infrastructure (Day 37+ runtime unification) ─────────────
# These imports are soft — if the new runtime modules aren't available
# (e.g. during a partial deployment), the trader still works exactly as
# before. When they ARE available, the trader publishes events, records
# metrics, and accepts a service registry for dependency injection.
try:
    from core.event_bus import EventBus, get_bus
    from core.runtime_metrics import RuntimeMetrics, get_metrics
    from core.service_registry import ServiceRegistry
    _RUNTIME_INFRA_AVAILABLE = True
except Exception as e:
    _RUNTIME_INFRA_AVAILABLE = False
    EventBus = None
    get_bus = None
    RuntimeMetrics = None
    get_metrics = None
    ServiceRegistry = None
    import logging as _logging
    _logging.getLogger("trader").warning(f"Runtime infrastructure unavailable: {e}")

try:
    import alerts.telegram_bot as telegram_module
    from alerts.telegram_bot import TelegramNotifier, start_telegram_bot_polling
except Exception as e:
    telegram_module = None
    TelegramNotifier = None
    start_telegram_bot_polling = None
    import logging as _logging
    _logging.getLogger("trader").warning(f"Telegram bot unavailable: {e}")

try:
    from learning.mistake_analyzer import AdvancedMistakeAnalyzer
except Exception as e:
    AdvancedMistakeAnalyzer = None
    import logging as _logging
    _logging.getLogger("trader").warning(f"AdvancedMistakeAnalyzer unavailable: {e}")

try:
    from scanner.market_scanner import MarketScanner
except Exception as e:
    MarketScanner = None
    import logging as _logging
    _logging.getLogger("trader").warning(f"MarketScanner unavailable: {e}")

# ── Orphan consumers (Phase 25 follow-up) ─────────────────────────────
# These four hooks actually *consume* the 83 services wired into the
# ServiceRegistry by core/_orphan_integration.py. Without these hooks,
# those services are registered but never consulted during the trade
# decision cycle — i.e. zero impact on trade quality.
#
# Each hook is fail-safe: a broken service logs a WARNING and is skipped.
# Only services whose *purpose* is to block trades (chasing filter, book
# guardrails, R:R policy, Monte Carlo risk-of-ruin, etc.) actually veto.
try:
    from core.orphan_consumers import (
        enrich_market_context,
        apply_signal_scoring,
        apply_advanced_risk_gates,
        final_decision_gate,
    )
    _ORPHAN_CONSUMERS_AVAILABLE = True
except Exception as e:
    _ORPHAN_CONSUMERS_AVAILABLE = False
    enrich_market_context = None
    apply_signal_scoring = None
    apply_advanced_risk_gates = None
    final_decision_gate = None
    import logging as _logging
    _logging.getLogger("trader").warning(f"orphan_consumers unavailable: {e}")

log = get_logger("ai_trader")


class AITrader:

    VERSION = "Week3-Day37-RuntimeUnified"

    def __init__(
        self,
        balance: float = None,
        symbol: str = "EURUSD",
        timeframe: str = "15m",
        seed_rules: bool = True,
        paper_balance: float = None,
        notifier=None,
        execution_mode: str = None,
        approval_mode: int = 3,
        circuit_breaker: CircuitBreaker = None,
        approval: ApprovalMode = None,
        registry: "Optional[ServiceRegistry]" = None,
        paper_trader: "Optional[PaperTrader]" = None,
        db: "Optional[TraderDB]" = None,
    ):
        # Bug #22 fix: default to config.INITIAL_BALANCE instead of 10000.0
        if balance is None:
            try:
                from config import INITIAL_BALANCE as _INITIAL_BALANCE
                balance = float(_INITIAL_BALANCE)
            except Exception:
                balance = 10000.0
        if paper_balance is None:
            paper_balance = balance
        self.balance = balance
        self.symbol = clean_symbol(symbol)
        self.timeframe = timeframe
        self.notifier = notifier
        self.execution_mode = (execution_mode or EXECUTION_MODE).lower()
        self._last_decision_candle = None
        # BUG FIX: the circuit-breaker block message used to be logged at
        # WARNING level on every single cycle it stayed tripped, with no
        # de-duplication — a multi-hour COOLDOWN produced dozens of
        # identical "Cooldown active — N min remaining" lines (48 in a
        # single 5-minute run were reported), drowning the log without
        # adding information. Mirrors the pattern utils/api_rate_limiter.py
        # already uses (_COOLDOWN_LOG_INTERVAL): log immediately on the
        # first block and on any change of mode/reason, otherwise at most
        # once per _CB_LOG_INTERVAL_SEC while the block is unchanged.
        self._cb_last_logged_mode = None
        self._cb_last_logged_reason = None
        self._cb_last_log_ts = 0.0
        self._CB_LOG_INTERVAL_SEC = 300  # log unchanged block at most every 5 min

        # ── Day 131 fix: Risk/Paper/Live balance synchronization ──────
        # self.balance used to be a frozen snapshot taken once at boot and
        # never updated, so risk sizing (e.g. risk_usd = balance * pct)
        # silently drifted away from both the PaperTrader's evolving
        # balance and the real MT5 account balance as PnL accrued. See
        # _sync_balance() for the fix.
        self._balance_lock = threading.Lock()
        self._balance_source = "config"  # "config" | "paper" | "live"
        self._balance_deviation_warn_pct = 0.05  # log if >5% drift ignored

        # Day 131 fix: per-instance ticket-tracking dict for MT5 close
        # detection. Must be created fresh per AITrader (per symbol) —
        # see the comment above _detect_mt5_position_closes() for why a
        # shared/class-level dict here was a cross-symbol data bug.
        self._mt5_known_tickets: dict = {}

        # ── Runtime infrastructure (Day 37+ unification) ──────────────
        # The registry is optional — when supplied, AITrader pulls shared
        # singletons from it (TradeMemory, CircuitBreaker, etc.) instead of
        # constructing fresh copies, and publishes events / metrics to the
        # central bus. When absent, the trader behaves exactly as before.
        self._registry = registry
        self._bus = get_bus() if _RUNTIME_INFRA_AVAILABLE else None
        self._metrics = get_metrics() if _RUNTIME_INFRA_AVAILABLE else None

        # Audit fix: explicit MT5 sync/health tracking used by
        # _get_live_open_pairs() / _detect_mt5_position_closes() to fail
        # closed (block new entries) instead of silently assuming "no open
        # positions" or "no losses" when MT5 is unreachable.
        self._mt5_sync_ok = True
        self._mt5_disconnect_cycles = 0
        # BUGFIX (log audit — "[Risk] Shared MT5Connection.positions_get()
        # returned None ..." warning fires every cycle): the warning is
        # logged on every single cycle while MT5 is degraded, producing
        # hundreds of identical lines per session. Track the last warn
        # timestamp so we only re-emit at most once every 5 minutes —
        # `_mt5_sync_ok` itself stays False the whole time so the fail-
        # closed behavior is unaffected.
        self._mt5_none_warn_last_ts: float = 0.0
        # Edge-detection for kill-switch Level 3 (max drawdown / full stop)
        # emergency close — see check_trade_permission() call site below.
        # Without this, every subsequent cycle while Level 3 stays active
        # would re-trigger close_all_orders() again.
        self._level3_emergency_close_done = False
        # Consecutive cycles MT5 may be unreachable before new entries are
        # blocked (existing positions are never force-closed by this).
        self._MT5_DISCONNECT_FAIL_CLOSED_THRESHOLD = int(
            os.getenv("MT5_DISCONNECT_FAIL_CLOSED_THRESHOLD", "3")
        )

        self._market = MarketAgent(self.symbol, timeframe)
        # Execution-parity wiring: thin wrappers around self._market /
        # self._router (constructed below). No new logic — same objects,
        # same methods, just accessed through the shared DataProvider /
        # ExecutionAdapter contract that backtest/unified_engine.py
        # already uses, so live and historical go through one boundary.
        from core.data_provider import LiveMT5Provider
        self._data_provider = LiveMT5Provider(self._market)
        self._analysis = AnalysisAgent()
        self._decision = DecisionAgent()
        self._risk = RiskEngine(balance=balance, symbol=self.symbol)
        self._perm = TradePermission()
        self._devils_advocate = DevilsAdvocateGate()
        self._learn = LearningAgent()
        # Prefer the registry's shared TradeMemory if available (so all
        # AITraders for different symbols share the same vector store).
        if registry is not None:
            shared_mem = registry.try_resolve("trade_memory")
            if shared_mem is not None:
                self._memory = shared_mem
            else:
                self._memory = TradeMemory(seed_rules=seed_rules)
        else:
            self._memory = TradeMemory(seed_rules=seed_rules)
        self._learning = LearningEngine()
        # Same for TraderDB — share the registry's connection if available.
        # EXECUTION-PARITY FIX: previously this ignored any `db` the caller
        # passed in and always fell back to TraderDB() (the hardcoded live
        # "database/trader.db" path) whenever no registry was supplied.
        # backtest/unified_engine.py's _make_backtest_trader() builds an
        # isolated backtest DB and passes it as `paper_trader`'s db, but
        # AITrader's own top-level self._db (used by ExecutionRouter,
        # decision logging, etc.) never received it — so a backtest run
        # was unconditionally opening a second connection to the LIVE
        # database. Now: explicit `db` argument wins, then registry, then
        # the live default (unchanged behavior for Demo/Real, which never
        # pass `db` explicitly).
        if db is not None:
            self._db = db
        elif registry is not None:
            shared_db = registry.try_resolve("db")
            self._db = shared_db if shared_db is not None else TraderDB()
        else:
            self._db = TraderDB()
        # Use a shared PaperTrader if one was passed in (e.g. from
        # AutonomousTraderSystem), otherwise create a private one.
        self._paper = paper_trader or PaperTrader(starting_balance=paper_balance, db=self._db)
        # Prefer the registry's shared mistake_analyzer.
        if registry is not None:
            shared_ma = registry.try_resolve("mistake_analyzer")
            self._mistake_analyzer = shared_ma if shared_ma is not None else (
                AdvancedMistakeAnalyzer() if AdvancedMistakeAnalyzer else None
            )
        else:
            self._mistake_analyzer = AdvancedMistakeAnalyzer() if AdvancedMistakeAnalyzer else None

        # Day 37 wiring — execution router shares THIS instance's PaperTrader
        # so paper-mode balance never drifts between router and trader.
        # Prefer the registry's shared router if available.
        if registry is not None:
            shared_router = registry.try_resolve("execution_router")
            self._router = shared_router if shared_router is not None else ExecutionRouter(
                mode=self.execution_mode, db=self._db, paper_trader=self._paper
            )
        else:
            self._router = ExecutionRouter(
                mode=self.execution_mode, db=self._db, paper_trader=self._paper
            )
        from core.execution_adapter import MT5ExecutionAdapter
        self._execution_adapter = MT5ExecutionAdapter(self._router)

        # Round-22 audit fix (B1): wire PositionManager for active trade
        # management (trailing stop, breakeven, partial close, Friday close).
        # Previously this 747-line module was completely dead — paper trades
        # got active management via PaperTrader.update_price(), but live MT5
        # trades had NO trailing/breakeven/partial-close/Friday-close at all.
        # Now: instantiate PositionManager in mt5_demo mode and call
        # poll_once() each cycle alongside the paper-trader update.
        self._position_manager = None
        if self.execution_mode in ("mt5_demo", "mt5_live"):
            try:
                from broker.position_manager import PositionManager
                # Round-30 fix N2: resolve shared OrderManager from registry
                # instead of constructing with wrong kwargs.
                # OrderManager.__init__ requires (connection, account_manager),
                # not (router=). The shared instance is already registered at
                # runtime.py:967 as "order_manager". Reuse it — never create
                # a duplicate.
                _om = None
                if self._registry is not None:
                    _om = self._registry.try_resolve("order_manager")
                if _om is None:
                    # Fallback: construct properly with connection + account_manager
                    _conn = self._resolve_mt5_connection()
                    if _conn is not None:
                        from broker.account_manager import AccountManager
                        from broker.order_manager import OrderManager
                        _acct = AccountManager(_conn)
                        _om = OrderManager(_conn, _acct)
                if _om is not None:
                    self._position_manager = PositionManager(
                        order_manager=_om,
                        journal_bridge=None,
                        on_closed=self._on_mt5_position_closed,
                        trade_memory=self._memory if hasattr(self, '_memory') else None,
                        risk_engine=self._risk if hasattr(self, '_risk') else None,
                    )
                    log.info(
                        f"[AITrader] {self.symbol} PositionManager wired for "
                        f"active management (trailing/breakeven/partial/Friday close)"
                    )
                else:
                    log.warning(
                        f"[AITrader] {self.symbol} PositionManager skipped — "
                        f"no OrderManager available (registry={self._registry is not None})"
                    )
            except Exception as _pm_e:
                log.warning(
                    f"[AITrader] {self.symbol} PositionManager init failed "
                    f"(live management unavailable): {_pm_e}"
                )
        # BUG FIX (cooldown leaking across symbols): approval mode is
        # legitimately global (one human-in-the-loop switch for the whole
        # system), but the circuit breaker must NOT be — it used to fall
        # back to `CircuitBreaker(balance=balance)` with symbol=None, which
        # writes to the legacy shared state file. When this AITrader is used
        # standalone (no circuit_breaker passed in), give it its own
        # per-symbol instance so a losing streak on this symbol can't also
        # cooldown every other AITrader sharing that same legacy file.
        self._circuit_breaker = circuit_breaker or CircuitBreaker(symbol=self.symbol, balance=balance)
        self._approval = approval or ApprovalMode(mode=approval_mode)
        # Correlation filter — prefer shared instance from registry.
        if registry is not None:
            shared_cf = registry.try_resolve("correlation_filter")
            self._corr_filter = shared_cf if shared_cf is not None else CorrelationFilter()
        else:
            self._corr_filter = CorrelationFilter()

        # ── Day 76 — Smart Capital Allocation Engine ──────────────────
        # The PositionSizer fuses Kelly × Volatility × Confidence ×
        # Correlation × Drawdown × Loss-streak into a single lot override
        # that runs AFTER RiskEngine picks SL/TP/entry.  When absent
        # (e.g. standalone AITrader without registry), the trader simply
        # uses RiskEngine's lot as before — fully backward-compatible.
        self._position_sizer = None
        self._live_risk_manager = None
        self._drawdown_monitor = None
        self._kill_switch = None
        if registry is not None:
            self._position_sizer = registry.try_resolve("position_sizer")
            self._live_risk_manager = registry.try_resolve("live_risk_manager")
            self._drawdown_monitor = registry.try_resolve("drawdown_monitor")
            self._kill_switch = registry.try_resolve("kill_switch")

        log.info(
            f"AITrader {self.VERSION} | {self.symbol} {timeframe} | "
            f"Mode: {self.execution_mode.upper()} | Approval: {self._approval.mode_name} | "
            f"Risk Balance: ${balance} | Paper Balance: ${self._paper.balance} | "
            f"Registry: {'yes' if registry else 'no'} | "
            f"Day76 Sizer: {'on' if self._position_sizer else 'off'}"
        )

    # ── Event / metrics helpers (Day 37+ runtime unification) ────────
    def _publish(self, channel: str, payload: dict) -> None:
        """Publish an event to the bus, if available."""
        if self._bus is not None:
            try:
                self._bus.publish(channel, payload, source=f"aitrader:{self.symbol}")
            except Exception as e:
                log.warning(f"event publish failed on {channel}: {e}")

    def _stage(self, name: str):
        """Return a timer context manager from runtime metrics, or a no-op."""
        if self._metrics is not None:
            return self._metrics.timer(name)
        # Fallback no-op context manager
        import contextlib

        class _NoOp:
            def __enter__(self):
                return None
            def __exit__(self, *a):
                return False
        return _NoOp()

    def _record_error(self, channel: str, reason: str) -> None:
        if self._metrics is not None:
            try:
                self._metrics.record_error(channel=channel)
            except Exception as e:
                log.warning(f"Suppressed exception at line 244: {e}")
                pass
        self._publish("system.error", {"channel": channel, "symbol": self.symbol, "reason": reason})

    # ── Co-founder fix: _reject helper for LiveRiskManager gate ──────
    def _reject(self, gate: str, reason: str = "", confidence: float = 0.0) -> dict:
        """Build a rejection result dict when a gate blocks the trade.

        Used by LiveRiskManager gate and other pre-trade checks that need
        to short-circuit the pipeline with a NO TRADE outcome.
        """
        log.info(f"[Trader] REJECTED by {gate}: {reason}")
        return {
            "trade_allowed": False,
            "reject_reason": f"{gate}: {reason}" if reason else gate,
            "final_action": "NO TRADE",
            "confidence": confidence,
            "gate": gate,
        }

    # ── Day 76 — Smart Capital Allocation override ────────────────────
    def _apply_advanced_sizing(
        self,
        risk_out: dict,
        dec_out: dict,
        market_out: dict,
        analysis_out: dict,
    ) -> dict:
        """Run the master PositionSizer on top of RiskEngine's base lot.

        Returns a (possibly modified) `risk_out` dict.  When the sizer is
        not wired or RiskEngine already rejected the trade, the dict is
        returned unchanged.  When the sizer rejects (Kelly negative,
        volatility too high, confidence below floor, portfolio heat
        exceeded, loss streak too long, etc.) the lot is set to 0 and
        reject_reason is filled.  When the sizer approves, lot/risk_usd/
        risk_pc are overridden with the sizer's output.

        The full breakdown (kelly/volatility/confidence/correlation/
        drawdown/streak multipliers + explanation lines) is stored under
        risk_out["position_sizing"] for downstream consumers (journal,
        telegram alerts, dashboard, audit_trail).
        """
        # Pass-through if no sizer, or RiskEngine already rejected.
        if self._position_sizer is None or not risk_out.get("approved"):
            return risk_out

        try:
            ind = market_out.get("ind_ctx", {}) or {}
            regime = market_out.get("regime", {}) or {}
            # ARCHITECTURAL FIX: risk_out no longer carries a `signal` field
            # (risk is an execution filter, not an analysis layer). Use the
            # analysis-layer decision as the authoritative direction. Falls
            # back to "WAIT" only if neither source has a direction.
            direction = dec_out.get("decision") or risk_out.get("signal") or "WAIT"
            confidence = float(dec_out.get("confidence", 0) or 0)

            # Pip value per lot — MUST be in the same unit as self.balance.
            # 2026-07-24: switched from the static USD table to a live MT5
            # lookup (get_live_pip_value_per_lot). The static table assumes
            # a real-USD Standard account; on a Cent account both balance
            # and pip value are reported in cents by MT5, and mixing a
            # cents-denominated balance with a real-USD pip value produces
            # a ~100x error in every risk-% calculation downstream. The
            # live lookup pulls tick value from the same MT5 session that
            # already supplies self.balance, so the two stay unit-consistent
            # regardless of account currency/type. Falls back to the static
            # table (with a warning) only if MT5 is unreachable.
            try:
                from core.constants import get_live_pip_value_per_lot
                mt5_conn = self._resolve_mt5_connection() if hasattr(self, "_resolve_mt5_connection") else None
                pip_value = get_live_pip_value_per_lot(self.symbol, mt5_conn=mt5_conn)
            except Exception as e:
                try:
                    from core.constants import get_pip_value_usd
                    pip_value = get_pip_value_usd(self.symbol)
                    log.warning(
                        f"[Trader] get_live_pip_value_per_lot failed ({e}) — "
                        f"using static USD pip value {pip_value}. If this is "
                        f"a Cent account, sizing will be wrong by ~100x."
                    )
                except Exception:
                    pip_value = 10.0  # last-resort default for non-JPY majors

            # ATR + median ATR for volatility adjustment.
            atr = float(ind.get("atr", 0.0005) or 0.0005)
            # Median ATR — use a rolling estimate from the regime ctx if
            # available; otherwise fall back to the current ATR (ratio = 1.0
            # → NORMAL volatility, no boost/penalty).
            atr_median = float(regime.get("atr_median", atr) or atr)

            # Drawdown % — pull from the DrawdownMonitor if wired.
            current_dd = 0.0
            if self._drawdown_monitor is not None:
                try:
                    dd_status = self._drawdown_monitor.status()
                    current_dd = float(dd_status.get("current_drawdown_pct", 0.0) or 0.0)
                except Exception as e:
                    log.warning(f"Suppressed exception at line 303: {e}")
                    pass

            # Loss streak — pull from the kill switch state if available,
            # else default to 0 (no penalty).
            consecutive_losses = 0
            if self._kill_switch is not None:
                try:
                    ks_state = self._kill_switch.status() if hasattr(self._kill_switch, "status") else {}
                    consecutive_losses = int(ks_state.get("consecutive_losses", 0) or 0)
                except Exception as e:
                    log.warning(f"Suppressed exception at line 314: {e}")
                    pass

            # Open positions for correlation/heat check.
            # Audit fix (EX-2 / X-2): previously read self._paper.get_open_positions()
            # directly, which is NOT authoritative in mt5_demo mode (the bot
            # trades through MT5, not PaperTrader) — this silently blinded the
            # correlation/portfolio-heat check to real MT5 exposure. Now uses
            # _get_live_open_positions_detailed(), which shares the same
            # fail-closed MT5-vs-PaperTrader source logic as
            # _get_live_open_pairs() (used elsewhere for the same purpose).
            try:
                open_positions = self._get_live_open_positions_detailed()
            except Exception as e:
                log.warning(f"[Sizing] _get_live_open_positions_detailed() failed: {e}")
                open_positions = []

            # News window flag — if analysis flagged news as unsafe, treat
            # as news-active so volatility adjuster caps the size.
            news_ctx = analysis_out.get("news_ctx", {}) or {}
            news_active = not bool(news_ctx.get("trade_allowed", True))

            # Historical stats for Kelly — pull from TradeMemory if available.
            win_rate = None
            avg_win_r = None
            avg_loss_r = None
            trade_count = 0
            try:
                mem_ctx = self._memory.get_context_for_ai(self.symbol) if self._memory else {}
                trade_count = int(mem_ctx.get("total_trades", 0) or 0)
                wr_pct = float(mem_ctx.get("overall_win_rate", 0) or 0)
                if trade_count > 0 and wr_pct > 0:
                    win_rate = wr_pct / 100.0
                    # Default R multiples when memory doesn't expose them.
                    avg_win_r = float(mem_ctx.get("avg_win_r", 1.5) or 1.5)
                    avg_loss_r = float(mem_ctx.get("avg_loss_r", 1.0) or 1.0)
            except Exception as e:
                log.warning(f"Suppressed exception at line 350: {e}")
                pass

            # Base risk % from RiskEngine (typically 1.0%).
            base_risk_pct = float(risk_out.get("risk_pc", 1.0) or 1.0) / 100.0
            # Capital tier multiplier — Tier 3 = 1.0 by default; lower
            # tiers reduce.  We pull this from the live risk manager when
            # available, otherwise default to 1.0 (mature system).
            #
            # CRITICAL FIX: Also call check_trade_permission() — this was
            # previously dead code. The method runs 6 pre-trade checks
            # (drawdown, daily loss, consecutive losses, spread, margin,
            # correlation) and should gate every trade.
            tier_mult = 1.0
            if self._live_risk_manager is not None:
                try:
                    tier_mult = float(self._live_risk_manager.current_tier.tier_mult)
                    # Co-founder fix: corrected parameter names + all required params
                    lrm_check = self._live_risk_manager.check_trade_permission(
                        pair=self.symbol,
                        direction=direction,
                        confidence=confidence,
                        sl_pips=float(risk_out.get("sl_pips", 0) or 0),
                        tp_pips=float(risk_out.get("tp_pips", 0) or 0),
                        balance=float(self.balance),
                        atr=atr,
                        atr_median=atr_median,
                        spread_pips=float(ind.get("spread_pips", 1.5) or 1.5),
                        open_positions=self._get_live_open_positions_detailed() if self._paper else [],
                        daily_pnl=float(getattr(self._risk, 'daily_pnl', 0.0) or 0.0),
                        weekly_pnl=float(getattr(self._risk, 'weekly_pnl', 0.0) or 0.0),
                    )
                    # Normalize return (TradePermission object or dict)
                    if hasattr(lrm_check, "allowed"):
                        _lrm_allowed = bool(lrm_check.allowed)
                        _lrm_reason = getattr(lrm_check, "reject_reason", "") or "blocked"
                    elif isinstance(lrm_check, dict):
                        _lrm_allowed = bool(lrm_check.get("allowed", True))
                        _lrm_reason = lrm_check.get("reason") or lrm_check.get("reject_reason", "blocked")
                    else:
                        _lrm_allowed = True
                        _lrm_reason = ""
                    if not _lrm_allowed:
                        # Round-6 audit fix: do NOT replace risk_out with a
                        # fresh dict from self._reject(). The old code did:
                        #     return self._reject("LiveRiskManager gate", ...)
                        # which returned a brand-new minimal dict containing
                        # only {trade_allowed, reject_reason, final_action,
                        # confidence, gate} — and LOST all the keys that
                        # RiskEngine had already computed:
                        #   - rr_ratio         (downstream trade_permission
                        #                        reads risk_out["rr_ratio"]
                        #                        and defaulted to 0 → "Min
                        #                        R:R 1:0" FAIL, blocking
                        #                        every LRM-rejected trade
                        #                        with a misleading reason)
                        #   - approved         (trade_permission reads
                        #                        risk_out["approved"] and
                        #                        defaulted to False → a
                        #                        second spurious FAIL)
                        #   - entry, sl_price, tp_price, lot, sl_pips,
                        #     tp_pips, signal, risk_usd, risk_pc, etc.
                        #
                        # The correct pattern (matching Day 76 Sizer reject
                        # at lines 518-531) is to UPDATE risk_out in place
                        # so downstream gates see the real reason and
                        # don't generate false-positive rejections.
                        log.info(
                            f"[Trader] LiveRiskManager BLOCKED trade: {_lrm_reason} "
                            f"(preserving risk_out keys: rr_ratio={risk_out.get('rr_ratio','?')}, "
                            f"approved will be set to False)"
                        )
                        risk_out["approved"] = False
                        risk_out["lot"] = 0.0
                        risk_out["risk_usd"] = 0.0
                        risk_out["risk_pc"] = 0.0
                        risk_out["reject_reason"] = f"LiveRiskManager gate: {_lrm_reason}"
                        risk_out["trade_allowed"] = False
                        risk_out["final_action"] = "NO TRADE"
                        # rr_ratio, entry, sl_price, tp_price, sl_pips,
                        # tp_pips, signal — all preserved from RiskEngine.
                        self._publish("risk.event", {
                            "kind": "live_risk_manager_reject",
                            "symbol": self.symbol,
                            "reason": _lrm_reason,
                        })

                        # ── Audit fix: kill-switch Level 3 (max drawdown,
                        # full stop) previously only blocked NEW trades —
                        # existing open positions stayed open indefinitely
                        # with no automatic close mechanism (the only
                        # close-all path was a manual webhook command).
                        # Trigger it here, once, using the same
                        # close_all_orders() path the weekend guard already
                        # uses (proven, already wired) rather than a new
                        # untested code path. Non-fatal: a failure here
                        # must never crash the risk-check chain.
                        if getattr(lrm_check, "emergency_close_required", False) \
                                and not self._level3_emergency_close_done:
                            self._level3_emergency_close_done = True
                            log.critical(
                                f"[Trader] KILL SWITCH LEVEL 3 (max drawdown) — "
                                f"triggering emergency close-all for {self.symbol}"
                            )
                            try:
                                _om = self._registry.try_resolve("order_manager") if self._registry else None
                                if _om is not None:
                                    _results = _om.close_all_orders(
                                        reason=f"Kill switch Level 3: {_lrm_reason}"
                                    )
                                    _failed = [r for r in (_results or []) if not r.get("success")]
                                    if _failed:
                                        log.error(
                                            f"[Trader] Emergency close: {len(_failed)} "
                                            f"position(s) failed to close for {self.symbol}"
                                        )
                                    if self.notifier is not None:
                                        try:
                                            self.notifier.send(
                                                f"🚨 KILL SWITCH LEVEL 3 (max drawdown) — "
                                                f"emergency close-all triggered for {self.symbol}. "
                                                f"{len(_failed) if _failed else 0} position(s) "
                                                f"failed to close (check manually)."
                                            )
                                        except Exception:
                                            pass
                                else:
                                    log.error(
                                        "[Trader] Emergency close: order_manager service "
                                        "unavailable — positions NOT auto-closed, manual "
                                        "close_all webhook command required."
                                    )
                            except Exception as _emc_e:
                                log.error(f"[Trader] Emergency close-all failed: {_emc_e}")

                        return risk_out
                except Exception as e:
                    log.warning(f"[Trader] LiveRiskManager check failed (non-fatal): {e}")

            # New equity high flag — paper trader balance vs starting.
            is_new_high = False
            try:
                is_new_high = float(self._paper.balance) >= float(self.balance) * 1.10
            except Exception as e:
                log.warning(f"Suppressed exception at line 391: {e}")
                pass

            # ── Run the master PositionSizer ──────────────────────────
            sizing = self._position_sizer.calculate(
                balance=float(self.balance),
                risk_pct=base_risk_pct,
                sl_pips=float(risk_out.get("sl_pips", 0) or 0),
                pip_value_per_lot=pip_value,
                confidence=confidence,
                atr=atr,
                atr_median=atr_median,
                consecutive_losses=consecutive_losses,
                tier_mult=tier_mult,
                win_rate=win_rate,
                avg_win_r=avg_win_r,
                avg_loss_r=avg_loss_r,
                trade_count=trade_count,
                pair=self.symbol,
                direction=direction,
                open_positions=open_positions,
                current_drawdown_pct=current_dd,
                is_new_equity_high=is_new_high,
                news_active=news_active,
            )

            # Persist the full breakdown for journal/telegram/dashboard.
            risk_out["position_sizing"] = sizing.to_dict()

            # Apply the sizer's verdict.
            # Day 81+ hotfix: In TEST_MODE, don't let PositionSizer reject
            # trades. The sizer checks Kelly criterion, volatility, drawdown,
            # correlation, etc. — all of which fail on a fresh account with
            # no trade history (Kelly needs win_rate, drawdown needs history,
            # etc.). In TEST_MODE, force-approve with minimum lot.
            _test_mode_sizer = False
            try:
                from config import TEST_MODE
                _test_mode_sizer = bool(TEST_MODE)
            except Exception as e:
                log.warning(f"Suppressed exception at line 431: {e}")
                pass

            if not sizing.approved and _test_mode_sizer:
                # ── SAFETY GUARD (2026-08-09 audit) ───────────────────────
                # TEST_MODE force-approve exists ONLY for MT5 connectivity /
                # integration testing on demo accounts. It must NEVER fire
                # when execution_mode == "mt5_live" — that would bypass risk
                # management on a REAL-MONEY account. Fail-closed: if the
                # operator somehow has TEST_MODE=true AND mt5_live, log a
                # CRITICAL error and respect the sizer's rejection.
                # This guard is purely additive — when execution_mode !=
                # "mt5_live", behavior is byte-identical to pre-audit.
                if self.execution_mode == "mt5_live":
                    log.error(
                        f"[SAFETY] {self.symbol} — TEST_MODE=true force-approve "
                        f"REFUSED in mt5_live mode (real-money). Sizer rejection "
                        f"stands: {sizing.reject_reason}. Set TEST_MODE=false "
                        f"before trading live."
                    )
                else:
                    log.info(
                        f"[Day 76 Sizer] REJECTED {self.symbol} {direction} — {sizing.reject_reason} — "
                        f"BUT TEST_MODE=true, force-approving with lot=0.01 "
                        f"(execution_mode={self.execution_mode} — DEMO/backtest only)"
                    )
                    risk_out["approved"] = True
                    risk_out["lot"] = 0.01
                    try:
                        from core.constants import get_live_pip_value_per_lot
                        mt5_conn = self._resolve_mt5_connection() if hasattr(self, "_resolve_mt5_connection") else None
                        _pip_value = get_live_pip_value_per_lot(self.symbol, mt5_conn=mt5_conn)
                    except Exception:
                        try:
                            from core.constants import get_pip_value_usd
                            _pip_value = get_pip_value_usd(self.symbol)
                        except Exception:
                            _pip_value = 10.0  # last-resort fallback ~EURUSD pip value
                    _sl_pips = float(risk_out.get("sl_pips", 30) or 30)
                    risk_out["risk_usd"] = round(0.01 * _sl_pips * _pip_value, 2)
                    risk_out["risk_pc"] = 1.0
                    risk_out["reject_reason"] = None
            elif not sizing.approved:
                log.info(
                    f"[Day 76 Sizer] REJECTED {self.symbol} {direction} — {sizing.reject_reason}"
                )
                risk_out["approved"] = False
                risk_out["lot"] = 0.0
                risk_out["risk_usd"] = 0.0
                risk_out["risk_pc"] = 0.0
                risk_out["reject_reason"] = f"Day76 Sizer: {sizing.reject_reason}"
                self._publish("risk.event", {
                    "kind": "position_sizer_reject",
                    "symbol": self.symbol,
                    "reason": sizing.reject_reason,
                })
            else:
                log.info(
                    f"[Day 76 Sizer] {self.symbol} {direction} | "
                    f"base_lot={sizing.base_lot:.2f} → final_lot={sizing.lot:.2f} | "
                    f"mult=×{sizing.final_mult:.3f} | "
                    f"risk=${sizing.risk_amount_usd:.0f} ({sizing.risk_pct:.2%})"
                )
                risk_out["lot"] = sizing.lot
                risk_out["risk_usd"] = sizing.risk_amount_usd
                risk_out["risk_pc"] = round(sizing.risk_pct * 100, 2)
                self._publish("analytics.metric", {
                    "symbol": self.symbol,
                    "metric": "position_size_multiplier",
                    "value": sizing.final_mult,
                })

            # ── Market DNA position-size adjustment (Day 100+) ──────
            # Multiply the final lot by the DNA cluster's position_multiplier.
            # This lets the unsupervised regime clusterer scale down trades
            # in unfamiliar/low-edge market states without blocking them.
            try:
                _dna_ctx = (market_out.get("regime_ctx", {}) or {}).get("market_dna", {})
                if _dna_ctx and risk_out.get("approved"):
                    _dna_mult = float(_dna_ctx.get("position_multiplier", 1.0))
                    _orig_lot = risk_out.get("lot", 0)
                    _new_lot = round(_orig_lot * _dna_mult, 2)
                    if _new_lot < _orig_lot:
                        log.info(
                            f"[MarketDNA] {self.symbol} lot adjusted: "
                            f"{_orig_lot:.2f} → {_new_lot:.2f} (×{_dna_mult:.2f}, "
                            f"cluster={_dna_ctx.get('cluster_id')}, "
                            f"tier={_dna_ctx.get('tier')})"
                        )
                    risk_out["lot"] = max(0.01, _new_lot)
                    risk_out["dna_multiplier"] = _dna_mult
                    risk_out["dna_cluster_id"] = _dna_ctx.get("cluster_id")
                    risk_out["dna_tier"] = _dna_ctx.get("tier")
            except Exception as _dna_e:
                log.debug(f"[MarketDNA] adjustment skipped: {_dna_e}")
        except Exception as e:
            # Audit fix (fail-open risk bug): this used to log and fall
            # through with the ORIGINAL risk_out untouched — meaning if
            # RiskEngine had already approved the trade, a crash anywhere
            # in the sizer/permission-check path silently skipped Kelly /
            # volatility / correlation / drawdown / loss-streak sizing and
            # let the trade proceed on RiskEngine's base lot alone. A risk
            # component that fails should never let a trade through it
            # never actually evaluated. We now fail CLOSED: the trade is
            # rejected this cycle and the operator sees why. This can
            # briefly reduce trade frequency if the sizer has a bug, but
            # that is the correct trade-off for a live-money risk gate.
            log.error(
                f"[Day 76 Sizer] {self.symbol} sizing failed — FAILING CLOSED "
                f"(trade rejected, not executed on unsized risk_out): {e}"
            )
            risk_out["approved"] = False
            risk_out["lot"] = 0.0
            risk_out["risk_usd"] = 0.0
            risk_out["risk_pc"] = 0.0
            risk_out["reject_reason"] = f"Day76 Sizer crashed (fail-closed): {e}"
            self._publish("risk.event", {
                "kind": "position_sizer_crash_fail_closed",
                "symbol": self.symbol,
                "error": str(e),
            })

        return risk_out

    def get_signal(self, show_chart: bool = False, auto_paper_trade: bool = True) -> dict:
        return self.run_cycle(show_chart=show_chart, auto_paper_trade=auto_paper_trade)

    def evaluate_decision_core(self, market_out: dict, session_ctx: dict, debugger=None, bypass_checks=None) -> dict:
        """
        SHARED DECISION CORE — Backtest / Demo / Real execution parity.//

        This is the SINGLE implementation of Analysis -> Decision -> Risk ->
        Position Sizing -> Safety Guard (Permission + Correlation) used by
        EVERY execution mode. It is extracted verbatim from run_cycle() (the
        live/demo trading loop) so that a historical replay in backtest mode
        calls the exact same code object as live trading -- not a
        reimplementation, not an approximation.

        Per the project's execution-parity requirement, only these things
        may legitimately differ between modes, and NONE of them live in
        this method:
          - where `market_out` came from (live MT5 tick vs. a historical
            bar built from MT5 history) -- caller's responsibility
          - what happens to the resulting decision (real MT5 order vs.
            BrokerSimulator fill vs. paper trade) -- caller's responsibility
          - account balance bookkeeping (MT5 account vs. simulated ledger)

        Args:
            market_out: MarketAgentResult-shaped dict (df, ind_ctx, regime,
                regime_ctx, mtf_bias, ...). Backtest builds this from a
                historical slice using the SAME canonical indicator
                registry live uses (data/indicator_registry.py) -- see
                backtest/unified_engine.py.
            session_ctx: output of SessionAnalyzer().get_current_session()
                (or, in backtest, the historical-time equivalent).
            debugger: optional signal-pipeline debugger (live-cycle
                instrumentation); safe to leave None in backtest.

        Returns:
            dict with keys: analysis_out, dec_out, risk_out, perm_out,
            memory_ctx, pat_ctx, vec_ctx, entry, session_ctx.
        """
        log.info("[3/9] Analysis Agent...")
        # ── Phase 25 follow-up: enrich market_out with MTF, strength,
        # liquidity BEFORE AnalysisAgent runs, so the analysis layer has
        # the richer context to fuse with its own signals. Fail-safe.
        if _ORPHAN_CONSUMERS_AVAILABLE and enrich_market_context is not None:
            try:
                market_out = enrich_market_context(
                    market_out,
                    symbol=self.symbol,
                    registry=self._registry,
                    timeframe=self.timeframe,
                )
            except Exception as _oc_e:
                log.warning(f"[Trader] enrich_market_context failed (non-fatal): {_oc_e}")
        analysis_out = self._analysis.run(market_out)
        if "error" in analysis_out:
            try:
                from core.trade_decision_log import log_decision
                log_decision(symbol=self.symbol, signal="NO TRADE",
                             reject_stage="analysis_agent",
                             reject_reason=f"Analysis error: {analysis_out.get('error')}")
            except Exception as e: pass
            # Return a dict with the SAME shape the success path returns
            # (see the `return {...}` at the bottom of this method) so
            # every caller can unpack it identically and just check
            # `"error" in core["analysis_out"]` — instead of returning
            # self._error_result()'s differently-shaped dict here, which
            # would break unpacking in run_cycle() / any backtest caller.
            return {
                "analysis_out": analysis_out, "dec_out": {}, "risk_out": {},
                "perm_out": {}, "memory_ctx": {}, "pat_ctx": {}, "vec_ctx": {},
                "entry": None, "session_ctx": session_ctx,
            }

        memory_ctx = self._memory.get_context_for_ai(self.symbol)
        pattern = self._extract_pattern(market_out)
        regime_str = market_out.get("regime", {}).get("regime", "")
        pat_ctx = self._memory.get_pattern_context(self.symbol, regime_str, pattern)
        # FIX (execution-parity audit — NameError found via backtest smoke
        # test, 2nd+ run against a DB with existing trade history): 'ind'
        # and 'latest_price' were both referenced below but never defined
        # in this method — only in run_cycle() (the method this was
        # extracted from), at market_out.get("ind_ctx", {}) / ind.get
        # ("close") or ind.get("price") respectively (see line ~1225).
        ind = market_out.get("ind_ctx", {}) or {}
        latest_price = ind.get("close") or ind.get("price")

        # Day 37 hotfix: initialize BEFORE the conditional so that a fresh
        # symbol with no trade history yet (total_trades == 0) never hits
        # the UnboundLocalError that used to crash every symbol's cycle.
        vec_ctx = {}

        if memory_ctx["total_trades"] > 0:
            log.info(
                f"[Memory] Trades: {memory_ctx['total_trades']} | "
                f"WR: {memory_ctx['overall_win_rate']}% | "
                f"Pattern wins: {pat_ctx.get('similar_wins', 0)} | "
                f"losses: {pat_ctx.get('similar_losses', 0)}"
            )
            if pat_ctx.get("warning"):
                log.info("[Memory] Warning: similar setups produced more losses than wins")

            vec_ctx = self._memory.get_pattern_context(
                pair=self.symbol,
                trend=ind.get("trend"),
                rsi=ind.get("rsi"),
                pattern=pattern,
                regime=regime_str,
            )

        log.info("[4/9] Decision Agent...")
        # Day 81+ hotfix: analysis_out may come from an early-return path
        # (dead zone, error, etc.) that doesn't include a "signal" key.
        # Use defensive `.get()` so we never raise KeyError here.
        # _build_result() already uses `.get("signal", {})` for the same
        # reason — this brings run_cycle() in line with that pattern.
        signal_data = analysis_out.get("signal") or {}
        # Day 81+ hotfix #2: when LLM is unavailable (all Groq keys
        # rate-limited, Gemini auth failed), master_ctx.master_entry
        # is None, so signal_data["entry"] is None. The fallback to
        # ind.get("close", 0) returns 0 if ind_ctx.close is missing,
        # which causes the RiskEngine to compute SL/TP around 0 (e.g.
        # SL=-0.00072, TP=0.00144) — a guaranteed instant stop-out.
        # Use latest_price (already extracted from market_out above)
        # as the second-tier fallback so entry is always a real price.
        entry = signal_data.get("entry") or ind.get("close") or ind.get("price") or latest_price
        if not entry or entry <= 0:
            return self._error_result("No valid price available for entry")
        # Day 72 fix: normalize STRONG_BUY/STRONG_SELL to BUY/SELL for approved check
        _final_norm = analysis_out.get("final_signal", "WAIT")
        if "STRONG_BUY" in str(_final_norm):
            _final_norm = "BUY"
        elif "STRONG_SELL" in str(_final_norm):
            _final_norm = "SELL"
        placeholder_risk = {
            "approved": _final_norm in ("BUY", "SELL"),
            "lot": 0,
            "sl_pips": 0,
            "tp_pips": 0,
            "rr_ratio": 0,
            "reject_reason": None,
            # Audit fix: explicit marker so decision_agent.py doesn't have
            # to infer "placeholder vs. real rejection" from all-zero
            # fields (a real RiskEngine rejection can also be all-zero).
            "is_placeholder": True,
        }
        dec_out = self._decision.decide(market_out, analysis_out, placeholder_risk)
        # 2026-08-13: pass per-pair strategy from signal_result to dec_out
        # so TradePermission can apply strategy-based gate bypass.
        _sig = analysis_out.get("signal", {}) if isinstance(analysis_out, dict) else {}
        if isinstance(_sig, dict) and _sig.get("strategy"):
            dec_out["strategy"] = _sig["strategy"]
        elif isinstance(analysis_out, dict) and analysis_out.get("signal_ctx", {}).get("strategy"):
            dec_out["strategy"] = analysis_out["signal_ctx"]["strategy"]
        self._decision.print_summary(dec_out)
        if debugger:
            debugger.record("decision",
                            dec_out.get("decision", "WAIT"),
                            f"conf={dec_out.get('confidence', 0):.0f}%")

        # ── Phase 25 follow-up: multi-factor signal scoring + confidence
        # management. Runs AFTER DecisionAgent but BEFORE RiskEngine so
        # the risk layer sees the calibrated decision. Can DOWNGRADE
        # decision to WAIT if score < adaptive threshold. Fail-safe.
        if _ORPHAN_CONSUMERS_AVAILABLE and apply_signal_scoring is not None:
            try:
                dec_out, analysis_out = apply_signal_scoring(
                    dec_out, analysis_out, market_out,
                    symbol=self.symbol,
                    registry=self._registry,
                )
                if debugger:
                    debugger.record(
                        "signal_scorer",
                        "WAIT" if dec_out.get("signal_scorer_downgraded") else "OK",
                        dec_out.get("reject_reason", "score passed"),
                    )
            except Exception as _oc_e:
                log.warning(f"[Trader] apply_signal_scoring failed (non-fatal): {_oc_e}")

        log.info("[5/9] Risk Engine...")

        # ── Stop Hunt Direct Lane (2026-08-02, Abdullah audit) ──────────
        # per_strategy_tester.py validated a real out-of-sample edge
        # (76.4%->80.4% / 65.5%->69.5%, two independent 15-pair sets) for
        # the RAW StopHuntSignalEngine signal with exactly 3 filters
        # (session, no-Wednesday, H4 trend agreement) — evaluated on its
        # own, NOT blended with 4 other engines and run through ~10
        # generic consensus-judging gates. Wiring it into the blend
        # (fast_path, above) didn't reproduce the edge because a "solo"
        # stop_hunt signal essentially never reaches the blend unmixed.
        # This lane bypasses the blend entirely: only fires when the
        # blended pipeline found nothing (WAIT/NO TRADE), uses the
        # strategy's OWN entry/SL/TP (see analysis/stop_hunt_direct_lane.py
        # — identical logic to the validated tester), and is tagged so
        # trade_permission.py can skip the blend-only gates for it.
        if dec_out.get("decision") not in ("BUY", "SELL"):
            try:
                from analysis.stop_hunt_direct_lane import get_stop_hunt_direct_signal
                _sh_df = market_out.get("df")
                _sh_df_h4 = analysis_out.get("df_h4")
                if _sh_df is not None and len(_sh_df) >= 20:
                    _sh_sig = get_stop_hunt_direct_signal(
                        _sh_df, symbol=self.symbol, df_h4=_sh_df_h4)
                    if _sh_sig:
                        entry = _sh_sig["entry"]
                        dec_out["decision"] = _sh_sig["action"]
                        dec_out["entry"] = _sh_sig["entry"]
                        dec_out["sl"] = _sh_sig["stop_loss"]
                        dec_out["tp"] = _sh_sig["take_profit"]
                        dec_out["direct_lane"] = "stop_hunt"
                        dec_out["reasons"] = (dec_out.get("reasons") or []) + [
                            f"Stop Hunt Direct Lane: {_sh_sig['reason']} "
                            f"(confidence={_sh_sig['confidence']})"
                        ]
                        log.info(
                            f"[Trader] Stop Hunt Direct Lane FIRED: "
                            f"{_sh_sig['action']} @ {_sh_sig['entry']:.5f} "
                            f"SL={_sh_sig['stop_loss']:.5f} TP={_sh_sig['take_profit']:.5f}"
                        )
                        if debugger:
                            debugger.record("stop_hunt_direct_lane", _sh_sig["action"],
                                             "validated standalone signal, blend was WAIT")
            except Exception as _e_shdl:
                # P1 audit fix (2026-08-03, performance + parity investigation):
                # this used to be log.debug which silently swallowed the
                # ModuleNotFoundError when analysis/stop_hunt_direct_lane.py
                # was missing. Promoted to WARNING permanently — silent
                # import-failure swallowing is how the original parity bug
                # went undiagnosed for weeks. Do NOT downgrade back to debug.
                log.warning(
                    f"[Trader] Stop Hunt Direct Lane check failed (non-fatal): {_e_shdl}"
                )

        # Day 81+ hotfix (Day 90 bugfix): sync live open positions into
        # RiskEngine so the correlation check uses authoritative PaperTrader
        # state instead of potentially-stale daily_risk.json open_pairs list.
        #
        # Day 90 bugfix history:
        #   Previously this was wrapped in a try/except that logged at DEBUG
        #   level — meaning any failure was silently swallowed and the
        #   operator never knew. Worse, RiskEngine had TWO duplicate
        #   sync_open_positions methods (Python kept the second one that
        #   never set _live_open_pairs), so even when this call "succeeded",
        #   the correlation check still fell back to the stale file state.
        #
        #   Both bugs are now fixed:
        #     1. risk_engine.py has ONE sync_open_positions method that sets
        #        BOTH _live_open_pairs (in-memory) and daily_risk.json (file)
        #     2. This call logs failures at WARNING level (visible in prod)
        #        and is no longer wrapped in a try/except that hides errors.
        #        If PaperTrader.get_open_positions() raises, we log + fall
        #        back to an empty list (no open positions = no correlation
        #        blocks), which is safer than silently using stale state.
        _live_open = self._get_live_open_pairs()

        if hasattr(self._risk, "sync_open_positions"):
            try:
                self._risk.sync_open_positions(_live_open)
            except Exception as e:
                # Day 90 bugfix: log at WARNING so silent failures are visible.
                # RiskEngine.sync_open_positions now has its own internal
                # try/except + counters, so this outer catch is just a
                # safety net for unexpected attribute errors etc.
                log.warning(
                    f"[Risk] sync_open_positions raised: {e} — "
                    f"correlation check may use stale daily_risk.json state"
                )
        else:
            # Day 90 bugfix: surface this — should never happen with the
            # merged RiskEngine, but if it does we need to know.
            log.warning(
                f"[Risk] self._risk ({type(self._risk).__name__}) has no "
                f"sync_open_positions method — correlation check will use "
                f"stale daily_risk.json state"
            )

        risk_out = self._risk.evaluate(
            signal=dec_out["decision"],
            entry=entry,
            atr=ind.get("atr", 0.0005),
            regime=market_out["regime"],
            # EXECUTION-PROOF AUDIT FIX: pass the live correlation_ctx
            # produced by CorrelationEngine in AnalysisAgent. Previously
            # this was computed every cycle and discarded (CONSUMPTION-MAP
            # row #63). Now RiskEngine uses it as an additional gate +
            # lot-sizing multiplier. Falls back gracefully to None when
            # the ctx is missing (e.g. analysis pipeline errored).
            correlation_ctx=analysis_out.get("correlation_ctx") if isinstance(analysis_out, dict) else None,
        )

        # Audit fix: fail CLOSED on new entries when we can't trust our
        # picture of live exposure/PnL. Two independent degraded-state
        # signals are checked:
        #   1. _mt5_sync_ok=False  → _get_live_open_pairs() couldn't reach
        #      MT5 this cycle, so the correlation check above may have run
        #      against an incomplete/empty position list.
        #   2. _mt5_disconnect_cycles beyond threshold → the close-detector
        #      hasn't been able to poll MT5 for several cycles in a row,
        #      so any losses that occurred during the outage haven't been
        #      folded into daily PnL — the circuit breaker is blind.
        # Existing open positions are left alone (we don't touch SL/TP or
        # force-close); only NEW entries are blocked.
        # 2026-08-13 fix: add ALLOW_MT5_SYNC_BYPASS env var — when true,
        # skip the MT5 sync fail-closed check (for environments where MT5
        # connection is known to be intermittent but trading should continue).
        _allow_mt5_bypass = os.getenv("ALLOW_MT5_SYNC_BYPASS", "false").lower() in ("1", "true", "yes")
        if (
            self.execution_mode == "mt5_demo"
            and risk_out.get("approved")
            and dec_out.get("decision") in ("BUY", "SELL")
            and not _allow_mt5_bypass
        ):
            if not getattr(self, "_mt5_sync_ok", True):
                risk_out["approved"] = False
                risk_out["lot"] = 0.0
                risk_out["reject_reason"] = (
                    "MT5 position sync unavailable this cycle — refusing new "
                    "entry (fail-closed; existing positions unaffected)"
                )
                log.error(f"[Risk] {self.symbol} — {risk_out['reject_reason']}")
            elif getattr(self, "_mt5_disconnect_cycles", 0) >= self._MT5_DISCONNECT_FAIL_CLOSED_THRESHOLD:
                risk_out["approved"] = False
                risk_out["lot"] = 0.0
                risk_out["reject_reason"] = (
                    f"MT5 unreachable for {self._mt5_disconnect_cycles} consecutive "
                    f"cycles — daily PnL/circuit breaker may be stale, refusing new "
                    f"entry (fail-closed)"
                )
                log.error(f"[Risk] {self.symbol} — {risk_out['reject_reason']}")

        self._risk.print_summary(risk_out)

        # Observability fix: RiskEngine's verdict was never reaching
        # execution.log. log_risk_evaluated() has existed in
        # core/execution_logger.py since Day 81 but nothing called it --
        # every "Risk approved" block in blocked_audit.py's pareto was a
        # black box (we knew it failed, never why). Log the FINAL risk_out
        # (post fail-closed MT5-sync checks above), matching the pattern
        # used for permission.checked below.
        try:
            from core.execution_logger import log_risk_evaluated
            log_risk_evaluated(
                symbol=self.symbol,
                approved=risk_out.get("approved", False),
                lot=risk_out.get("lot", 0),
                sl=risk_out.get("sl_price"),
                tp=risk_out.get("tp_price"),
                reject_reason=risk_out.get("reject_reason"),
                evaluation_id=getattr(self, "_current_evaluation_id", None),
            )
        except Exception as e:
            log.warning(f"Suppressed exception logging risk.evaluated: {e}")
        if debugger:
            risk_status = "OK" if risk_out.get("approved") else "REJECT"
            # Day 81+ crash fix: reject_reason can be None (not a string),
            # so we can't do [:20] on it directly. Coerce to string first.
            _reject_reason = risk_out.get("reject_reason") or "approved"
            debugger.record("risk", risk_status,
                            f"lot={risk_out.get('lot', 0)} "
                            f"reason={str(_reject_reason)[:20]}")

        daily = self._risk.get_daily_summary()
        log.info(
            f"Daily PnL — Net: ${daily['net_usd']} | "
            f"Loss: {daily['daily_loss_pc']}% | "
            f"Limit left: {daily['limit_remaining_pc']}%"
        )

        # ── Day 76 — Smart Capital Allocation override ───────────────
        # Run the master PositionSizer on top of RiskEngine's base lot.
        # This applies Kelly × Volatility × Confidence × Correlation ×
        # Drawdown × Loss-streak multipliers and may shrink, grow, or
        # block the lot.  When the sizer is not wired, risk_out passes
        # through unchanged (fully backward-compatible).
        risk_out = self._apply_advanced_sizing(risk_out, dec_out, market_out, analysis_out)

        # Co-founder fix: SYNC dec_out with FINAL risk_out so final report
        # and learning agent see REAL lot/sl/tp/entry, not placeholder values.
        dec_out["lot"]    = risk_out.get("lot", dec_out.get("lot", 0))
        dec_out["entry"]  = risk_out.get("entry",  dec_out.get("entry"))
        dec_out["sl"]     = risk_out.get("sl_price", dec_out.get("sl"))
        dec_out["tp"]     = risk_out.get("tp_price", dec_out.get("tp"))
        dec_out["sl_pips"] = risk_out.get("sl_pips", dec_out.get("sl_pips", 0))
        dec_out["tp_pips"] = risk_out.get("tp_pips", dec_out.get("tp_pips", 0))
        dec_out["rr"]     = risk_out.get("rr_ratio", dec_out.get("rr", 0))

        # Round-30 fix F1: pass df into dec_out so trade_permission's
        # entry_quality_guardrails can access OHLCV data. Without this,
        # the guardrails code looks for decision_out.get("_df"), finds
        # None, and silently skips all 12 entry-quality checks.
        dec_out["_df"] = market_out.get("df")
        dec_out["_symbol"] = self.symbol

        # 2026-07-23 fix: same silent-gap pattern as the _df fix above.
        # trade_permission's entry_quality_guardrails AND the newly-wired
        # confirmation_bias_defense both read decision_out.get("ind_ctx", {}),
        # but dec_out (DecisionAgent's return dict) never set this key —
        # it was always {}, so RSI/MACD/trend checks silently no-op'd
        # (default rsi=50, no macd_cross, no trend match, so the
        # confirmation-bias gate could never actually fire).
        dec_out["ind_ctx"] = market_out.get("ind_ctx", {})
        # BUG FIX: market_out never contains a "market_bias" key anywhere in
        # the pipeline (grep-verified) — the previous line always evaluated
        # to None, so confirmation_bias_defense's market_bias check could
        # never fire. The real source is analysis_agent's MarketBiasEngine
        # output, stored in analysis_out["bias_ctx"]["bias"].
        dec_out["market_bias"] = dec_out.get("market_bias") or (analysis_out.get("bias_ctx", {}) or {}).get("bias")
        # BUG FIX: market_out["mtf_bias"] is a dict ({"bias": ..., "confidence":
        # ...} — see agents/market_agent.py), not a plain string. It "worked"
        # by accident because downstream code does substring checks like
        # "bear" in str(mtf_bias).lower(), and str(dict) happens to contain
        # the bias word — but that's fragile, not correct. Extract the
        # actual bias string explicitly.
        dec_out["mtf_bias"] = dec_out.get("mtf_bias") or (market_out.get("mtf_bias") or {}).get("bias", "NEUTRAL")
        # 2026-08-07 fix: dec_out["mtf_bias"] above collapses the full MTF
        # read down to a single bias STRING (BULLISH/BEARISH/NEUTRAL), which
        # loses the per-timeframe breakdown. That per-TF breakdown ('4h',
        # '1h', '15m' trend strings, from analysis/timeframe.py's
        # MultiTimeframeAnalyzer.get_bias()) is exactly what's needed to
        # enforce "only trade when H4, H1 and M15 actually agree" — without
        # it, trade_permission.py has no way to see that e.g. H4 is
        # bullish, H1 is bullish, but M15 is bearish; it only ever sees the
        # single collapsed "BULLISH" bias. Thread the raw per-TF dict
        # through separately so the new hard gate below can use it.
        # ── MTF trends for TradePermission + Devil's Advocate ─────────
        # DA expects keys "4h"/"1h"/"15m". Upstream may use H4/H1/M15 or
        # only a collapsed bias string. Normalize here so DA never sees
        # all-unknown HTF (which forced 100% REJECT in audit logs).
        _mtf_bias_full = market_out.get("mtf_bias") or {}
        if not isinstance(_mtf_bias_full, dict):
            _mtf_bias_full = {}
        _raw_trends = _mtf_bias_full.get("trends") or {}
        if not isinstance(_raw_trends, dict):
            _raw_trends = {}
        _mtf_struct = analysis_out.get("mtf_structure_ctx") or {}
        _ind_for_mtf = market_out.get("ind_ctx") or {}

        def _pick_tf(*candidates):
            for c in candidates:
                if c is None:
                    continue
                s = str(c).strip()
                if s and s.upper() not in ("UNKNOWN", "NONE", ""):
                    return s
            return "unknown"

        dec_out["mtf_trends"] = {
            "4h": _pick_tf(
                _raw_trends.get("4h"), _raw_trends.get("H4"), _raw_trends.get("h4"),
                _mtf_bias_full.get("h4_trend"),
                _mtf_struct.get("h4_trend"), _mtf_struct.get("external_bias"),
                _mtf_struct.get("combined_bias"),
            ),
            "1h": _pick_tf(
                _raw_trends.get("1h"), _raw_trends.get("H1"), _raw_trends.get("h1"),
                _mtf_bias_full.get("h1_trend"),
                _mtf_struct.get("h1_trend"), _mtf_struct.get("internal_bias"),
            ),
            "15m": _pick_tf(
                _raw_trends.get("15m"), _raw_trends.get("M15"), _raw_trends.get("m15"),
                _mtf_bias_full.get("m15_trend"),
                _ind_for_mtf.get("trend"),
            ),
        }
        # B4a fix: propagate stale-TF list so TradePermission can distinguish
        # "mtf_trends missing because of upstream crash" from "mtf_trends
        # missing because H1/H4 stale". The P4 hard-block fires either way,
        # but the log detail can now be specific.
        dec_out["mtf_stale_tfs"] = _mtf_bias_full.get("stale_tfs", []) if isinstance(_mtf_bias_full, dict) else []

        # 2026-07-23: feed the advisory (log-only) entry-score /
        # institutional-entry-framework check in trade_permission with real
        # context instead of the {} defaults it would otherwise get.
        # Also alias structure_bos → bos so Devil's Advocate (and any other
        # consumer looking for "bos") sees the real event, not unknown.
        _sr = dict(analysis_out.get("sr_ctx") or {})
        if "nearest_zone" not in _sr or not _sr.get("nearest_zone"):
            _sr["nearest_zone"] = (
                _sr.get("location")
                or _sr.get("nearest_support")
                or _sr.get("nearest_resistance")
                or "unknown"
            )
        dec_out["sr_ctx"] = _sr

        _struct = dict(analysis_out.get("structure_ctx") or {})
        if "bos" not in _struct or _struct.get("bos") in (None, "", "unknown"):
            _struct["bos"] = (
                _struct.get("structure_bos")
                or _struct.get("break_of_structure")
                or "NONE"
            )
        if "choch" not in _struct or _struct.get("choch") in (None, "", "unknown"):
            _struct["choch"] = (
                _struct.get("structure_choch")
                or _struct.get("change_of_character")
                or "NONE"
            )
        dec_out["structure_ctx"] = _struct
        dec_out["smc_ctx"] = analysis_out.get("smc_ctx", {})
        dec_out["liquidity_ctx"] = analysis_out.get("liquidity_ctx", {})

        # Spread: never leave a literal 0.0 for DA (it treated 0 as critical
        # failure). Prefer real pips; if missing, omit so DA shows "unknown".
        _ind = dict(market_out.get("ind_ctx") or {})
        _sp = _ind.get("spread_pips")
        try:
            _sp_f = float(_sp) if _sp is not None else None
        except (TypeError, ValueError):
            _sp_f = None
        if _sp_f is None or _sp_f <= 0:
            _ind["spread_pips"] = None
        else:
            _ind["spread_pips"] = _sp_f
        dec_out["ind_ctx"] = _ind
        # 2026-08-02 (Abdullah audit): market_out["regime"] comes straight
        # from MarketRegimeDetector.detect() on real historical price data
        # (no live-API dependency, unlike mtf_bias above) — used by the new
        # trend-alignment hard gate in trade_permission.py. Was previously
        # never threaded into dec_out at all, so trade_permission's
        # `decision_out.get("regime", {})` always silently read {}.
        dec_out["regime"] = market_out.get("regime", {})
        # 2026-08-02 (Abdullah audit): the revenge-trading detector inside
        # trade_permission.py hardcodes `TraderDB()` with no db_path, which
        # ALWAYS points at the live database/trader.db — even during a
        # backtest run, which uses its own isolated TraderDB(db_path=...)
        # (see backtest/unified_engine.py's _make_backtest_trader). That
        # means the detector's `get_trade_history()` call during backtest
        # was reading the live account's history (usually empty/irrelevant)
        # instead of the backtest's own trades, so clustered/correlated
        # entries within the SAME backtest run were never caught. self._db
        # is already correctly wired to the right DB for both live and
        # backtest (see the TraderDB injection fix above in __init__) —
        # just needs to be threaded through like sr_ctx/regime above.
        dec_out["_db"] = self._db
        # 2026-08-02 (Abdullah audit): fast_path flag set by the
        # adaptive_decision wiring fix in analysis_agent.py — True only
        # for a clean solo stop_hunt signal (validated 76-80%/65-70%
        # out-of-sample edge, see backtest/per_strategy_tester.py). Used
        # by trade_permission.py to skip the blend-only gates (Confluence
        # quality, SMC+Session fusion) that were never validated for a
        # standalone strategy and were diluting this one's proven edge.
        dec_out["fast_path"] = (analysis_out.get("unified_signal", {}) or {}).get("fast_path", False)

        # ── Phase 25 follow-up: advanced risk gates ─────────────────────
        # Runs AFTER RiskEngine + Day76 Sizer, BEFORE TradePermission.
        # Invokes: entry_quality_guardrails, institutional_entry_framework,
        # structure_stop, rr_policy, book_guardrails, trading_controls,
        # streak_tracker, advanced_risk_orchestrator, monte_carlo_engine,
        # cost_tracker. Each may BLOCK (set approved=False) or dampen lot.
        # Fail-safe: any service that errors logs WARNING and is skipped.
        if _ORPHAN_CONSUMERS_AVAILABLE and apply_advanced_risk_gates is not None:
            try:
                risk_out = apply_advanced_risk_gates(
                    risk_out, dec_out, market_out, analysis_out,
                    symbol=self.symbol,
                    balance=float(self.balance),
                    registry=self._registry,
                )
                if debugger:
                    _rag_status = "OK" if risk_out.get("approved") else "REJECT"
                    debugger.record(
                        "advanced_risk_gates",
                        _rag_status,
                        risk_out.get("reject_reason", "all gates passed"),
                    )
            except Exception as _oc_e:
                log.warning(f"[Trader] apply_advanced_risk_gates failed (non-fatal): {_oc_e}")

        # ── BUG FIX (root cause of "Confluence quality: 0 factors, UNKNOWN"
        # blocking ~93% of all signals): analysis_out["confluence"] (built by
        # AnalysisAgent / Day-67 ConfluenceEngine) was computed correctly and
        # used later for journaling (see confluence_ctx around line ~2346)
        # and for the debug-only "confluence_quality" report field (~3258),
        # but was NEVER copied into dec_out before being handed to
        # TradePermission.check(). TradePermission reads
        # decision_out.get("aligned_factors", 0) and
        # decision_out.get("setup_quality", "UNKNOWN") — since dec_out never
        # had these keys, EVERY trade failed the Confluence quality gate
        # with the default "0 factors, UNKNOWN", regardless of what the
        # ConfluenceEngine actually found. Wire it through here.
        _confluence_ctx = analysis_out.get("confluence") if isinstance(analysis_out, dict) else None
        if isinstance(_confluence_ctx, dict):
            dec_out.setdefault("aligned_factors", _confluence_ctx.get("aligned_factors", 0))
            dec_out.setdefault("total_factors", _confluence_ctx.get("total_factors", 0))
            dec_out.setdefault("setup_quality", _confluence_ctx.get("setup_quality", "UNKNOWN"))
            dec_out.setdefault("raw_setup_quality", _confluence_ctx.get("raw_setup_quality", _confluence_ctx.get("setup_quality", "")))
        else:
            log.warning(
                "[Trader] analysis_out['confluence'] missing/not a dict — "
                "Confluence quality gate will fall back to 0 factors/UNKNOWN "
                "(check AnalysisAgent/ConfluenceEngine wiring)."
            )

        # A4 fix: log the FINAL risk_out state (post-sizer, post-RAG gates)
        # so the operator can see the difference between risk.evaluated
        # (raw RiskEngine output) and risk.finalized (post-mutation state).
        # AUDUSD audit caught: risk.evaluated.approved=true was logged, but
        # then LiveRiskManager/_apply_advanced_sizing mutated approved=False
        # in place, and the operator couldn't see the change. This new
        # event makes the mutation visible without losing the raw snapshot.
        try:
            from core.execution_logger import log_event
            log_event("risk.finalized", {
                "symbol":         self.symbol,
                "approved":       risk_out.get("approved", False),
                "lot":            risk_out.get("lot", 0),
                "reject_reason":  risk_out.get("reject_reason"),
                "mutator":        "post_apply_advanced_sizing+apply_advanced_risk_gates",
                "raw_approved":   "see risk.evaluated event",
                "evaluation_id":  getattr(self, "_current_evaluation_id", None),
            })
        except Exception as e:
            log.debug(f"[Trader] risk.finalized log failed (non-fatal): {e}")

        log.info("[6/9] Safety Guard (Permission + Correlation)...")
        perm_out = self._perm.check(
            decision_out=dec_out,
            risk_out=risk_out,
            news_ctx=analysis_out.get("news_ctx", {}),
            session_ctx=self._session_permission_context(
                analysis_out.get("session_ctx") if isinstance(analysis_out, dict) else None,
                fallback=session_ctx,
            ),
            execution_filters=analysis_out.get("execution_filters", {}),
            bypass_checks=bypass_checks,
            symbol=self.symbol,  # 2026-08-13: per-pair profile
        )

        # Day 97+ Book Page 15: Signal Persistence Filter
        # Suppress entries when signal is flip-flopping (unstable)
        if perm_out["allowed"]:
            try:
                from core.signal_persistence import get_signal_persistence_filter
                spf = get_signal_persistence_filter()
                final_sig = perm_out.get("final_action", "WAIT")
                if not spf.is_stable(self.symbol, final_sig):
                    perm_out["allowed"] = False
                    perm_out["execution_allowed"] = False
                    perm_out["final_action"] = "NO TRADE"
                    perm_out["execution_action"] = "NO TRADE"
                    perm_out["blocked_reason"] = "Signal flip-flopping (unstable)"
                    perm_out["checks"].append({
                        "check": "Signal persistence",
                        "passed": False,
                        "detail": f"Signal flip-flopping (unstable)",
                    })
                    perm_out["total"] = perm_out.get("total", 0) + 1
                spf.record(self.symbol, final_sig, dec_out.get("confidence", 0))
            except Exception as e:
                log.warning(f"Suppressed exception at line 798: {e}")
                pass

        # Day 97+ Book Page 15: Regime Suppression
        # Suppress entries in known false-signal regimes
        if perm_out["allowed"]:
            try:
                from core.regime_suppression import get_regime_suppressor
                rs = get_regime_suppressor()
                regime_ctx = market_out.get("regime", {})
                ind_ctx = market_out.get("ind_ctx", {})
                # FIX (2026-08-19 audit Bug 4): pass bar_time so regime
                # suppression uses the historical bar's timestamp instead
                # of wall-clock time when running a backtest on Friday UTC.
                # `current_time` is set by unified_engine at line 354 from
                # primary_df.index[i]; in live mode it's None, which
                # preserves the old wall-clock behavior in regime_suppression.
                _bar_time = market_out.get("bar_time") or market_out.get("current_time")
                suppress, reason = rs.should_suppress(
                    symbol=self.symbol,
                    regime=regime_ctx,
                    session=session_ctx,
                    news_ctx=analysis_out.get("news_ctx", {}),
                    ind_ctx=ind_ctx,
                    bar_time=_bar_time,
                )
                if suppress:
                    perm_out["allowed"] = False
                    perm_out["execution_allowed"] = False
                    perm_out["final_action"] = "NO TRADE"
                    perm_out["execution_action"] = "NO TRADE"
                    perm_out["blocked_reason"] = f"Regime suppression: {reason}"
                    perm_out["checks"].append({
                        "check": "Regime suppression",
                        "passed": False,
                        "detail": reason,
                    })
                    perm_out["total"] = perm_out.get("total", 0) + 1
            except Exception as e:
                log.warning(f"Suppressed exception at line 825: {e}")
                pass

        # FIX (2026-08-19 audit Bug 5): in mt5_demo mode, PaperTrader is
        # NOT authoritative (stale open-position records after broker-side
        # closes / sync failures block all subsequent entries forever — a
        # known "orphan position" issue). Use _get_live_open_pairs() which
        # reads real MT5 positions, the same authoritative source the
        # correlation filter at line ~1603 already uses. PaperTrader is
        # still authoritative in pure paper / backtest mode.
        from core.constants import is_backtest_mode as _bt_dup_check
        _use_paper_for_dup = (self.execution_mode != "mt5_demo") or _bt_dup_check()
        if _use_paper_for_dup:
            _dup_open = self._paper.has_open_position(self.symbol, perm_out.get("final_action"))
        else:
            # Live MT5 demo: read real positions
            try:
                _live_pairs = self._get_live_open_pairs()
                _target_dir = perm_out.get("final_action")
                _dup_open = any(
                    (p.get("symbol") == self.symbol and
                     str(p.get("signal","")).upper() == str(_target_dir).upper())
                    for p in _live_pairs if isinstance(p, dict)
                ) if _target_dir in ("BUY","SELL") else False
            except Exception:
                _dup_open = False  # fail open if MT5 unreachable
        if _dup_open:
            perm_out["allowed"] = False
            perm_out["execution_allowed"] = False
            perm_out["final_action"] = "NO TRADE"
            perm_out["execution_action"] = "NO TRADE"
            perm_out["blocked_reason"] = f"{self.symbol} {dec_out.get('decision')} already open"
            perm_out["checks"].append(
                {
                    "check": "Duplicate trade",
                    "passed": False,
                    "detail": f"{self.symbol} {dec_out.get('decision')} already open",
                }
            )
            perm_out["total"] = perm_out.get("total", 0) + 1

        # Correlation check — same underlying-risk group already has an open
        # position (e.g. EURUSD BUY blocks a fresh GBPUSD BUY). Lot size, SL
        # distance, and daily loss are already enforced inside RiskEngine
        # above; news/confidence/session/duplicate are TradePermission above;
        # this is the last piece of the Day 37 "Safety Guard" checklist.
        if perm_out["allowed"]:
            # Bugfix: in mt5_demo mode, PaperTrader is not authoritative —
            # use _get_live_open_pairs() which reads real MT5 positions.
            open_pairs = self._get_live_open_pairs()
            self._corr_filter.sync_open(open_pairs)
            still_allowed = self._corr_filter.allow(
                [{"symbol": self.symbol, "signal": perm_out["final_action"]}]
            )
            if not still_allowed:
                perm_out["allowed"] = False
                perm_out["execution_allowed"] = False
                perm_out["final_action"] = "NO TRADE"
                perm_out["execution_action"] = "NO TRADE"
                perm_out["blocked_reason"] = "Correlated pair group already has an open position"
                perm_out["checks"].append(
                    {
                        "check": "Correlation filter",
                        "passed": False,
                        "detail": "Correlated pair group already has an open position",
                    }
                )
                perm_out["total"] = perm_out.get("total", 0) + 1

        # ── Phase 25 follow-up: final decision gate ─────────────────────
        # The absolute LAST veto before execution. Runs AFTER all existing
        # perm_out filters (signal_persistence, regime_suppression,
        # duplicate, correlation) so it has the final word.
        # Invokes: system_watchdog, network_monitor, ml_concept_drift_detector.
        # (decision_validator requires FusionResult — not constructed by
        #  the current pipeline; tracked as a follow-up.)
        # Fail-safe: a service that errors logs WARNING and is skipped.
        if _ORPHAN_CONSUMERS_AVAILABLE and final_decision_gate is not None:
            try:
                perm_out = final_decision_gate(
                    perm_out, dec_out, risk_out, market_out, analysis_out,
                    symbol=self.symbol,
                    registry=self._registry,
                )
                if debugger:
                    _fdg_status = "OK" if perm_out.get("allowed") else "VETO"
                    _fdg_reason = perm_out.get("blocked_reason", "passed")
                    debugger.record("final_decision_gate", _fdg_status, _fdg_reason)
            except Exception as _oc_e:
                log.warning(f"[Trader] final_decision_gate failed (non-fatal): {_oc_e}")

        self._perm.print_summary(perm_out)
        if debugger:
            perm_status = "OK" if perm_out.get("allowed") else "BLOCK"
            debugger.record("permission", perm_status,
                            f"{perm_out.get('passed', 0)}/{perm_out.get('total', 0)} checks")

        # Day 81+ hotfix: log permission outcome to execution.log
        try:
            from core.execution_logger import log_permission_checked
            # Bugfix (decision/allowed mismatch): `decision` must reflect the
            # *gated* outcome, not the raw analysis signal. Previously this
            # always logged dec_out["decision"] verbatim, so a blocked SELL
            # (allowed=false) still showed decision="SELL" in execution.log —
            # any downstream dashboard/analytics reading that field alone
            # would think the SELL actually went through. Mirror the same
            # "GATED — analysis verdict preserved" convention already used
            # around line ~1614 for dec_out["execution_action"]: keep the raw
            # signal in its own field, and make `decision` the value that was
            # actually acted on.
            _raw_signal = dec_out.get("decision")
            _perm_allowed = perm_out.get("allowed", False)
            if _perm_allowed:
                _gated_decision = _raw_signal
            elif _raw_signal in (None, "", "WAIT", "NO TRADE", "HOLD"):
                _gated_decision = "NO_TRADE"
            else:
                _gated_decision = f"BLOCKED_{_raw_signal}"
            log_permission_checked(
                symbol=self.symbol,
                allowed=_perm_allowed,
                passed=perm_out.get("passed", 0),
                total=perm_out.get("total", 0),
                failed_checks=[c.get("check", "?") for c in perm_out.get("checks", [])
                               if not c.get("passed", True)],
                decision=_gated_decision,
                raw_signal=_raw_signal,
                # Day 81+ fix (log discrepancy): previously logged only
                # dec_out["confidence"] (pre-penalty), which could show e.g.
                # "Confidence: 73%" right next to a failed "Min confidence"
                # check whose actual gating value (post entry-quality-penalty,
                # e.g. 52%) lived only in trader.log. Log both explicitly so
                # execution.log alone is enough to audit/backtest against.
                confidence_pre_penalty=perm_out.get(
                    "confidence_pre_penalty", dec_out.get("confidence", 0)),
                confidence_post_penalty=perm_out.get(
                    "confidence_post_penalty", dec_out.get("confidence", 0)),
                # Diagnostic fix: entry_quality_detail carries WHICH specific
                # guardrail checks fired and how much each one penalized
                # confidence (see risk/entry_quality_guardrails.py _PENALTY_MAP),
                # but until now that detail died inside perm_out and only the
                # folded pre/post confidence numbers reached execution.log.
                # That made it impossible to audit, from the log alone,
                # whether blocks were driven by e.g. chasing_filter vs.
                # sl_swing_anchor+tp_structure_validation compounding — you
                # had to re-run the trade to see it. Surface the summary here.
                entry_quality_penalty=(
                    (perm_out.get("entry_quality_detail") or {}).get("confidence_penalty")
                ),
                entry_quality_failed_checks=[
                    r.get("flag_name")
                    for r in ((perm_out.get("entry_quality_detail") or {}).get("results") or [])
                    if isinstance(r, dict) and not r.get("passed", True)
                ],
                evaluation_id=getattr(self, "_current_evaluation_id", None),
            )
        except Exception as e:
            log.warning(f"Suppressed exception at line 881: {e}")
            pass

        return {
            "analysis_out": analysis_out,
            "dec_out": dec_out,
            "risk_out": risk_out,
            "perm_out": perm_out,
            "memory_ctx": memory_ctx,
            "pat_ctx": pat_ctx,
            "vec_ctx": vec_ctx,
            "entry": entry,
            "session_ctx": session_ctx,
        }


    def run_cycle(self, show_chart: bool = False, auto_paper_trade: bool = True) -> dict:
        log.debug("━" * 52)
        log.debug(f"  AITrader {self.VERSION} — {self.symbol} {self.timeframe}")
        log.debug("━" * 52)
        t0 = time.time()

        # ─── Fix #3 (Round 3 audit): evaluation_id correlation ───────
        # Generate a unique ID per cycle so all log events from this cycle
        # (risk.evaluated, risk.finalized, permission.checked, devils_advocate.review,
        # approval.processed, router.execute.*) can be correlated by the operator.
        # Format mirrors orchestrator/trading_orchestrator.py:178 cycle_id pattern.
        import uuid as _uuid_mod
        self._current_evaluation_id = (
            f"eval_{int(t0)}_{self.symbol}_{_uuid_mod.uuid4().hex[:8]}"
        )
        log.debug(f"[Trader] {self.symbol}: cycle evaluation_id={self._current_evaluation_id}")

        # Day 81+ hotfix: reset per-cycle LLM call counter so each
        # symbol cycle gets a fresh budget of MAX_LLM_CALLS_PER_CYCLE.
        # Without this, the counter would accumulate across cycles and
        # block all LLM calls after the first few symbols.
        try:
            from core.llm_key_manager import get_llm_key_manager
            get_llm_key_manager().reset_cycle_calls()
        except Exception as e:
            log.warning(f"Suppressed exception at line 497: {e}")
            pass

        # ── Day 81+ — Start signal pipeline debugger for this cycle ──
        try:
            from monitoring.signal_debugger import get_signal_debugger
            debugger = get_signal_debugger()
            debugger.start_cycle(self.symbol, self.timeframe)
        except Exception as e:
            debugger = None

        # ── Audit fix (Phase 9 wiring): Honor HumanOverrideSystem state. ──
        # HumanOverrideSystem is registered in core/runtime.py:boot_orchestrator
        # (Phase 23) and its poll thread runs continuously, receiving STOP_ALL /
        # PAUSE / CLOSE_ALL commands from memory/human_override_cmd.json or
        # Telegram. It updates SystemState.human_override to "PAUSED" or
        # "STOPPED" — but AITrader.run_cycle never read that field, so the
        # emergency stop button had zero effect on trading. This gate honors
        # the operator's override BEFORE any market data is fetched, before
        # any analysis runs, and before any new trade is opened. Existing
        # open positions continue to be monitored by PaperTrader and
        # PositionManager in the close-detection path below; only NEW entries
        # are blocked, matching the same "monitor existing, block new" rule
        # the Circuit Breaker Gate uses below.
        try:
            if self._registry is not None:
                _ssm = self._registry.try_resolve("system_state_manager")
                if _ssm is not None:
                    _state = _ssm.get_state() if hasattr(_ssm, "get_state") else getattr(_ssm, "state", None)
                    if _state is not None:
                        _override = getattr(_state, "human_override", None)
                        if _override in ("PAUSED", "STOPPED"):
                            log.warning(
                                f"[Trader] HUMAN OVERRIDE active: {_override} — "
                                f"skipping new-entry analysis for {self.symbol}"
                            )
                            try:
                                from core.trade_decision_log import log_decision
                                log_decision(symbol=self.symbol, signal="NO TRADE",
                                             reject_stage="human_override",
                                             reject_reason=f"Human override: {_override}")
                            except Exception:
                                pass
                            if debugger:
                                debugger.record("human_override", "BLOCK", _override)
                                debugger.record_final("NO_TRADE", f"Human override: {_override}")
                                debugger.log_cycle_summary()
                                debugger.save_to_file()
                            return {
                                "symbol": self.symbol,
                                "timeframe": self.timeframe,
                                "version": self.VERSION,
                                "final_action": "WAIT",
                                "trade_allowed": False,
                                "reject_reason": f"Human override: {_override}",
                                "human_override": _override,
                            }
        except Exception as e:
            log.debug(f"[Trader] HumanOverride state check skipped (non-fatal): {e}")

        # ── Day 84+ — Trade frequency controller (early bail if daily cap hit) ──
        # PREMORTEM FIX: Equity stop — halt all trading if equity drops
        # below 90% of balance. This prevents catastrophic drawdown.
        #
        # Day 131 fix: this previously called `mt5.account_info()` directly
        # on the raw MetaTrader5 module, bypassing the shared MT5Connection
        # entirely. That created a second, unlocked access path into the
        # single process-wide MT5 terminal session — a thread-safety hazard
        # when multiple per-symbol AITraders run concurrently — and meant
        # the account snapshot was never fed back into risk sizing. Now
        # routed through the shared connection (with its lock) when
        # available, and used to keep self.balance (risk balance) in sync
        # with the real broker account instead of the frozen boot-time
        # config value. Falls back to a direct, still-guarded raw call
        # only if no shared connection is registered.
        try:
            if MT5_AVAILABLE and self.execution_mode == "mt5_demo":
                acct = None
                mt5_conn = self._resolve_mt5_connection()
                if mt5_conn is not None and hasattr(mt5_conn, "account_info"):
                    lock = getattr(mt5_conn, "MT5_LOCK", None)
                    if lock is not None:
                        with lock:
                            acct = mt5_conn.account_info()
                    else:
                        acct = mt5_conn.account_info()
                else:
                    import MetaTrader5 as mt5
                    acct = mt5.account_info()

                if acct and acct.balance > 0:
                    equity_ratio = acct.equity / acct.balance
                    # Keep the risk-sizing balance synced to the real,
                    # authoritative broker balance (see _sync_balance()).
                    self._sync_balance(live_balance=acct.balance)

                    # 2026-07-24: log the account currency/unit once at
                    # connect time — makes Cent vs Standard visible in the
                    # logs instead of silently inferred, so a misconfigured
                    # or unexpectedly-wrong account type is caught by
                    # reading the log rather than by a mis-sized trade.
                    if not getattr(self, "_account_currency_logged", False):
                        acct_currency = getattr(acct, "currency", "?")
                        is_cent_like = str(acct_currency).upper() in ("USC", "CENT", "EURC")
                        log.info(
                            f"[Trader] MT5 account currency: {acct_currency} "
                            f"({'CENT/micro-denominated' if is_cent_like else 'standard'}) "
                            f"| balance={acct.balance} | login={getattr(acct, 'login', '?')} "
                            f"| server={getattr(acct, 'server', '?')} — "
                            f"position sizing now uses live tick-value pip pricing "
                            f"in this same unit (see get_live_pip_value_per_lot)."
                        )
                        self._account_currency_logged = True
                    if equity_ratio < 0.85:
                        # 2026-08-12 winrate audit: lowered 0.90 → 0.85.
                        # 10% equity drawdown is normal intraday fluctuation
                        # on active strategies; 0.90 was tripping frequently
                        # and blocking recovery trades.
                        log.critical(
                            f"[Trader] EQUITY STOP: equity=${acct.equity:.0f} "
                            f"< 85% of balance=${acct.balance:.0f} "
                            f"(ratio={equity_ratio:.3f}). HALTING all trading."
                        )
                        return {
                            "symbol": self.symbol,
                            "final_action": "WAIT",
                            "trade_allowed": False,
                            "reject_reason": f"EQUITY STOP: equity ratio {equity_ratio:.3f} < 0.85",
                            "error": "equity_stop_triggered",
                        }
            elif self.execution_mode != "mt5_demo":
                # Paper mode — PaperTrader is authoritative.
                self._sync_balance()
        except Exception as e:
            log.warning(f"[Trader] Equity check failed: {e}")

        try:
            from risk.trade_frequency import get_trade_frequency_controller
            freq_ctrl = get_trade_frequency_controller()
            if auto_paper_trade and not freq_ctrl.can_trade_now():
                if debugger:
                    debugger.record("frequency_ctrl", "BLOCK",
                                    f"Daily cap {freq_ctrl.trade_count_today()}/max")
                    debugger.record_final("NO_TRADE", "Daily trade cap reached")
                    debugger.log_cycle_summary()
                    debugger.save_to_file()
                log.warning("[Frequency] Daily trade cap hit — skipping cycle")
                try:
                    from core.trade_decision_log import log_decision
                    log_decision(symbol=self.symbol, signal="NO TRADE",
                                 reject_stage="frequency_cap",
                                 reject_reason="Daily trade cap reached")
                except Exception as e: pass
                return self._error_result("Daily trade cap reached")
        except Exception as e:
            freq_ctrl = None
            try:
                from core.trade_decision_log import log_cycle_error
                log_cycle_error(self.symbol, str(e), "frequency_ctrl_init")
            except Exception as e: pass

        session_ctx = SessionAnalyzer().get_current_session()
        latest_price = None

        log.info("[1/9] Market Agent...")
        with self._stage(f"aitrader.{self.symbol}.market"):
            market_out = self._data_provider.get_market_out(self.symbol, self.timeframe)
        if "error" in market_out:
            # Don't send Telegram alert for market fetch failures — they're
            # common (market closed, symbol temporarily unavailable) and
            # would spam the user. Just log locally.
            _is_unavailable = market_out.get("skipped") or "symbol_unavailable" in market_out.get("error", "")
            if _is_unavailable:
                log.debug(f"[Market] {self.symbol} skipped — not available on broker")
            else:
                log.warning(f"[Market] {self.symbol} data fetch failed — skipping this cycle")
            try:
                from core.trade_decision_log import log_decision
                log_decision(symbol=self.symbol, signal="NO TRADE",
                             reject_stage="market_data",
                             reject_reason=f"Market data fetch failed: {market_out.get('error')}")
            except Exception as e: pass
            if debugger:
                debugger.record("market_data", "ERROR", market_out.get("error", "fetch_failed"))
                debugger.record_final("NO_TRADE", "Market data fetch failed")
                debugger.log_cycle_summary()
                debugger.save_to_file()
            # Return WITHOUT "error" key for unavailable symbols — they must
            # NOT count as cycle errors for recovery pause logic.
            if _is_unavailable:
                return {
                    "symbol": self.symbol,
                    "timeframe": self.timeframe,
                    "version": self.VERSION,
                    "final_action": "NO TRADE",
                    "trade_allowed": False,
                    "skipped_unavailable": True,
                }
            return self._error_result(f"Market Agent: {market_out['error']}")

        # Record market data success
        if debugger:
            ind_ctx = market_out.get("ind_ctx", {}) or {}
            # Round-5 audit fix: Indicators.get_ai_context() uses key "price"
            # (NOT "close") — confirmed in data/indicators.py:89-90. The
            # old `ind_ctx.get('close', '?')` always returned '?' because
            # the key never exists. Now uses 'price' (the actual key),
            # falling back to 'close' for any caller that has a raw OHLCV
            # row instead of an ind_ctx.
            debugger.record("market_data", "OK",
                            f"price={ind_ctx.get('price', ind_ctx.get('close', '?'))} "
                            f"trend={ind_ctx.get('trend', '?')}")

        ind = market_out.get("ind_ctx", {})
        # Day 81+ hotfix: Indicators.get_ai_context() uses "price" key, not "close"
        latest_price = ind.get("close") or ind.get("price")

        # PREMORTEM FIX: Data quality validation — reject bad ticks.
        # If the latest price is zero/negative or NaN, skip this cycle.
        if latest_price is not None:
            try:
                price_val = float(latest_price)
                if price_val <= 0 or price_val != price_val:  # NaN check
                    log.warning(f"[Trader] BAD PRICE detected: {latest_price} — skipping cycle")
                    return {
                        "symbol": self.symbol,
                        "final_action": "WAIT",
                        "trade_allowed": False,
                        "reject_reason": f"Bad price: {latest_price}",
                    }
            except (ValueError, TypeError):
                log.warning(f"[Trader] INVALID PRICE type: {latest_price} — skipping cycle")
                return {
                    "symbol": self.symbol,
                    "final_action": "WAIT",
                    "trade_allowed": False,
                    "reject_reason": f"Invalid price: {latest_price}",
                }
        else:
            return self._error_result("No price available from market data")

        candle_time = self._extract_candle_time(market_out)
        closed_now = []

        if auto_paper_trade and latest_price:
            # Day 102+ hotfix: pass candle high/low so PaperTrader can
            # detect intra-candle SL/TP hits (matching real broker fills).
            # Previously only `close` was passed, so any TP hit during the
            # candle that finished below TP was missed — producing
            # optimistic paper P&L and corrupting ML labels.
            _candle_high = ind.get("high") or latest_price
            _candle_low = ind.get("low") or latest_price
            closed_now = self._paper.update_price(
                self.symbol, latest_price,
                high=_candle_high, low=_candle_low,
            )
        closed_processed = self._process_closed_trades(closed_now)

        # Round-22 audit fix (B1): poll PositionManager for active MT5 trade
        # management (trailing stop, breakeven, partial close, Friday close).
        # Only runs in mt5_demo/mt5_live mode — paper trades are already
        # managed by PaperTrader.update_price() above.
        if self._position_manager is not None:
            try:
                mt5_closed = self._position_manager.poll_once()
                if mt5_closed:
                    closed_processed.extend(mt5_closed)
                    log.info(
                        f"[AITrader] {self.symbol} PositionManager detected "
                        f"{len(mt5_closed)} MT5 close event(s)"
                    )
            except Exception as _pm_poll_e:
                log.debug(f"[AITrader] PositionManager poll skipped: {_pm_poll_e}")

        # [2/9] Circuit Breaker Gate — existing positions above still get
        # monitored (SL/TP/timeout) even while tripped; only NEW entries block.
        log.info("[2/9] Circuit Breaker Gate...")
        self._circuit_breaker.reset_daily()
        cb_check = self._circuit_breaker.allow_trade()
        if not cb_check["allowed"]:
            _cb_mode = cb_check["mode"]
            _cb_reason = cb_check["reason"]
            # BUG FIX: the COOLDOWN reason string embeds a live countdown
            # ("... — 97 min remaining. Resume after 11:19 UTC") that
            # ticks down roughly once a minute. Comparing the FULL string
            # for "did anything change" meant it looked "changed" on
            # almost every cycle purely because the minute count moved —
            # completely defeating the 5-minute quiet window this
            # throttle exists for (log/Telegram lines kept firing about
            # once a minute per symbol instead of once per
            # _CB_LOG_INTERVAL_SEC). Strip the volatile countdown before
            # comparing so "changed" only fires on an actual mode/reason
            # change (new trigger, mode transition), not the clock ticking.
            _cb_reason_stable = re.sub(
                r"\s*—\s*\d+\s*min remaining\.?\s*Resume after \d{2}:\d{2} UTC",
                "", _cb_reason,
            )
            _cb_changed = (
                _cb_mode != self._cb_last_logged_mode
                or _cb_reason_stable != self._cb_last_logged_reason
            )
            _cb_due = (time.time() - self._cb_last_log_ts) >= self._CB_LOG_INTERVAL_SEC
            if _cb_changed or _cb_due:
                log.warning(f"[CircuitBreaker] {_cb_mode} — {_cb_reason}")
                self._cb_last_logged_mode = _cb_mode
                self._cb_last_logged_reason = _cb_reason_stable
                self._cb_last_log_ts = time.time()
            else:
                log.debug(f"[CircuitBreaker] {_cb_mode} — {_cb_reason} (suppressed repeat)")
            if debugger:
                debugger.record("circuit_breaker", "BLOCK", f"{cb_check['mode']}: {cb_check['reason']}")
                debugger.record_final("NO_TRADE", f"CircuitBreaker: {cb_check['reason']}")
                debugger.log_cycle_summary()
                debugger.save_to_file()
            self._publish("risk.circuit_breaker", {
                "symbol": self.symbol, "mode": cb_check["mode"], "reason": cb_check["reason"],
            })
            self._publish("risk.event", {
                "kind": "circuit_breaker", "symbol": self.symbol,
                "mode": cb_check["mode"], "reason": cb_check["reason"],
            })
            result = self._monitor_only_result(
                price=latest_price,
                candle_time=candle_time,
                session_ctx=session_ctx,
                elapsed=round(time.time() - t0, 1),
                closed_trades=closed_processed,
            )
            result["reject_reason"] = f"Circuit breaker [{cb_check['mode']}]: {cb_check['reason']}"
            try:
                from core.trade_decision_log import log_decision
                log_decision(symbol=self.symbol, signal="NO TRADE",
                             reject_stage="circuit_breaker",
                             reject_reason=f"[{cb_check['mode']}] {cb_check['reason']}")
            except Exception as e: pass
            self._print_final(result)
            return result
        if debugger:
            debugger.record("circuit_breaker", "OK", "Trade allowed")

        # Day 72 fix: Removed candle dedup check that was blocking ALL pairs.
        # The old logic compared candle_time with _last_decision_candle and
        # skipped analysis if they matched. But since all pairs share the
        # same candle time (e.g. 17:30), the first pair's cycle would set
        # _last_decision_candle and ALL subsequent pairs would be skipped.
        # Now we always run the full analysis pipeline. Duplicate trade
        # prevention is handled by TradePermission + duplicate check in
        # the Safety Guard step.
        self._last_decision_candle = candle_time

        # ── Audit fix: data staleness + candle-close gates ────────────
        # core/production_hardening.py shipped check_data_staleness() and
        # is_candle_closed() specifically to catch two classic false-signal
        # sources (trading on stale ticks / trading on a still-forming
        # candle), but neither was ever called from the live pipeline.
        # Placed here — AFTER open-position monitoring (_paper.update_price
        # above) and the Circuit Breaker gate — so it follows the same
        # "existing positions still get monitored, only NEW entries block"
        # rule already documented for the Circuit Breaker Gate just above.
        # Each check is independently wrapped so a failure here can never
        # block trading; worst case it no-ops and behavior is unchanged
        # from before this fix.
        df_for_checks = market_out.get("df")
        if df_for_checks is not None and len(df_for_checks.index) > 0:
            # ── Round-3 audit fix: hoist tf_code normalization ABOVE the
            # staleness check so BOTH the staleness check and the
            # candle-close check below can use it. Previously _tf_map
            # was only computed inside the candle-close block, which
            # forced the staleness check above to use a hardcoded
            # `max_age_sec=120` (2 min) — catastrophically tight on M15
            # (candle updates every 900s) and triggered "STALE DATA"
            # on every single cycle, blocking all new-entry analysis.
            _tf_map = {
                "1M": "M1", "5M": "M5", "15M": "M15", "30M": "M30",
                "1H": "H1", "4H": "H4", "1D": "D1",
            }
            tf_code = _tf_map.get(self.timeframe.upper(), self.timeframe.upper())

            try:
                from core.production_hardening import (
                    check_data_staleness,
                    compute_staleness_threshold,
                )
                # ── Round-3 audit fix: timeframe-aware staleness threshold ──
                # Was: `max_age_sec=120` (hardcoded 2 min).
                # Now: `compute_staleness_threshold(tf_code)` returns
                # `max(tf_sec + 60s buffer, 120s floor)`:
                #   M15 → 960s  (16 min — fixes the 183s "stale" bug)
                #   H1  → 3660s (61 min)
                #   D1  → 86460s (~24h)
                # See compute_staleness_threshold() docstring for full table.
                staleness_max_age = compute_staleness_threshold(tf_code)
                staleness = check_data_staleness(df_for_checks, max_age_sec=staleness_max_age)
                if staleness.get("is_stale"):
                    log.warning(
                        f"[Trader] STALE DATA for {self.symbol}: "
                        f"{staleness.get('reason')} (threshold={staleness_max_age}s, tf={tf_code}) "
                        f"— skipping new-entry analysis"
                    )
                    try:
                        from core.trade_decision_log import log_decision
                        log_decision(symbol=self.symbol, signal="NO TRADE",
                                     reject_stage="data_staleness",
                                     reject_reason=staleness.get("reason", "Stale data"))
                    except Exception:
                        pass
                    result = self._monitor_only_result(
                        price=latest_price, candle_time=candle_time,
                        session_ctx=session_ctx, elapsed=round(time.time() - t0, 1),
                        closed_trades=closed_processed,
                    )
                    result["reject_reason"] = f"Stale data: {staleness.get('reason')}"
                    self._print_final(result)
                    return result
            except Exception as e:
                log.debug(f"[Trader] Data staleness check skipped (non-fatal): {e}")

            try:
                # ── L-1 FIX: Fast path — MarketAgent already stripped the
                # forming bar, so if forming_bar_df is present, the bar
                # is DEFINITELY still forming. Skip the expensive
                # get_last_closed_bar_time walk entirely. ──
                if market_out.get("forming_bar_df") is not None:
                    log.debug(
                        f"[Trader] {self.symbol} candle still forming "
                        f"(fast path: MarketAgent pre-stripped) — skipping"
                    )
                    try:
                        from core.trade_decision_log import log_decision
                        log_decision(symbol=self.symbol, signal="NO TRADE",
                                     reject_stage="candle_not_closed",
                                     reject_reason="Forming bar pre-stripped by MarketAgent")
                    except Exception:
                        pass
                    result = self._monitor_only_result(
                        price=latest_price, candle_time=candle_time,
                        session_ctx=session_ctx, elapsed=round(time.time() - t0, 1),
                        closed_trades=closed_processed,
                    )
                    result["reject_reason"] = "Candle not closed: forming bar pre-stripped"
                    self._print_final(result)
                    return result

                from core.production_hardening import (
                    is_candle_closed,
                    get_last_closed_bar_time,
                )
                # tf_code was already normalized above (before the
                # staleness check) so both checks share it. The
                # _tf_map block that used to live here has been
                # hoisted up so the staleness threshold could be
                # computed from the same resolved timeframe.
                #
                # ── Round-4 audit fix: use LAST CLOSED bar, not forming bar ──
                # MT5's copy_rates_from_pos returns N rows where the LAST
                # row (df.index[-1]) is the CURRENTLY-FORMING candle. Its
                # close_time is in the FUTURE, so is_candle_closed() on it
                # ALWAYS returns False — blocking all new-entry analysis
                # on every cycle, every pair.
                #
                # get_last_closed_bar_time() walks backward and returns
                # the first bar whose close_time <= now. That's the last
                # fully-closed bar — the one whose OHLCV is final and
                # safe to analyze.
                last_bar_time, _row_idx, _forming_bar = get_last_closed_bar_time(
                    df_for_checks, tf_code
                )
                if last_bar_time is None:
                    log.warning(
                        f"[Trader] {self.symbol} get_last_closed_bar_time returned "
                        f"None — skipping candle-close check (df empty?)"
                    )
                else:
                    if hasattr(last_bar_time, "to_pydatetime"):
                        last_bar_time = last_bar_time.to_pydatetime()

                    # ── P1 audit: diagnostic log of the exact timestamp ──
                    # we're about to feed into is_candle_closed(). This
                    # makes it trivial to spot the broker-tz bug: if
                    # `last_bar_time` shows a wall-clock 2-3 hours ahead
                    # of UTC `now`, the fetcher is mislabeling broker
                    # server time as UTC and the trader will block
                    # forever on "candle still forming".
                    from datetime import datetime as _dt, timezone as _tz
                    _now_utc = _dt.now(_tz.utc)
                    _bar_for_log = last_bar_time
                    if _bar_for_log.tzinfo is None:
                        _bar_for_log = _bar_for_log.replace(tzinfo=_tz.utc)
                    _delta_sec = (_now_utc - _bar_for_log).total_seconds()
                    log.info(
                        f"[Trader] {self.symbol} candle-close check | "
                        f"tf={tf_code} | "
                        f"last_closed_bar={last_bar_time.isoformat()} (row={_row_idx}) | "
                        f"forming_bar_skipped={_forming_bar.isoformat() if _forming_bar else 'None'} | "
                        f"tzinfo={'naive' if last_bar_time.tzinfo is None else str(last_bar_time.tzinfo)} | "
                        f"now_utc={_now_utc.isoformat()} | "
                        f"delta={_delta_sec:.0f}s "
                        f"({'FUTURE' if _delta_sec < 0 else 'past'})"
                    )
                    if _delta_sec < -60:
                        log.critical(
                            f"[Trader] {self.symbol} last_bar_time is "
                            f"{abs(_delta_sec):.0f}s in the FUTURE. The fetcher "
                            f"is returning broker server time mislabeled as UTC. "
                            f"Set MT5_BROKER_TZ_OFFSET_HOURS in .env to the "
                            f"broker's GMT offset (2 or 3)."
                        )

                    closed_check = is_candle_closed(tf_code, last_bar_time)
                    if not closed_check.get("is_closed", True):
                        log.info(
                            f"[Trader] {self.symbol} candle still forming "
                            f"({closed_check.get('reason')}) — skipping new-entry analysis"
                        )
                        try:
                            from core.trade_decision_log import log_decision
                            log_decision(symbol=self.symbol, signal="NO TRADE",
                                         reject_stage="candle_not_closed",
                                         reject_reason=closed_check.get("reason", "Candle forming"))
                        except Exception:
                            pass
                        result = self._monitor_only_result(
                            price=latest_price, candle_time=candle_time,
                            session_ctx=session_ctx, elapsed=round(time.time() - t0, 1),
                            closed_trades=closed_processed,
                        )
                        result["reject_reason"] = f"Candle not closed: {closed_check.get('reason')}"
                        self._print_final(result)
                        return result
            except Exception as e:
                log.debug(f"[Trader] Candle-close check skipped (non-fatal): {e}")

        # NOTE: "[3/9] Analysis Agent..." is logged inside
        # evaluate_decision_core() below — do NOT duplicate it here.
        # (Audit finding: the duplicate log line was producing two
        # identical INFO entries per cycle in trader.log.)
        _core = self.evaluate_decision_core(market_out, session_ctx, debugger)
        analysis_out = _core["analysis_out"]
        dec_out      = _core["dec_out"]
        risk_out     = _core["risk_out"]
        perm_out     = _core["perm_out"]
        memory_ctx   = _core["memory_ctx"]
        pat_ctx      = _core["pat_ctx"]
        vec_ctx      = _core["vec_ctx"]
        entry        = _core["entry"]
        if "error" in analysis_out:
            try:
                from core.trade_decision_log import log_decision
                log_decision(symbol=self.symbol, signal="NO TRADE",
                             reject_stage="analysis_agent",
                             reject_reason=f"Analysis error: {analysis_out.get('error')}")
            except Exception as e: pass
            return self._error_result(f"Analysis Agent: {analysis_out['error']}")

        log.info("[7/9] Learning Agent...")
        # ── ARCHITECTURAL FIX (institutional refactor) ───────────────
        # Previously: `dec_out["decision"] = "WAIT"` (or _final_action)
        # when permission was denied. This OVERWROTE the analysis-layer
        # verdict with the execution-layer verdict, destroying the audit
        # trail. The learning agent then "learned" from post-gate signals
        # instead of analysis signals — a fundamental data contamination.
        #
        # Now: `dec_out["decision"]` STAYS as the analysis-layer verdict
        # (BUY/SELL/WAIT — what the analysts actually said). A NEW field
        # `dec_out["execution_action"]` carries the post-gate verdict
        # (BUY/SELL/NO TRADE — what the system will actually do). The
        # learning agent, audit trail, and dashboard read BOTH fields
        # and can distinguish "analysis said X, execution did Y".
        # ──────────────────────────────────────────────────────────────
        _raw_signal = dec_out.get("decision", "WAIT")
        _final_action = perm_out.get("final_action", perm_out.get("execution_action", "WAIT"))
        dec_out["raw_signal"] = _raw_signal
        dec_out["execution_action"] = _final_action
        if _final_action in ("NO TRADE", "WAIT", None, ""):
            # DETAILED REJECTION LOGGING
            _perm_checks = perm_out.get("checks", [])
            for _chk in _perm_checks:
                if not _chk.get("passed", True):
                    log.warning(
                        f"[REJECTION] {_chk.get('check', 'Unknown')} | "
                        f"detail={_chk.get('detail', 'N/A')}"
                    )
            log.warning(
                f"[SIGNAL REJECTED] Analysis={_raw_signal} → Execution={_final_action} | "
                f"Fusion Score={dec_out.get('confidence', 0)}% | "
                f"Risk Approved={risk_out.get('approved', False)} | "
                f"R:R={risk_out.get('rr_ratio', 0)} | "
                f"Session={session_ctx.get('current_session', 'N/A') if session_ctx else 'N/A'} | "
                f"Blocked by={perm_out.get('blocked_reason', 'multiple checks')}"
            )
            # Execution is gated — but analysis verdict is PRESERVED in
            # dec_out["decision"]. Only execution_action reflects the block.
            dec_out.setdefault("gated_by_permission", True)
            dec_out.setdefault("blocked_reason", perm_out.get("blocked_reason"))
            log.info(
                f"[Learning] Signal sync: analysis={_raw_signal} → "
                f"execution={_final_action} (GATED — analysis verdict preserved)"
            )
        else:
            log.info(
                f"[Learning] Signal sync: analysis={_raw_signal} → "
                f"execution={_final_action} (ALLOWED)"
            )

        try:
            decision_id = self._learn.save_decision(dec_out, analysis_out, market_out)
        except Exception as e:
            log.warning(f"[Learning] save_decision failed: {e}")
            decision_id = None
        stats = self._learn.get_performance_stats()

        self._save_all(market_out, analysis_out, risk_out, dec_out, perm_out)

        elapsed = round(time.time() - t0, 1)
        result = self._build_result(
            market_out,
            analysis_out,
            dec_out,
            risk_out,
            perm_out,
            stats,
            elapsed,
            session_ctx=session_ctx,
            candle_time=candle_time,
            closed_trades=closed_processed,
        )

        trade_id = self._memory.on_signal_generated(result, market_out, analysis_out)
        if trade_id:
            result["trade_id"] = trade_id
            log.info(f"[Memory] Trade #{trade_id} saved")

        # Day 102+ hotfix: stash decision_id on the result so the execution
        # layer can embed it in the trade's context dict. When the trade
        # eventually closes, _process_closed_trades can use it to backfill
        # the LearningAgent JSON via update_outcome(id, ...) — instead of
        # falling back to the symbol-based search.
        if decision_id is not None:
            result["decision_id"] = decision_id

        result["memory_context"] = vec_ctx
        result["pattern_context"] = pat_ctx
        result["approval_mode"] = self._approval.mode_name

        log.info("[8/9] Approval Gate...")

        # ════════════════════════════════════════════════════════════════
        # ARCHITECTURAL FIX (Round 3 audit, 2026-08-13):
        # Previously the order was:
        #     Permission ALLOW → ApprovalMode.process() (logs "EXECUTE") → DA review → Execute
        #
        # The `approval.processed` event with `action="EXECUTE"` fired BEFORE
        # Devil's Advocate ran, making the operator think the trade was already
        # executed when DA hadn't even been consulted yet. The actual MT5 call
        # at line ~2482 WAS correctly gated by `approved_to_execute`, so no
        # unauthorized trades went through — but the LOG ORDERING was misleading
        # and contradicted the intended veto hierarchy.
        #
        # NEW ORDER (veto hierarchy enforced + log clarity):
        #     Permission ALLOW → DA review (HARD VETO) → ApprovalMode.process()
        #                                                       → Execute
        #
        # DA REJECT now:
        #   - Sets approved_to_execute = False BEFORE ApprovalMode is consulted
        #   - Skips the approval.processed log entirely (no misleading "EXECUTE")
        #   - Skips the actual execute call
        #
        # DA exception (LLM timeout / network failure):
        #   - Now FAIL-CLOSED: approved_to_execute = False
        #     (was fail-open before — execution proceeded on DA exceptions)
        # ════════════════════════════════════════════════════════════════
        approved_to_execute = False

        # ─── STEP 1: Devil's Advocate (runs FIRST, before approval gate) ──
        if auto_paper_trade and result.get("trade_allowed"):
            _da_enabled = os.getenv("DEVILS_ADVOCATE_ENABLED", "true").lower() in ("1", "true", "yes", "on")
            if not _da_enabled:
                log.debug(f"[Trader] {self.symbol}: DevilsAdvocate disabled — skipping")
                approved_to_execute = True   # DA disabled → fall through to approval gate
            else:
                _da_exception = False
                try:
                    try:
                        from execution.execution_router import _check_absolute_safety
                        _safe, _safety_reason = _check_absolute_safety(self.symbol)
                    except Exception as _e:
                        _safe, _safety_reason = True, f"safety pre-check unavailable: {_e}"

                    if not _safe:
                        result["trade_allowed"] = False
                        result["final_action"] = "NO TRADE"
                        result["execution_action"] = "NO TRADE"
                        result["reject_reason"] = f"absolute_safety: {_safety_reason}"
                        result["blocked_reason"] = result["reject_reason"]
                        result["reject_stage"] = "absolute_safety"
                        approved_to_execute = False
                        perm_out["allowed"] = False
                        perm_out["execution_allowed"] = False
                        perm_out["final_action"] = "NO TRADE"
                        perm_out["execution_action"] = "NO TRADE"
                        perm_out["blocked_reason"] = result["reject_reason"]
                        perm_out["checks"].append({
                            "check": "Absolute safety pre-check (pre Devil's Advocate)",
                            "passed": False,
                            "detail": _safety_reason,
                        })
                        perm_out["total"] = perm_out.get("total", 0) + 1
                        log.info(
                            f"[Trader] {self.symbol}: absolute_safety pre-check blocked trade "
                            f"before Devil's Advocate ({_safety_reason}) — LLM call skipped"
                        )
                    else:
                        trade_context = {
                            "symbol": self.symbol,
                            "pair": self.symbol,
                            "market_context": {
                                "timeframe": self.timeframe,
                                "session": session_ctx.get("current_session") if session_ctx else None,
                                "volatility": market_out.get("volatility") or analysis_out.get("volatility"),
                                "rr_ratio": result.get("rr"),
                                # 2026-08-13 fix: include canonical market data
                                # so DA doesn't see "unknown" for H4/SR
                                "h4_trend": analysis_out.get("mtf_structure_ctx", {}).get("h4_trend", "unknown"),
                                "h1_trend": analysis_out.get("mtf_structure_ctx", {}).get("h1_trend", market_out.get("ind_ctx", {}).get("trend", "unknown")),
                                "m15_trend": market_out.get("ind_ctx", {}).get("trend", "unknown"),
                                "regime": market_out.get("regime", {}).get("regime", "unknown"),
                                "market_direction": market_out.get("regime", {}).get("market_direction", "unknown"),
                                "sr_zone": analysis_out.get("sr_ctx", {}).get("location", "unknown"),
                                "nearest_support": analysis_out.get("sr_ctx", {}).get("nearest_support"),
                                "nearest_resistance": analysis_out.get("sr_ctx", {}).get("nearest_resistance"),
                                "smc_bias": analysis_out.get("smc_ctx", {}).get("bias", "unknown"),
                                "structure_trend": analysis_out.get("structure_ctx", {}).get("trend", "unknown"),
                                "confluence_quality": analysis_out.get("confluence", {}).get("setup_quality", "unknown"),
                                "entry": result.get("entry"),
                                "sl": result.get("sl"),
                                "tp": result.get("tp"),
                            },
                            "analysis_out": analysis_out,
                            "risk_out": risk_out,
                            "decision_out": dec_out,
                            "perm_out": perm_out,
                        }
                        review = self._devils_advocate.review(
                            trade_context=trade_context,
                            signal=result.get("final_action"),
                            risk_out=risk_out,
                            decision_out=dec_out,
                        )
                        result["devils_advocate"] = review
                        dec_out["devils_advocate"] = review
                        _da_final = "REJECT_TRADE" if review.get("decision") == "REJECT" else "TAKE_TRADE"
                        log.info(
                            f"[Trader] {self.symbol}: Devil's Advocate reviewed "
                            f"{result.get('final_action')} -> {_da_final} "
                            f"(raw={review.get('raw_decision', 'n/a')}, conf={review.get('confidence', 0):.0f}%) | "
                            f"reasoning: {review.get('risk_summary', 'n/a')} | "
                            f"concerns={review.get('reasons_for_concern', [])}"
                        )
                        if review.get("decision") == "REJECT":
                            result["trade_allowed"] = False
                            result["final_action"] = "NO TRADE"
                            result["execution_action"] = "NO TRADE"
                            result["reject_reason"] = (
                                f"Devil's Advocate reject: {review.get('risk_summary', 'high concern')}"
                            )
                            result["blocked_reason"] = result["reject_reason"]
                            result["reject_stage"] = "devils_advocate"
                            approved_to_execute = False   # ← HARD VETO
                            perm_out["allowed"] = False
                            perm_out["execution_allowed"] = False
                            perm_out["final_action"] = "NO TRADE"
                            perm_out["execution_action"] = "NO TRADE"
                            perm_out["blocked_reason"] = result["reject_reason"]
                            perm_out["checks"].append({
                                "check": "Devil's Advocate review",
                                "passed": False,
                                "detail": f"{review.get('risk_summary', 'high concern')}",
                            })
                            perm_out["total"] = perm_out.get("total", 0) + 1
                        else:
                            # DA TAKE → fall through to approval gate below
                            approved_to_execute = True
                            perm_out["checks"].append({
                                "check": "Devil's Advocate review",
                                "passed": True,
                                "detail": f"{review.get('decision')} conf={review.get('confidence', 0):.0f}%",
                            })
                            perm_out["total"] = perm_out.get("total", 0) + 1
                        try:
                            from core.execution_logger import log_devils_advocate_result
                            log_devils_advocate_result(
                                symbol=self.symbol,
                                decision=review.get("decision", "TAKE"),
                                confidence=float(review.get("confidence", 0) or 0),
                                reasons=review.get("reasons_for_concern", []),
                                risk_summary=review.get("risk_summary", ""),
                                evidence=review.get("evidence", []),
                                raw_decision=review.get("raw_decision"),
                                thesis_quality=review.get("thesis_quality"),
                                counter_evidence_strength=review.get("counter_evidence_strength"),
                                expected_edge=review.get("expected_edge"),
                                risk_level=review.get("risk_level"),
                                data_quality=review.get("data_quality"),
                                critical_failure=review.get("critical_failure"),
                                evaluation_id=getattr(self, "_current_evaluation_id", None),
                            )
                        except Exception as e:
                            log.warning(f"Suppressed exception in DA log: {e}")
                except Exception as e:
                    # FIX #2: FAIL-CLOSED on DA exceptions.
                    # Previously: exception was swallowed and execution proceeded
                    # (since `approved_to_execute` defaulted to False but the
                    # approval gate below would still run and set it to True).
                    # Now: any DA exception (LLM timeout, network error, malformed
                    # response, internal bug) BLOCKS the trade. The operator can
                    # override via DEVILS_ADVOCATE_FAIL_OPEN=true for research.
                    _da_exception = True
                    _fail_open = os.getenv("DEVILS_ADVOCATE_FAIL_OPEN", "false").lower() == "true"
                    if _fail_open:
                        log.warning(
                            f"[Trader] {self.symbol}: Devil's Advocate review raised exception "
                            f"({e}) — DEVILS_ADVOCATE_FAIL_OPEN=true, proceeding to approval gate"
                        )
                        approved_to_execute = True
                    else:
                        log.error(
                            f"[Trader] {self.symbol}: Devil's Advocate review raised exception "
                            f"({e}) — FAIL-CLOSED (set DEVILS_ADVOCATE_FAIL_OPEN=true to override)"
                        )
                        result["trade_allowed"] = False
                        result["final_action"] = "NO TRADE"
                        result["execution_action"] = "NO TRADE"
                        result["reject_reason"] = f"Devil's Advocate exception (fail-closed): {e}"
                        result["blocked_reason"] = result["reject_reason"]
                        result["reject_stage"] = "devils_advocate_exception"
                        approved_to_execute = False
                        perm_out["allowed"] = False
                        perm_out["execution_allowed"] = False
                        perm_out["final_action"] = "NO TRADE"
                        perm_out["execution_action"] = "NO TRADE"
                        perm_out["blocked_reason"] = result["reject_reason"]
                        perm_out["checks"].append({
                            "check": "Devil's Advocate review",
                            "passed": False,
                            "detail": f"EXCEPTION (fail-closed): {str(e)[:120]}",
                        })
                        perm_out["total"] = perm_out.get("total", 0) + 1

        # ─── STEP 2: Approval Gate (only runs if DA passed or was skipped) ─
        if approved_to_execute and auto_paper_trade and result.get("trade_allowed"):
            approval_out = self._approval.process(
                {
                    "symbol": self.symbol,
                    "final_action": result["final_action"],
                    "confidence": result["confidence"],
                    "entry": result["entry"],
                    "sl": result["sl"],
                    "tp": result["tp"],
                    "lot": result["lot"],
                    "rr": result["rr"],
                    "llm_analysis": result.get("llm_analysis", ""),
                }
            )
            approved_to_execute = approval_out["proceed"]

            # Day 81+ hotfix: log every approval decision to execution.log
            # NOTE: this log now fires ONLY after DA has approved. The
            # `action="EXECUTE"` string here represents the approval gate's
            # intent, not the actual broker order placement. The actual
            # execute call is at line ~2482, gated by `if approved_to_execute:`.
            try:
                from core.execution_logger import log_approval_processed
                log_approval_processed(
                    symbol=self.symbol,
                    proceed=approved_to_execute,
                    mode=approval_out.get("mode", 0),
                    action=approval_out.get("action", "unknown"),
                    final_action=result["final_action"],
                    confidence=result["confidence"],
                    devils_advocate_verdict=result.get("devils_advocate", {}).get("decision", "skipped"),
                    evaluation_id=getattr(self, "_current_evaluation_id", None),
                )
            except Exception as e:
                log.warning(f"Suppressed exception at line 943: {e}")
                pass

            if approval_out["action"] == "WAIT_APPROVAL":
                result["pending_approval_id"] = approval_out.get("pending_id")
                if self.notifier:
                    self._run_async(self.notifier.send_message(approval_out["message"]))

            if not approved_to_execute:
                result["reject_reason"] = approval_out.get("message", result.get("reject_reason"))

        log.info("[9/9] Execution + Alerts...")
        if approved_to_execute:
            with self._stage(f"aitrader.{self.symbol}.execute"):
                trade = self._execution_adapter.open_trade(
                    symbol=self.symbol,
                    direction=result["final_action"],
                    entry_price=result["entry"],
                    sl=result["sl"],
                    tp=result["tp"],
                    lot=result["lot"],
                    confidence=result["confidence"],
                    # Everything below rides through **kwargs on
                    # MT5ExecutionAdapter.open_trade() straight into the same
                    # decision_result dict ExecutionRouter.execute() always
                    # received — no field dropped by the adapter swap.
                    rr=result["rr"],
                    # Day 81+ hotfix: pass trade_allowed + risk_approved
                    # so ExecutionRouter can hard-block on permission bypass.
                    trade_allowed=result["trade_allowed"],
                    risk_approved=result.get("risk_approved", True),
                    timeframe=self.timeframe,
                    # BUGFIX: these were already computed in `result` by
                    # _build_result() (trend/rsi/regime/session — same
                    # data that lands correctly in the `analysis` table
                    # every cycle) but never forwarded here. journal_bridge
                    # .log_mt5_open() reads exactly these keys off
                    # decision_result to fill the trades table's
                    # pattern/regime/trend/rsi/session columns — without
                    # them every real MT5 trade recorded NULL for all
                    # five, permanently losing the strategy context that
                    # produced that specific trade.
                    trend=result.get("trend"),
                    rsi=result.get("rsi"),
                    regime=result.get("regime"),
                    session=result.get("session"),
                    pattern=(result.get("pattern_context") or {}).get("pattern")
                            or result.get("rule_signal"),
                    mtf_bias=result.get("mtf_bias"),
                    llm_signal=result.get("llm_signal"),
                )
            if trade:
                result["paper_trade_id"] = trade.get("id")
                # Day 96 bugfix: the ExecutionRouter returns "ticket" in its
                # response dict for every successful fill (paper, simulated,
                # or real MT5), but this value was never copied onto `result`
                # — so result.get("ticket") was always None downstream,
                # which is why trade_decisions.jsonl showed "ticket: null"
                # for every trade including ones that filled successfully.
                result["ticket"] = trade.get("ticket")
                result["paper_balance"] = self._paper.balance
                self._risk.record_trade_open(self.symbol)
                self._notify_trade_open(trade, result, dec_out)

                # Round-30: Register MT5 ticket → DB trade_id in PositionManager.
                # This was NEVER called before — PositionManager._ticket_to_db_id
                # was always empty for MT5 trades, making close detection unable
                # to find the DB trade to update.
                _mt5_ticket = trade.get("ticket")
                _db_trade_id = trade.get("id")
                if _mt5_ticket is not None and _db_trade_id is not None and self._position_manager is not None:
                    try:
                        self._position_manager.register_open(int(_mt5_ticket), int(_db_trade_id))
                    except Exception as e:
                        # P1 fix: was `except Exception: pass` — silently lost ticket→DB mapping.
                        # Now logs + writes to orphan spool for reconcile_on_startup recovery.
                        log.warning(f"[AITrader] register_open failed for ticket={_mt5_ticket}, "
                                    f"db_trade_id={_db_trade_id}: {e}")
                        try:
                            import json as _json
                            import time as _time
                            import os as _os
                            _os.makedirs(str(MEMORY_DIR), exist_ok=True)
                            with open(str(MEMORY_DIR / "orphan_trade_spool.jsonl"), "a") as _f:
                                _f.write(_json.dumps({
                                    "ticket": _mt5_ticket,
                                    "db_trade_id": _db_trade_id,
                                    "symbol": self.symbol,
                                    "reason": "register_open_failed",
                                    "error": str(e),
                                    "ts": _time.time(),
                                }) + "\n")
                        except Exception:
                            pass  # best-effort spool; do not crash the trade path
                # ── Day 37+ runtime unification ─────────────────────────
                # Publish trade.execution + signal.generated events so the
                # bus subscribers (alerts, dashboard, webhook, audit_trail)
                # all see this trade without AITrader knowing about them.
                self._publish("trade.execution", {
                    "symbol": self.symbol,
                    "decision": result["final_action"],
                    "entry": result["entry"],
                    "sl": result["sl"],
                    "tp": result["tp"],
                    "lot": result["lot"],
                    "confidence": result["confidence"],
                    "rr": result["rr"],
                    "trade_id": trade.get("id"),
                    "execution_mode": self.execution_mode,
                    "timeframe": self.timeframe,
                })
                self._publish("signal.generated", {
                    "symbol": self.symbol,
                    "signal": result["final_action"],
                    "confidence": result["confidence"],
                    "source": "aitrader",
                })
                # ── Day 67: Confluence Engine Telegram alert ──────────────
                # If a confluence decision was computed by AnalysisAgent,
                # send the rich multi-factor signal alert to Telegram.
                try:
                    confluence_ctx = analysis_out.get("confluence") if isinstance(analysis_out, dict) else None
                    if confluence_ctx and confluence_ctx.get("should_trade"):
                        from intelligence.confluence_engine import ConfluenceDecision
                        decision = ConfluenceDecision(
                            pair=confluence_ctx.get("pair", self.symbol),
                            timeframe=confluence_ctx.get("timeframe", self.timeframe),
                            direction=confluence_ctx.get("direction", result["final_action"]),
                            confidence=confluence_ctx.get("confidence", result["confidence"]),
                            setup_quality=confluence_ctx.get("setup_quality", "A"),
                            aligned_factors=confluence_ctx.get("aligned_factors", 0),
                            total_factors=confluence_ctx.get("total_factors", 0),
                            buy_score=confluence_ctx.get("buy_score", 0),
                            sell_score=confluence_ctx.get("sell_score", 0),
                            net_score=confluence_ctx.get("net_score", 0),
                            factors=confluence_ctx.get("factors", []),
                            market_story=confluence_ctx.get("market_story", ""),
                            risks=confluence_ctx.get("risks", []),
                        )
                        alert_msg = decision.to_telegram_alert()
                        if alert_msg and self.notifier:
                            self._run_async(self.notifier.send_message(alert_msg))
                except Exception as e:
                    log.debug(f"[Day 67] confluence telegram alert failed: {e}")

                if self._metrics is not None:
                    try:
                        self._metrics.inc("trades.opened")
                        self._metrics.set_gauge(f"paper.balance.{self.symbol}", self._paper.balance)
                    except Exception as e:
                        log.warning(f"Suppressed exception at line 1046: {e}")
                        pass
            else:
                # Router returned None — broker failure or rejection.
                self._publish("broker.failure", {
                    "symbol": self.symbol,
                    "reason": "execution_router returned None",
                    "decision": result["final_action"],
                })
                self._record_error("broker", f"execution returned None for {self.symbol}")

        if show_chart:
            ChartEngine(self.symbol, self.timeframe).create_full_chart(
                df=market_out["df"],
                support_zones=analysis_out["sr_result"]["support_zones"],
                resistance_zones=analysis_out["sr_result"]["resistance_zones"],
                patterns_df=market_out["df"],
                show=True,
                save_html="data/chart.html",
            )

        self._print_final(result)

        # ── Phase 7: Structured per-decision audit log ──
        # Emits a fixed-format, grep-parseable block with all individual
        # confidence components (technical, ML, RL, LLM, master, SMC,
        # session, fusion, confluence) plus bonuses, penalties, and the
        # exact reason chain.  Pure logging — never mutates state.
        try:
            from utils.decision_logger import log_decision_block
            log_decision_block(result, analysis_out)
        except Exception as e:
            log.warning(f"DecisionLogger error (non-fatal): {e}")

        # ── Day 81+ — Record final outcome in signal debugger ──
        if debugger:
            final_action = result.get("final_action") or result.get("decision", "WAIT")
            reject_reason = result.get("reject_reason", "")
            debugger.record_final(final_action, reject_reason)
            debugger.log_cycle_summary()
            debugger.save_to_file()

        # ── Day 81+ hotfix: log EVERY trade decision to memory/trade_decisions.jsonl ──
        # This is the single source of truth for "why didn't the bot trade?".
        # The operator can tail this file to see exactly what happened in
        # each cycle: signal, confidence, taken/not-taken, reject stage+reason.
        try:
            from core.trade_decision_log import log_decision as _log_dec
            _final_action = result.get("final_action") or result.get("decision", "WAIT")
            _taken = bool(result.get("paper_trade_id") or result.get("ticket"))
            # Determine reject_stage from final_action + reject_reason
            _reject_stage = ""
            _reject_reason = result.get("reject_reason") or ""
            if not _taken and _reject_reason:
                if "Circuit breaker" in _reject_reason:
                    _reject_stage = "circuit_breaker"
                elif "Correlation" in _reject_reason:
                    _reject_stage = "risk_correlation"
                elif "Daily loss" in _reject_reason or "loss limit" in _reject_reason:
                    _reject_stage = "risk_daily_loss"
                elif "Max open" in _reject_reason:
                    _reject_stage = "risk_max_open"
                elif "Insufficient margin" in _reject_reason:
                    _reject_stage = "risk_margin"
                elif "Risk rejected" in _reject_reason or "Risk approved" in str(result.get("failed_checks", "")):
                    _reject_stage = "risk_engine"
                elif "News" in _reject_reason or "news" in _reject_reason:
                    _reject_stage = "news_filter"
                elif "Session" in _reject_reason or "session" in _reject_reason:
                    _reject_stage = "session"
                elif "WAIT_APPROVAL" in str(result.get("pending_approval_id")):
                    _reject_stage = "approval_mode_2"
                elif "execution" in _reject_reason.lower() or "router" in _reject_reason.lower():
                    _reject_stage = "execution_router"
                elif "devil" in _reject_reason.lower() or "advocate" in _reject_reason.lower():
                    _reject_stage = "devils_advocate"
                elif "market closed" in _reject_reason.lower() or "Hard Stop" in _reject_reason:
                    _reject_stage = "absolute_safety"
                elif _final_action in ("WAIT", "NO TRADE"):
                    _reject_stage = "decision_agent"
                else:
                    _reject_stage = "unknown"
            _log_dec(
                symbol=self.symbol,
                signal=_final_action,
                confidence=result.get("confidence", 0),
                timeframe=self.timeframe,
                taken=_taken,
                reject_stage=_reject_stage,
                reject_reason=_reject_reason,
                lot=result.get("lot"),
                entry=result.get("entry"),
                sl=result.get("sl"),
                tp=result.get("tp"),
                ticket=result.get("ticket"),
            )
        except Exception as e:
            log.warning(f"Suppressed exception at line 1130: {e}")
            pass

        # ── Tier-3 audit fix (2026-07-22): core/audit_report.py existed but
        # had a NameError bug (missing `Dict` import) that made it crash on
        # import, so it had zero callers anywhere in the codebase. Fixed the
        # bug and wired it in here, best-effort, using whatever `result`
        # already has -- the fusion/risk breakdown fields it was designed
        # for (weights, contributors) aren't produced anywhere yet, so those
        # sections of the report render as zeros for now rather than being
        # left completely absent.
        try:
            from core.audit_report import get_audit_report
            get_audit_report().generate(
                trade_id=str(result.get("ticket") or result.get("paper_trade_id") or "-"),
                symbol=self.symbol,
                timeframe=self.timeframe,
                analysis_ctx=analysis_out if isinstance(analysis_out, dict) else {},
                fusion_result={},
                risk_result={},
                final_decision=result.get("final_action") or result.get("decision", "WAIT"),
            )
        except Exception as e:
            log.debug(f"[Trader] audit_report generation skipped: {e}")

        # ── Day 84+ — Record trade in frequency controller ──
        if freq_ctrl:
            _final_for_freq = result.get("final_action")
            if _final_for_freq in ("BUY", "SELL"):
                try:
                    freq_ctrl.record_trade(symbol=self.symbol, direction=_final_for_freq)
                except Exception as e:
                    log.warning(f"Suppressed exception at line 1140: {e}")
                    pass

        # ── Day 37+ professional: log every decision to trade journal ──
        try:
            from core.professional_tools import get_trade_journal, JournalEntry
            journal = get_trade_journal()
            cycle = journal.next_cycle()
            entry = JournalEntry(
                timestamp=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                cycle=cycle,
                symbol=self.symbol,
                timeframe=self.timeframe,
                session=result.get("session") or "UNKNOWN",
                decision=result.get("final_action", "WAIT"),
                confidence=float(result.get("confidence", 0) or 0),
                entry=result.get("entry"),
                sl=result.get("sl"),
                tp1=result.get("tp"),
                tp2=None,
                lot=float(result.get("lot", 0) or 0),
                rr_ratio=float(result.get("rr", 0) or 0),
                risk_usd=float(result.get("risk_usd", 0) or 0),
                reason=str(result.get("reject_reason") or "")[:200],
                llm_analysis=str(result.get("llm_analysis", ""))[:500],
                master_analysis=str(result.get("master_analysis", ""))[:500],
            )
            journal.log_decision(entry)
        except Exception as e:
            log.debug(f"[Journal] log_decision failed: {e}")
        return result

    def monitor_open_trades(self, price: float = None) -> list[dict]:
        if price is None:
            market_out = self._data_provider.get_market_out(self.symbol, self.timeframe)
            price = market_out.get("ind_ctx", {}).get("close")
            if price is None:
                log.warning("[PaperTrader] No price available to check open trades")
                return []
        closed_now = self._paper.update_price(self.symbol, price)
        return self._process_closed_trades(closed_now)

    def check_open_paper_trades(self, price: float = None) -> list[dict]:
        return self.monitor_open_trades(price=price)

    def close_trade(self, trade_id: int, result: str, pnl: float):
        self._memory.on_trade_closed(trade_id, result, pnl)
        self._risk.record_trade_close(self.symbol, pnl)
        self._circuit_breaker.record_result(result, pnl)
        # Day 131 fix: re-sync risk balance immediately on close instead of
        # waiting for the next cycle's equity check, so a losing/winning
        # streak is reflected in position sizing right away.
        if self.execution_mode != "mt5_demo":
            self._sync_balance()
        log.info(f"Trade #{trade_id} closed: {result} | PnL: ${pnl}")

    def get_paper_dashboard(self) -> dict:
        return self._paper.get_dashboard()

    def print_paper_dashboard(self) -> None:
        self._paper.print_dashboard()

    def get_learning_report(self):
        self._learning.print_report()

    def get_memory_stats(self):
        self._memory.print_stats()

    def _resolve_mt5_connection(self):
        """Resolve the single shared MT5Connection from the DI registry.

        Day 131 fix: prefer the registry instance actually injected into
        this AITrader (self._registry, wired by AutonomousTraderSystem /
        core.runtime). If none was injected (e.g. AITrader constructed
        standalone), fall back to the process-wide ServiceRegistry
        singleton from core.service_registry — never a separate/duplicate
        registry module. This guarantees every caller resolves the exact
        same MT5Connection instance that core.runtime.boot_market()
        registered, eliminating the "No shared MT5Connection in registry"
        false negative caused by a previously-used, unrelated registry
        implementation.
        """
        reg = self._registry
        if reg is None:
            try:
                from core.service_registry import get_registry
                reg = get_registry()
            except Exception:
                return None
        try:
            return reg.try_resolve("mt5_connection")
        except Exception:
            return None

    def _sync_balance(self, live_balance: Optional[float] = None) -> None:
        """Keep self.balance (used for risk-% position sizing) synced to a
        single authoritative source instead of the frozen boot-time value.

        Day 131 fix (Risk / Paper / Live balance synchronization):
        previously `self.balance` was set once in __init__ and never
        touched again, while `self._paper.balance` moved with every paper
        trade and the real MT5 account balance moved with every live
        trade/market swing. Risk sizing therefore silently drifted from
        the account it was supposed to be sizing against.

        Precedence:
          * mt5_demo with a fresh live account snapshot -> live balance is
            authoritative (real broker money).
          * otherwise -> the shared PaperTrader's balance is authoritative.

        Thread-safe: several per-symbol AITraders may share one PaperTrader
        and call this concurrently.
        """
        with self._balance_lock:
            if live_balance is not None and live_balance > 0:
                new_balance, source = float(live_balance), "live"
            else:
                try:
                    new_balance = float(self._paper.balance)
                    source = "paper"
                except Exception:
                    return

            old_balance = self.balance
            if old_balance and old_balance > 0:
                drift = abs(new_balance - old_balance) / old_balance
                if drift > self._balance_deviation_warn_pct:
                    log.info(
                        f"[Balance] {self.symbol} risk balance re-synced "
                        f"${old_balance:,.2f} -> ${new_balance:,.2f} "
                        f"(source={source}, drift={drift:.1%})"
                    )
            self.balance = new_balance
            self._balance_source = source

    def _get_live_open_pairs(self) -> list:
        """
        Day 96 bugfix + Day 102 hardening: use shared MT5Connection
        instead of raw mt5.initialize()/shutdown() which killed the
        shared session and caused positions_get() to return None.

        Audit fix (correlation blind-spot): in mt5_demo mode, this used to
        silently fall back to PaperTrader.get_open_positions() whenever the
        shared MT5 connection was unavailable or positions_get() failed —
        and PaperTrader is empty when the bot actually trades through MT5,
        not paper. The correlation filter would then see "no open
        positions" and happily open correlated pairs (e.g. EURUSD +
        GBPUSD + AUDUSD together) while MT5 in fact already held exposure.

        This method now sets `self._mt5_sync_ok` to reflect whether the
        returned list is actually authoritative. Callers in mt5_demo mode
        must treat `_mt5_sync_ok is False` as "unknown open positions" —
        i.e. fail CLOSED on new entries — rather than "zero positions".
        """
        # Assume healthy until proven otherwise below; only meaningful in
        # mt5_demo mode (paper/backtest modes are never "degraded").
        self._mt5_sync_ok = True
        try:
            _sim_mode = bool(getattr(self._router, "_simulation_mode", False))
            if self.execution_mode == "mt5_demo" and not _sim_mode:
                from core.constants import MT5_MAGIC_NUMBER

                # Use the shared MT5Connection (registered in Phase 4 boot)
                # instead of calling mt5.initialize()/shutdown() directly.
                # Day 131 fix: this used to import a stale duplicate
                # `utils.registry.ServiceRegistry` and call try_resolve()
                # as an unbound class method — a different, unpopulated
                # registry than the one core.runtime actually wires
                # (core.service_registry). That always returned None,
                # which is the real root cause of the persistent
                # "No shared MT5Connection in registry" message even
                # when MT5 was connected and healthy. See
                # _resolve_mt5_connection() for the corrected lookup.
                mt5_conn = self._resolve_mt5_connection()

                if mt5_conn is not None:
                    # Shared connection available — use it
                    positions = mt5_conn.positions_get()
                    if positions is not None:
                        return [
                            p.symbol for p in positions
                            if getattr(p, "magic", MT5_MAGIC_NUMBER) == MT5_MAGIC_NUMBER
                        ]
                    # Shared connection returned None — this is a real issue.
                    # BUGFIX (log audit): throttle the warning to at most
                    # once per 5 minutes — `_mt5_sync_ok=False` is set
                    # every cycle (fail-closed behavior unchanged), but
                    # the warning was producing one log line per cycle.
                    self._mt5_sync_ok = False
                    _now = time.time()
                    if _now - getattr(self, "_mt5_none_warn_last_ts", 0.0) > 300:
                        log.warning(
                            "[Risk] Shared MT5Connection.positions_get() returned None "
                            "(MT5 terminal may not be running or account issue) — "
                            "open positions unknown, failing closed for correlation "
                            "(warning throttled to once per 5min; _mt5_sync_ok stays False)"
                        )
                        self._mt5_none_warn_last_ts = _now
                else:
                    # No shared connection — cannot verify live exposure.
                    self._mt5_sync_ok = False
                    if not getattr(self, '_mt5_unavailable_warned', False):
                        log.warning(
                            "[Risk] No shared MT5Connection in registry while in "
                            "mt5_demo mode — open positions unknown, correlation "
                            "check will fail closed until sync is restored"
                        )
                        self._mt5_unavailable_warned = True
        except ImportError:
            # MetaTrader5 package not installed — this only happens when
            # execution_mode isn't actually mt5_demo (e.g. Linux paper/dev
            # runs), so PaperTrader genuinely is authoritative here.
            if not getattr(self, '_mt5_unavailable_warned', False):
                log.info("[Risk] MetaTrader5 package not installed (Linux?) — "
                         "PaperTrader is the authoritative position source")
                self._mt5_unavailable_warned = True
        except Exception as e:
            log.warning(f"[Risk] Position detection failed: {e} — "
                        f"open positions unknown, failing closed for correlation")
            self._mt5_sync_ok = False

        # PaperTrader is the fallback source. In mt5_demo mode with a
        # degraded sync, this list is NOT authoritative — it's returned
        # only as a best-effort value for logging/UI; run_cycle() checks
        # `self._mt5_sync_ok` separately and fails closed on new entries
        # rather than trusting an empty list here as "no open positions".
        try:
            return [t.get("pair") for t in self._paper.get_open_positions() if t.get("pair")]
        except Exception as e:
            log.warning(
                f"[Risk] PaperTrader.get_open_positions() raised: {e} — "
                f"returning empty open-pairs list"
            )
            self._mt5_sync_ok = self._mt5_sync_ok and (self.execution_mode != "mt5_demo")
            return []

    def sync_risk_with_open_positions(self) -> None:
        open_pairs = self._get_live_open_pairs()
        self._risk.sync_open_positions(open_pairs)

    def _get_live_open_positions_detailed(self) -> list[dict]:
        """Audit fix (EX-2 / X-2): PositionSizer's correlation/portfolio-heat
        check (_apply_advanced_sizing) used to call self._paper.get_open_positions()
        directly — in mt5_demo mode that source is not authoritative (the bot
        trades through MT5, not PaperTrader), so the sizer would see "no open
        positions" even while MT5 held real correlated exposure, and would
        happily approve stacking more risk on top of it.

        This mirrors `_get_live_open_pairs()`'s authoritative-source logic but
        returns the richer {pair, direction, risk_usd} shape the sizer needs,
        keeping both call sites in sync on the same fail-closed semantics.

        Fail-closed contract: in mt5_demo mode, if MT5 positions can't be
        read, this returns an empty list AND leaves `self._mt5_sync_ok=False`
        (set by `_get_live_open_pairs()`, called first below) so callers that
        check that flag correctly treat "empty" as "unknown", not "flat".
        """
        # Piggyback on _get_live_open_pairs() for the authoritative-source
        # decision + self._mt5_sync_ok bookkeeping — avoids duplicating that
        # (already-hardened) fallback logic here.
        pairs_only = self._get_live_open_pairs()

        _sim_mode = bool(getattr(self._router, "_simulation_mode", False))
        if self.execution_mode == "mt5_demo" and not _sim_mode and self._mt5_sync_ok:
            try:
                from core.constants import MT5_MAGIC_NUMBER, get_pip_value_usd
                mt5_conn = self._resolve_mt5_connection()
                positions = mt5_conn.positions_get() if mt5_conn is not None else None
                if positions is not None:
                    detailed = []
                    for p in positions:
                        if getattr(p, "magic", MT5_MAGIC_NUMBER) != MT5_MAGIC_NUMBER:
                            continue
                        direction = "BUY" if getattr(p, "type", 0) == 0 else "SELL"
                        risk_usd = 0.0
                        try:
                            sl = float(getattr(p, "sl", 0) or 0)
                            entry = float(getattr(p, "price_open", 0) or 0)
                            volume = float(getattr(p, "volume", 0) or 0)
                            if sl and entry and volume:
                                import MetaTrader5 as mt5
                                info = mt5.symbol_info(p.symbol)
                                if info:
                                    pip_size = info.point * (10 if info.digits in (3, 5) else 1)
                                    pips = abs(entry - sl) / pip_size if pip_size else 0.0
                                    # 2026-07-24: compute pip value live from the same
                                    # `info` object (tick_value/tick_size), in the
                                    # account's own currency/unit — see
                                    # get_live_pip_value_per_lot() for why the static
                                    # USD table is wrong on Cent accounts.
                                    tick_value = float(getattr(info, "trade_tick_value", 0) or 0)
                                    tick_size = float(getattr(info, "trade_tick_size", 0) or 0)
                                    if tick_value > 0 and tick_size > 0:
                                        pip_value = tick_value * (pip_size / tick_size)
                                    else:
                                        pip_value = get_pip_value_usd(p.symbol)
                                        log.warning(
                                            f"[Sizing] {p.symbol}: symbol_info missing "
                                            f"tick_value/tick_size — falling back to "
                                            f"static USD pip value (wrong on Cent accounts)"
                                        )
                                    risk_usd = round(pips * pip_value * volume, 2)
                        except Exception as e:
                            log.warning(f"[Sizing] risk_usd estimate failed for {p.symbol}: {e}")
                        detailed.append({
                            "pair": p.symbol,
                            "direction": direction,
                            "risk_usd": risk_usd,
                        })
                    return detailed
            except Exception as e:
                log.warning(f"[Sizing] MT5 detailed-position read failed: {e} — "
                            f"falling back to pair-only list with risk_usd=0")

            # MT5 detailed read failed after pairs_only already succeeded —
            # degrade gracefully to pair-only info rather than losing the
            # correlation signal entirely.
            return [{"pair": pair, "direction": "", "risk_usd": 0.0} for pair in pairs_only]

        if self.execution_mode == "mt5_demo" and not _sim_mode and not self._mt5_sync_ok:
            # Fail closed: unknown exposure must not be treated as "none".
            # Returning [] here means the sizer's correlation/heat check
            # sees nothing — callers that need the stronger guarantee
            # should also check self._mt5_sync_ok directly, same as
            # _get_live_open_pairs() callers do.
            return []

        # Paper/backtest modes — PaperTrader is authoritative.
        try:
            return [
                {
                    "pair": pos.get("pair", ""),
                    "direction": pos.get("signal") or pos.get("direction", ""),
                    "risk_usd": float(pos.get("risk_usd", 0) or 0),
                }
                for pos in self._paper.get_open_positions()
            ]
        except Exception as e:
            log.warning(f"[Sizing] PaperTrader.get_open_positions() raised: {e}")
            return []

    def _on_mt5_position_closed(self, symbol: str, result: str, pnl: float) -> None:
        """Round-22 audit fix (B1): callback for PositionManager close events.

        Called by broker/position_manager.py when it detects an MT5 position
        has been closed (SL/TP hit by broker, or scheduled exit like Friday
        close). This callback feeds the close into the same processing
        pipeline as paper-trade closes — circuit breaker, risk engine,
        trade memory, etc.
        """
        try:
            log.info(
                f"[AITrader] {symbol} MT5 position closed: {result} | PnL: ${pnl:.2f}"
            )
            # Feed into circuit breaker + risk engine for state updates
            self._risk.record_trade_close(symbol, pnl)
            self._circuit_breaker.record_result(result, pnl)
            # Sync balance after MT5 close
            if hasattr(self, '_sync_balance'):
                self._sync_balance()
        except Exception as e:
            log.warning(f"[AITrader] _on_mt5_position_closed error: {e}")

    def _process_closed_trades(self, closed_now: list[dict]) -> list[dict]:
        processed = []
        for trade in closed_now:
            context = trade.get("context") or {}
            memory_trade_id = context.get("memory_trade_id")
            rr_ratio = context.get("rr_ratio") or trade.get("rr_ratio", 0)
            trade["rr_ratio"] = rr_ratio

            self._risk.record_trade_close(trade["pair"], trade["pnl"])
            self._circuit_breaker.record_result(trade["result"], trade["pnl"])

            # ── Audit fix (Phase 9 wiring): CostTracker.record_trade(). ──
            # monitoring/cost_analysis.py::CostTracker is registered as the
            # "cost_tracker" service in core/_orphan_integration.py:984, but
            # its record_trade() method had ZERO callers anywhere in the
            # codebase — meaning the entire cost-analysis DB
            # (database/cost_analysis.db) was always empty and "hidden
            # trading costs" (spread, commission, swap, slippage) were
            # silently never collected. Wire it here, right after
            # _risk.record_trade_close(), so every closed paper/MT5 trade
            # gets logged with whatever cost components are available.
            # try/except isolation: a cost-log failure must NEVER block the
            # close-handling chain (memory sync, learning, alerts all depend
            # on this loop continuing).
            try:
                if self._registry is not None:
                    _ct = self._registry.try_resolve("cost_tracker")
                    if _ct is not None and hasattr(_ct, "record_trade"):
                        _ctx = context or {}
                        _ct.record_trade(
                            symbol=trade.get("pair", self.symbol),
                            direction=(trade.get("type") or _ctx.get("decision") or "").upper(),
                            lot=float(trade.get("lot", 0.0) or 0.0),
                            entry_spread_pips=float(_ctx.get("entry_spread_pips", 0.0) or 0.0),
                            commission_usd=float(_ctx.get("commission_usd", 0.0) or 0.0),
                            swap_usd=float(_ctx.get("swap_usd", 0.0) or 0.0),
                            slippage_cost_pips=float(_ctx.get("slippage_pips_at_open", 0.0) or 0.0),
                            gross_pnl_usd=float(trade.get("pnl", 0.0) or 0.0),
                            holding_hours=float(_ctx.get("holding_hours", 0.0) or 0.0),
                            ticket=_ctx.get("ticket") or trade.get("ticket"),
                        )
            except Exception as _ct_e:
                log.debug(f"[CostTracker] record_trade failed (non-fatal): {_ct_e}")

            # Audit fix: risk/compounding.py's CompoundingEngine.record_profit()
            # was fully implemented (balance tracking + lot-multiplier growth)
            # but had zero callers anywhere in the codebase — its persisted
            # state file was never written to, so risk/position_sizer.py's
            # opt-in `use_compounding` multiplier would always read a
            # balance == initial_balance (multiplier stuck at 1.0) even on
            # an account that had genuinely grown. Record every closed
            # trade's PnL here so the multiplier reflects real history.
            # Non-fatal: a failure here must never block the close chain.
            try:
                from risk.compounding import get_compounding_engine as _get_comp_engine
                _comp = _get_comp_engine()
                _comp.record_profit(
                    trade_pnl=float(trade.get("pnl", 0.0) or 0.0),
                    pair=trade.get("pair", self.symbol),
                )
            except Exception as _comp_e:
                log.debug(f"[Compounding] record_profit failed (non-fatal): {_comp_e}")

            # Audit fix: core/confidence_manager.py's record_outcome() was
            # fully implemented but never called anywhere, so layer weights
            # never adjusted from real trade results. We wire a minimal,
            # correctly-derived signal here: for a directional trade, a WIN
            # means the predicted direction was right, a LOSS means the
            # opposite direction would have been right. This only records
            # the "decision_agent" layer (the one signal this codebase
            # actually tracks per-trade); true per-layer (rule/ml/rl/llm)
            # attribution needs those individual predictions persisted on
            # trade open, which is a larger change left for the
            # MasterDecisionEngine integration.
            try:
                predicted_signal = (context.get("decision") or trade.get("type") or "").upper()
                trade_result = trade.get("result")
                if predicted_signal in ("BUY", "SELL") and trade_result in ("WIN", "LOSS"):
                    actual_direction = predicted_signal if trade_result == "WIN" else (
                        "SELL" if predicted_signal == "BUY" else "BUY"
                    )
                    from core.confidence_manager import get_confidence_manager
                    get_confidence_manager().record_outcome(
                        "decision_agent", predicted_signal, actual_direction
                    )
            except Exception as e:
                log.debug(f"[ConfidenceManager] record_outcome failed: {e}")

            # ── Day 102+ hotfix: memory DB sync fallback ─────────────
            # Previously, if memory_trade_id was missing (context dict
            # lost on restart, MT5 position closed externally, etc.),
            # we'd skip the memory DB update entirely — leaving the
            # trade's `result` column stuck at 'OPEN' forever. This
            # silently broke win-rate stats and made every trade look
            # like the bot's "first ever" trade (no learning).
            #
            # Now: if memory_trade_id is missing, do a fallback lookup
            # by pair symbol in the trades table. If we find an OPEN
            # trade for that pair, close it with the result/pnl we
            # just got from the broker.
            if memory_trade_id:
                try:
                    self._memory.on_trade_closed(memory_trade_id, trade["result"], trade["pnl"])
                    if self._mistake_analyzer:
                        self._mistake_analyzer.analyze_closed_trade(memory_trade_id)
                except Exception as e:
                    log.warning(f"[Learning] Close sync failed for memory trade #{memory_trade_id}: {e}")
                # Day 102+ hotfix: also backfill the JSON-side LearningAgent
                # so get_performance_stats() sees the closed trade and the
                # "Memory: X decisions | WR: Y%" log line reflects reality.
                try:
                    decision_id = context.get("decision_id")
                    if decision_id is not None:
                        self._learn.update_outcome(decision_id, trade["result"], trade.get("pnl_pips", 0.0))
                    else:
                        # No decision_id stashed — use symbol-based fallback
                        self._learn.update_outcome_by_symbol(
                            trade["pair"], trade["result"], trade.get("pnl_pips", 0.0)
                        )
                except Exception as e:
                    log.debug(f"[Learning] LearningAgent outcome backfill failed: {e}")
            else:
                # Fallback: try to find an orphaned OPEN trade by pair
                try:
                    orphan_id = self._memory.db.close_orphaned_open_trade(
                        trade["pair"], trade["result"], trade["pnl"]
                    )
                    if orphan_id is not None:
                        log.warning(
                            f"[Learning] Synced orphaned trade #{orphan_id} "
                            f"({trade['pair']}) via fallback — memory_trade_id was missing"
                        )
                        memory_trade_id = orphan_id  # so downstream events carry it
                        # Mistake analysis still possible on the recovered id
                        if self._mistake_analyzer:
                            try:
                                self._mistake_analyzer.analyze_closed_trade(orphan_id)
                            except Exception as e:
                                log.debug(f"[Learning] Mistake analysis on orphan #{orphan_id} failed: {e}")
                    else:
                        log.warning(
                            f"[Learning] No OPEN trade found in memory for {trade['pair']} — "
                            f"close event dropped (result={trade['result']}, pnl=${trade['pnl']:.2f})"
                        )
                except Exception as e:
                    log.warning(
                        f"[Learning] Orphan-close fallback failed for {trade['pair']}: {e}"
                    )
                # Day 102+ hotfix: also backfill JSON-side LearningAgent
                # via symbol-based fallback (we never had a decision_id).
                try:
                    self._learn.update_outcome_by_symbol(
                        trade["pair"], trade["result"], trade.get("pnl_pips", 0.0)
                    )
                except Exception as e:
                    log.debug(f"[Learning] LearningAgent symbol-fallback backfill failed: {e}")

            self._notify_trade_close(trade)
            # ── Day 102+ hotfix: backfill the OTHER close handlers ─────
            # Three persistence layers had "open without close" bugs
            # identical to the trade_memory.json result=null issue we
            # already fixed. Their close methods existed but were never
            # called from production code:
            #   1. TradeJournal.log_close  (core/professional_tools.py:301)
            #   2. AnalysisHistory.update_result  (memory/history.py:62)
            # Without these calls, journal.csv close columns stayed blank
            # and analysis_history.json entries stayed result=null forever
            # — same silent gap pattern.
            try:
                from core.professional_tools import get_trade_journal
                journal = get_trade_journal()
                journal.log_close(
                    symbol=trade.get("pair", "?"),
                    cycle=int(context.get("cycle", 0)),
                    close_price=float(trade.get("exit_price", trade.get("close_price", 0)) or 0),
                    result=trade.get("result", "UNKNOWN"),
                    pnl_usd=float(trade.get("pnl", 0) or 0),
                    pnl_pips=float(trade.get("pnl_pips", 0) or 0),
                    lesson=trade.get("lesson", ""),
                )
            except Exception as e:
                log.debug(f"[Journal] log_close failed: {e}")

            try:
                # AnalysisHistory is indexed by append position, not by
                # trade_id. We use the decision_id stashed at open time
                # (minus 1 because update_result takes a 0-indexed position
                # while decision_id is 1-indexed).
                decision_id = context.get("decision_id")
                if decision_id is not None and decision_id > 0:
                    AnalysisHistory().update_result(
                        index=decision_id - 1,
                        result=trade.get("result", "UNKNOWN").lower(),
                        pnl=float(trade.get("pnl", 0) or 0),
                    )
            except Exception as e:
                log.debug(f"[History] update_result failed: {e}")

            # ── Day 37+ runtime unification ─────────────────────────
            # Publish trade.close + learning.feedback so bus subscribers
            # (analytics, dashboard, audit_trail, learning) all see the
            # closed trade without AITrader knowing about them.
            self._publish("trade.close", {
                "symbol": trade.get("pair"),
                "result": trade.get("result"),
                "pnl": trade.get("pnl"),
                "rr_ratio": rr_ratio,
                "trade_id": memory_trade_id,
            })
            self._publish("learning.feedback", {
                "symbol": trade.get("pair"),
                "result": trade.get("result"),
                "pnl": trade.get("pnl"),
                "rr_ratio": rr_ratio,
                "memory_trade_id": memory_trade_id,
            })
            if self._metrics is not None:
                try:
                    self._metrics.inc("trades.closed")
                    if trade.get("result") == "WIN":
                        self._metrics.inc("trades.wins")
                    elif trade.get("result") == "LOSS":
                        self._metrics.inc("trades.losses")
                except Exception as e:
                    log.warning(f"Suppressed exception at line 1297: {e}")
                    pass
            processed.append(trade)

        return processed

    def _monitor_only_result(
        self,
        price: float,
        candle_time: str | None,
        session_ctx: dict,
        elapsed: float,
        closed_trades: list[dict],
    ) -> dict:
        return {
            "symbol": self.symbol,
            "timeframe": self.timeframe,
            "version": self.VERSION,
            "elapsed_sec": elapsed,
            "price": price,
            "trend": None,
            "rsi": None,
            "regime": None,
            "volatility": None,
            "mtf_bias": None,
            "rule_signal": None,
            "rule_conf": 0,
            "llm_signal": None,
            "llm_conf": 0,
            "llm_analysis": "",
            "llm_risk": "",
            "news_safe": True,
            "news_reason": "",
            "decision": "WAIT",
            "confidence": 0,
            "trade_allowed": False,
            "final_action": "WAIT",
            "entry": None,
            "sl": None,
            "tp": None,
            "sl_pips": 0,
            "tp_pips": 0,
            "lot": 0,
            "rr": 0,
            "risk_usd": 0,
            "reject_reason": "One decision already taken for this candle",
            "total_decisions": 0,
            "win_rate": "N/A",
            "session": self._format_session_label(session_ctx),
            "decision_candle": candle_time,
            "closed_trades": closed_trades,
            "monitor_only": True,
            "approval_mode": self._approval.mode_name,
        }

    @staticmethod
    def _rl_conf_100(rl_ctx: dict) -> float:
        """Convert RL confidence from 0-1 scale to 0-100 scale."""
        try:
            v = float(rl_ctx.get("confidence", 0) or 0)
            return min(99.0, v * 100) if v <= 1.0 else v
        except (TypeError, ValueError):
            return 0.0

    def _build_result(
        self,
        market_out,
        analysis_out,
        dec_out,
        risk_out,
        perm_out,
        stats,
        elapsed,
        session_ctx: dict | None = None,
        candle_time: str | None = None,
        closed_trades: list[dict] | None = None,
    ):
        ind = market_out["ind_ctx"]
        regime = market_out["regime"]
        signal = analysis_out.get("signal", {})
        llm = analysis_out.get("llm", {})
        news = analysis_out.get("news", {})
        
        # Day 81+ fix: extract fallback price from ind_ctx to ensure entry is never None
        fallback_price = ind.get("close") or ind.get("price") or 0

        # Co-founder fix: Price fallback chain so it's never None in report
        _price = (
            ind.get("close") or ind.get("price")
            or dec_out.get("entry") or risk_out.get("entry") or perm_out.get("entry")
        )
        if _price is None:
            try:
                _df = market_out.get("df")
                if _df is not None and len(_df) > 0 and "close" in _df.columns:
                    _price = float(_df["close"].iloc[-1])
            except Exception:
                pass
        if _price is None:
            _price = 0

        return {
            "symbol": self.symbol,
            "timeframe": self.timeframe,
            "version": self.VERSION,
            "elapsed_sec": elapsed,
            "price": _price,
            "trend": ind.get("trend"),
            "rsi": ind.get("rsi"),
            "regime": regime.get("regime"),
            "volatility": regime.get("volatility"),
            "mtf_bias": market_out.get("mtf_bias"),
            "rule_signal": signal.get("signal"),
            "rule_conf": signal.get("confidence"),
            "llm_signal": llm.get("signal"),
            "llm_conf": llm.get("confidence"),
            "llm_analysis": llm.get("analysis", ""),
            "llm_risk": llm.get("key_risk", ""),
            "news_safe": news.get("trade_allowed", True),
            "news_reason": news.get("reason", ""),
            # ARCHITECTURAL FIX: `decision` is the ANALYSIS verdict
            # (BUY/SELL/WAIT — what the analysts said). `final_action` /
            # `execution_action` is the EXECUTION verdict (what the system
            # will actually do, after gates). Both are reported so the
            # operator can distinguish "analysis said X, execution did Y".
            "decision":           dec_out.get("decision"),
            # BUG FIX (2026-08-05): this was `dec_out.get("decision")` — the
            # SAME field the signal_scorer downgrade overwrites to "WAIT" in
            # place (core/orphan_consumers.py apply_signal_scoring()). So
            # "analysis_signal" was never actually a distinct pre-gate
            # snapshot despite the comment above claiming it separates
            # analysis from execution; it just aliased the post-downgrade
            # value. Now prefers the pre_gate_decision/pre_gate_confidence
            # that apply_signal_scoring() records BEFORE downgrading, so the
            # final report shows what was really analyzed (e.g. "SELL 95%")
            # even when execution was blocked and dec_out["decision"] became
            # "WAIT".
            "analysis_signal":    dec_out.get("pre_gate_decision") or dec_out.get("decision"),
            "execution_action":   dec_out.get("execution_action") or perm_out.get("final_action"),
            # 2026-08-13 fix: use post-penalty confidence (not pre_gate).
            # Previously used pre_gate_confidence (60%) which bypassed
            # entry_quality penalties. Now uses the final confidence that
            # TradePermission saw (50% after penalty).
            "confidence":         perm_out.get("confidence_post_penalty") or dec_out.get("confidence", 0),
            "trade_allowed":      perm_out["allowed"],
            "final_action":       perm_out["final_action"],
            "blocked_reason":     perm_out.get("blocked_reason"),
            "execution_filters":  analysis_out.get("execution_filters", {}),
            # Day 81+ hotfix: ensure entry is never None/0 — use dec_out's entry
            # (which has the ind_ctx fallback) if risk_out lost it
            "entry": risk_out.get("entry") or dec_out.get("entry") or fallback_price,
            "sl": risk_out.get("sl_price"),
            "tp": risk_out.get("tp_price"),
            "sl_pips": risk_out.get("sl_pips", 0),
            "tp_pips": risk_out.get("tp_pips", 0),
            "lot": risk_out.get("lot", 0),
            "rr": risk_out.get("rr_ratio", 0),
            "risk_usd": risk_out.get("risk_usd", 0),
            "reject_reason": risk_out.get("reject_reason")
            or (
                None
                if perm_out["allowed"]
                else next((c["detail"] for c in perm_out["checks"] if not c["passed"]), None)
            ),
            "total_decisions": stats.get("closed_trades", stats.get("total_decisions", 0)),
            "total_history":   stats.get("total_decisions", 0),
            "win_rate": stats.get("win_rate", "N/A"),
            "session": self._format_session_label(session_ctx),
            "decision_candle": candle_time,
            "closed_trades": closed_trades or [],
            # Day 76 — full sizer breakdown for journal/telegram/dashboard.
            "position_sizing": risk_out.get("position_sizing"),

            # ── Phase 6: Individual confidence source visibility ──
            # Previously _build_result() was the bottleneck that collapsed
            # all 10 confidence sources into 3 keys (rule_conf, llm_conf,
            # confidence).  Now each source is individually accessible in
            # the report dict so main.py, dashboards, and diagnostics can
            # see exactly what each module contributed.
            "master_confidence": (analysis_out.get("master_ctx") or {}).get("master_confidence", 0),
            "master_signal": (analysis_out.get("master_ctx") or {}).get("master_signal", "WAIT"),
            "ml_confidence": (analysis_out.get("ensemble") or {}).get("confidence", 0),
            "ml_available": (analysis_out.get("ensemble") or {}).get("ml_available", True),
            "rl_confidence": self._rl_conf_100(analysis_out.get("rl_agent") or {}),
            "smc_score": (analysis_out.get("smc_ctx") or {}).get("smc_score", 0),
            "smc_grade": (analysis_out.get("smc_ctx") or {}).get("smc_grade", "N/A"),
            "session_score": (analysis_out.get("session_ctx") or {}).get("session_score", 0),
            "session_confidence": (analysis_out.get("session_ctx") or {}).get("session_confidence", 0),
            "session_grade": (analysis_out.get("session_ctx") or {}).get("session_grade", "N/A"),
            "confluence_confidence": (analysis_out.get("confluence") or {}).get("confidence", 0),
            "confluence_quality": (analysis_out.get("confluence") or {}).get("setup_quality", "UNKNOWN"),
            "fusion_confidence": dec_out.get("_fusion_conf", 0),
            "per_source_confidence": dec_out.get("per_source_confidence", {}),
            # Raw aggregate confidence before voting adjustments (from decision_agent)
            "raw_confidence": (dec_out.get("per_source_confidence") or {}).get("aggregate_raw", dec_out.get("confidence", 0)),
            # Phase 7: confidence trace (full before/after audit trail)
            "confidence_trace": dec_out.get("confidence_trace", []),
            # Reasons list for the decision block logger
            "reasons": dec_out.get("reasons", []),
            # Pattern (from decision_agent extraction)
            "pattern": dec_out.get("pattern"),
        }

    def _print_final(self, r: dict) -> None:
        # 2026-08-13: professional concise log — one-line summary + details only when needed
        icons = {"BUY": "BUY ", "SELL": "SELL", "WAIT": "WAIT", "NO TRADE": "SKIP"}
        icon = icons.get(r["final_action"], "SKIP")

        # One-line summary (always shown)
        _sym = r.get("symbol", "?")
        _action = icon
        _price = r.get("price", "?")
        _session = r.get("session", "?")
        _trend = r.get("trend", "?")
        _rule_sig = r.get("rule_signal", "?")
        _rule_conf = r.get("rule_conf", 0)
        _elapsed = r.get("elapsed_sec", 0)

        # Compact summary line
        if r.get("trade_allowed") and r.get("paper_trade_id"):
            _entry = r.get("entry", "?")
            _sl = r.get("sl", "?")
            _tp = r.get("tp", "?")
            _lot = r.get("lot", 0)
            _rr = r.get("rr", 0)
            log.info(
                f"[TRADE] {_sym} {_action} | price={_price} | entry={_entry} | "
                f"SL={_sl} | TP={_tp} | lot={_lot} | RR=1:{_rr} | "
                f"session={_session} | trend={_trend} | {_elapsed}s"
            )
        elif r.get("monitor_only"):
            _reason = r.get("reject_reason", "monitor only")
            log.info(f"[SKIP]  {_sym} {_action} | price={_price} | reason={_reason} | {_elapsed}s")
        else:
            _blocked = r.get("blocked_reason") or r.get("reject_reason") or "gated"
            _analysis_sig = r.get("analysis_signal") or r.get("decision", "WAIT")
            _conf = r.get("confidence", 0)
            log.info(
                f"[SKIP]  {_sym} {_action} | price={_price} | "
                f"analysis={_analysis_sig}({_conf}%) | "
                f"blocked={_blocked} | session={_session} | {_elapsed}s"
            )

        # Trade entry details (only when trade executed)
        if r.get("paper_trade_id") and r.get("trade_allowed"):
            ps = r.get("position_sizing")
            if ps and ps.get("approved"):
                log.info(
                    f"        sizer: base={ps.get('base_lot', 0):.2f} → "
                    f"final={ps.get('lot', 0):.2f} (×{ps.get('final_mult', 0):.3f})"
                )
            if r.get("trade_id"):
                log.info(f"        trade_id=#{r['trade_id']} paper=#{r['paper_trade_id']}")
            if r.get("risk_usd"):
                log.info(f"        risk=${r['risk_usd']} | paper_balance=${r.get('paper_balance')}")

        # Closed trades (only when something closed)
        if r.get("closed_trades"):
            log.info(f"        closed: {len(r['closed_trades'])} trade(s) updated")

        # Memory summary (always — but one line)
        _closed = r.get("total_decisions", 0)
        _wr = r.get("win_rate", "N/A")
        log.info(f"        memory: {_closed} closed | WR: {_wr}%")

    def _save_all(self, market_out, analysis_out, risk_out, dec_out, perm_out):
        try:
            ind_ctx = market_out["ind_ctx"]
            combined = {
                **ind_ctx,
                **market_out.get("regime_ctx", {}),
                **analysis_out.get("pat_ctx", {}),
                **analysis_out.get("sr_ctx", {}),
                **analysis_out.get("bias_ctx", {}),
                **analysis_out.get("signal_ctx", {}),
                **analysis_out.get("llm_ctx", {}),
                **analysis_out.get("news_ctx", {}),
                **self._risk.get_ai_context(risk_out),
                **self._decision.get_ai_context(dec_out),
                "trade_allowed": perm_out["allowed"],
                "final_action": perm_out["final_action"],
            }
            db = self._db
            df = market_out["df"]
            db.save_candles(df, self.symbol, self.timeframe)
            db.save_indicators(df, self.symbol, self.timeframe)
            # 2026-07-20 fix: market_out["df"] never has the 'pattern' /
            # 'engulfing' / 'star_pattern' columns — PatternDetector.detect_all()
            # (agents/analysis_agent.py) makes its own df.copy() before adding
            # them, so those columns only exist on analysis_out["df"]. Calling
            # save_patterns() with market_out["df"] meant every row's
            # row.get('pattern','none') silently defaulted to 'none' and got
            # skipped — patterns table stayed at 0 rows forever even though
            # pattern detection was running correctly for live decisions.
            pattern_df = analysis_out.get("df", df)
            db.save_patterns(pattern_df, self.symbol, self.timeframe)
            bias_result = analysis_out.get("bias_result") or {}
            bias_score = bias_result.get("net_score")
            bias_label = bias_result.get("bias") or "UNKNOWN"
            if bias_score is None:
                bias_score = dec_out.get("confidence", 0)
            db.save_analysis(
                self.symbol,
                self.timeframe,
                bias_score,
                bias_label,
                combined,
            )
            # Co-founder fix: save the FINAL decision signal to history,
            # not the intermediate bias_ctx signal.
            _final_action = perm_out.get("final_action", "WAIT")
            _final_confidence = dec_out.get("confidence", 0)
            _final_bias_ctx = {
                "bias": _final_action,
                "confidence_pct": _final_confidence,
                "recommendation": f"Final decision: {_final_action}",
                "has_conflict": False,
            }
            AnalysisHistory().save(
                self.symbol,
                self.timeframe,
                _final_bias_ctx,
                ind_ctx,
            )
        except Exception as e:
            log.warning(f"DB save error (non-critical): {e}")

    def _extract_candle_time(self, market_out: dict) -> str | None:
        df = market_out.get("df")
        if df is None or len(df.index) == 0:
            return None
        latest = df.index[-1]
        try:
            return latest.to_pydatetime().isoformat()
        except Exception as e:
            return str(latest)

    def _extract_pattern(self, market_out: dict) -> str:
        df = market_out.get("df")
        if df is None:
            return "none"
        for key in ("pattern_name", "pattern", "engulfing", "star_pattern"):
            if key in df.columns:
                value = df.iloc[-1].get(key, "none")
                if value and value != "none":
                    return value
        return "none"

    def _format_session_label(self, session_ctx: dict | None) -> str | None:
        if not session_ctx:
            return None
        if session_ctx.get("overlap"):
            return session_ctx["overlap"]
        active = session_ctx.get("active_sessions") or []
        if active:
            return "/".join(s.replace("_", " ").title() for s in active)
        return "Closed"

    def _session_permission_context(self, session_ctx: dict | None, fallback: dict | None = None) -> dict | None:
        ctx = session_ctx or fallback
        if not ctx:
            return None
        # Pass session_grade straight through -- trade_permission.py already
        # has the correct A+/A/B/C -> HIGH/HIGH/MEDIUM/LOW mapping (see its
        # Session quality gate). Re-deriving "quality" here from the
        # nonexistent "trade_quality" key was the bug: it always produced
        # quality="LOW" and pre-empted that correct downstream fallback.
        return {
            "session_grade": ctx.get("session_grade"),
            "session_score": ctx.get("session_score"),
            # Bug fix: trade_permission.py's fusion gate requires this
            # NESTED under "fusion" -- the flat fusion_allowed/fusion_score/
            # fusion_grade keys get_ai_context() actually produces were
            # never read anywhere, silently disabling this gate entirely.
            "fusion": {
                "fusion_allowed": ctx.get("fusion_allowed", True),
                "fusion_score":   ctx.get("fusion_score", 0),
                "fusion_grade":   ctx.get("fusion_grade", "?"),
                "issues":         ctx.get("fusion_issues", []),
            },
        }

    def _notify_trade_open(self, trade: dict, result: dict, dec_out: dict) -> None:
        """Builds the Telegram payload from `result`, not `trade` — `trade`'s
        shape differs between paper mode (full PaperTrader record) and MT5
        demo mode (still a `PENDING_EXECUTOR` stub), but `result` always has
        symbol/final_action/entry/sl/tp/lot regardless of backend."""
        if not self.notifier:
            return
        payload = {
            "pair": result.get("symbol"),
            "signal": result.get("final_action"),
            "entry": result.get("entry"),
            "sl": result.get("sl"),
            "tp": result.get("tp"),
            "lot": result.get("lot"),
        }
        self._run_async(
            self.notifier.notify_trade_open(
                payload,
                result.get("confidence", 0),
                dec_out.get("reasons", []),
                confidence_breakdown_lines=dec_out.get("confidence_breakdown_lines", []),
            )
        )

    def _notify_trade_close(self, trade: dict) -> None:
        if not self.notifier:
            return
        self._run_async(self.notifier.notify_trade_close(trade))

    def _run_async(self, coro) -> None:
        """Run an async coroutine safely (Bug fix: don't close event loop).

        Previous code used asyncio.run() which creates AND closes a loop
        each call. The python-telegram-bot Bot object caches the loop
        internally, so closing it caused 'Event loop is closed' errors
        on every subsequent call.

        Fix: delegate to utils.async_utils.run_coro_sync(), which reuses
        a persistent event loop (same fix as before) WITHOUT relying on
        the deprecated asyncio.get_event_loop() call outside a running
        loop context.
        """
        from utils.async_utils import run_coro_sync
        run_coro_sync(coro)

    def _clean_symbol(self, symbol: str) -> str:
        # Round-14 fix: see backtest/simulator.py — blanket "USDT"->"USD"
        # replace corrupted USDTRY/USDTHB (matched "USDT" mid-string, not
        # just as a Tether-quote suffix). Note: this method is also
        # defined again near line ~3370 in this same class — that later
        # definition wins at runtime (Python keeps the last one), so this
        # copy is currently dead code, but fixing both for consistency.
        cleaned = str(symbol).upper().replace("/", "").replace("=X", "").strip()
        if cleaned.endswith("USDT"):
            cleaned = cleaned[:-1]
        return cleaned

    def _error_result(self, reason: str) -> dict:
        log.error(f"Pipeline failed: {reason}")
        return {
            "symbol": self.symbol,
            "timeframe": self.timeframe,
            "version": self.VERSION,
            "final_action": "NO TRADE",
            "trade_allowed": False,
            "error": reason,
        }


class AutonomousTraderSystem:

    def __init__(
        self,
        symbols: list[str] | None = None,
        timeframe: str = "15m",
        balance: float = 10000.0,
        poll_seconds: int = 60,
        backup_interval_minutes: int = 30,
        cooldown_minutes: int = 5,
        max_cycles: int | None = None,
        enable_telegram: bool = True,
        use_scanner: bool = False,
        execution_mode: str = None,
        approval_mode: int = 3,
        registry: "Optional[ServiceRegistry]" = None,
    ):
        self.symbols = [self._clean_symbol(s) for s in (symbols or ["EURUSD", "GBPUSD", "USDJPY"])]
        self.timeframe = timeframe
        self.balance = balance
        self.poll_seconds = max(5, poll_seconds)
        self.backup_interval_minutes = max(5, backup_interval_minutes)
        self.cooldown_minutes = max(1, cooldown_minutes)
        self.max_cycles = max_cycles
        self.use_scanner = use_scanner
        self.execution_mode = (execution_mode or EXECUTION_MODE).lower()
        self.approval_mode = approval_mode
        self._stop_requested = False
        self._pause_until = None
        self._consecutive_error_cycles = 0
        self._bot_thread = None
        self._last_backup = None
        self._last_results: list[dict] = []

        # ── Day 37+ runtime unification ──────────────────────────────
        # Accept an optional ServiceRegistry. When provided, the system
        # pulls shared services (CircuitBreaker, ApprovalMode, scanner,
        # notifier, etc.) from it instead of constructing fresh copies,
        # and publishes events / metrics to the central bus.
        self._registry = registry
        self._bus = get_bus() if _RUNTIME_INFRA_AVAILABLE else None
        self._metrics = get_metrics() if _RUNTIME_INFRA_AVAILABLE else None

        # Day 36/37 — Market Scanner picks the day's Top-N tradeable pairs
        # each cycle instead of always scanning a fixed list. It needs a
        # market_data_manager (MT5 tick/candle bundle) to actually rank
        # pairs; that adapter isn't built yet, so until it is,
        # _select_cycle_symbols() below safely falls back to self.symbols.
        # If a registry is available, prefer its shared scanner.
        if registry is not None:
            shared_scanner = registry.try_resolve("market_scanner")
            if use_scanner and shared_scanner is not None:
                self.scanner = shared_scanner
            elif use_scanner and MarketScanner:
                self.scanner = MarketScanner(risk_engine=None)
            else:
                self.scanner = None
        else:
            self.scanner = MarketScanner(risk_engine=None) if (use_scanner and MarketScanner) else None

        # BUG FIX (circuit-breaker cooldown leaking across symbols): this
        # used to create ONE CircuitBreaker (symbol=None) and hand the same
        # shared instance to every symbol's AITrader via _build_trader().
        # symbol=None makes CircuitBreaker write to the legacy single global
        # state file, so a losing streak / daily-loss trip on ONE pair
        # cooled down or paused EVERY pair, including ones that hadn't lost
        # a single trade. CircuitBreaker already supports per-symbol
        # isolation (symbol=<pair> -> its own memory/circuit_breaker/
        # <symbol>.json) — it just was never constructed that way here.
        # Approval mode genuinely IS global (one human-in-the-loop switch
        # for the whole system) so it's left as a single shared instance.
        # Circuit breakers are now cached per-symbol, lazily, the same way
        # SignalPipeline._get_risk_engine() already caches per-symbol
        # RiskEngines.
        self._cb_factory = registry.try_resolve("circuit_breaker_factory") if registry is not None else None
        self._circuit_breakers: dict = {}
        self.approval = ApprovalMode(mode=approval_mode)

        if registry is not None:
            shared_notifier = registry.try_resolve("telegram_notifier")
            if shared_notifier is not None:
                self.notifier = shared_notifier
            else:
                self.notifier = TelegramNotifier() if enable_telegram and TelegramNotifier else None
        else:
            self.notifier = TelegramNotifier() if enable_telegram and TelegramNotifier else None

        # ── Shared PaperTrader ───────────────────────────────────────
        # One PaperTrader for ALL symbols so balance / open-position
        # tracking is unified.  Each AITrader previously created its own
        # PaperTrader, leading to 6 independent balances for 6 symbols.
        self._shared_paper = PaperTrader(starting_balance=balance)

        self.traders: dict[str, AITrader] = {
            symbol: self._build_trader(symbol) for symbol in self.symbols
        }
        self._sync_risk_state()

        # ── Webhook / external command subscription ──────────────────
        # Listen for webhook.command events and route them into the system.
        if self._bus is not None:
            try:
                self._bus.subscribe("webhook.command", self._on_webhook_command)
            except Exception as e:
                log.warning(f"[System] webhook.command subscription failed: {e}")

    def _on_webhook_command(self, evt) -> None:
        """Handle external commands received via webhook.
        Payload shape: {"action": "pause"|"resume"|"close_all"|"status", ...}"""
        if evt.payload is None:
            return
        action = (evt.payload.get("action") or "").lower() if isinstance(evt.payload, dict) else ""
        log.info(f"[System] Webhook command: {action} — {evt.payload}")
        if action == "pause":
            self._pause_until = datetime.now(timezone.utc) + timedelta(hours=1)
            log.info("[System] Paused via webhook for 1 hour")
        elif action == "resume":
            self._pause_until = None
            log.info("[System] Resumed via webhook")
        elif action == "stop":
            self.stop()
        elif action == "status":
            # The next cycle will write a fresh latest_report.json
            pass

    def _get_circuit_breaker(self, symbol: str) -> "CircuitBreaker":
        """Per-symbol CircuitBreaker, lazily created and cached — mirrors
        SignalPipeline._get_risk_engine(). Fixes the cooldown-leaking-across-
        symbols bug: each pair now gets its own memory/circuit_breaker/
        <symbol>.json instead of every pair sharing one global file."""
        if symbol not in self._circuit_breakers:
            if self._cb_factory is not None:
                self._circuit_breakers[symbol] = self._cb_factory(symbol, self.balance)
            else:
                self._circuit_breakers[symbol] = CircuitBreaker(symbol=symbol, balance=self.balance)
        return self._circuit_breakers[symbol]

    def _circuit_breaker_status_summary(self) -> dict:
        """Aggregate per-symbol CircuitBreaker status for dashboards.

        Now that each symbol has its own CircuitBreaker (see
        _get_circuit_breaker), there's no longer a single global status to
        report. `by_symbol` gives the full per-pair breakdown; `worst`
        surfaces whichever symbol is currently the most restricted
        (PAUSED > COOLDOWN > LEARNING > TRADING) so existing dashboard code
        expecting one summary object still has something sensible to show.
        """
        by_symbol = {
            sym: cb.get_status() for sym, cb in self._circuit_breakers.items()
        }
        if not by_symbol:
            return {"mode": "TRADING", "by_symbol": {}}
        priority = {"PAUSED": 3, "COOLDOWN": 2, "LEARNING": 1, "TRADING": 0}
        worst_sym = max(by_symbol, key=lambda s: priority.get(by_symbol[s].get("mode"), 0))
        worst = dict(by_symbol[worst_sym])
        worst["by_symbol"] = by_symbol
        return worst

    def _build_trader(self, symbol: str) -> AITrader:
        return AITrader(
            balance=self.balance,
            symbol=symbol,
            timeframe=self.timeframe,
            paper_balance=self.balance,
            notifier=self.notifier,
            execution_mode=self.execution_mode,
            approval_mode=self.approval_mode,
            circuit_breaker=self._get_circuit_breaker(symbol),
            approval=self.approval,
            registry=self._registry,
            paper_trader=self._shared_paper,
        )

    def run(self) -> dict:
        # Day 37+ fix: reset stop flag so run() can be called again after a
        # previous stop() / crash. This makes auto-restart from main.py work.
        self._stop_requested = False
        self._start_telegram_commands()
        self.backup_state(force=True)
        cycles = 0

        # ── Day 66: Send Telegram alert for upcoming high-impact news ──
        try:
            from intelligence.news_ai import get_news_intelligence
            news_ai = get_news_intelligence()
            news_ai.set_pairs(self.symbols)
            alert_msg = news_ai.format_telegram_alert()
            if alert_msg and self.notifier:
                # Issue 9 fix: route through the shared run_coro_sync() helper
                # instead of calling the deprecated asyncio.get_event_loop()
                # directly. run_coro_sync() reuses one persistent loop per
                # process, so we never create-and-abandon loops here.
                from utils.async_utils import run_coro_sync
                run_coro_sync(self.notifier.send_message(alert_msg))
        except Exception as e:
            log.debug(f"[System] Day 66 news alert failed: {e}")

        log.info(
            f"[System] Starting autonomous loop | Pairs={self.symbols} | "
            f"Timeframe={self.timeframe} | Mode={self.execution_mode.upper()} | "
            f"Scanner={'ON' if self.use_scanner else 'OFF'} | "
            f"Risk Balance=${self.balance} (config) | "
            f"Registry={'yes' if self._registry else 'no'}"
        )

        # Publish startup event
        if self._bus is not None:
            try:
                self._bus.publish("system.startup", {
                    "phase": "trader_loop",
                    "symbols": self.symbols,
                    "mode": self.execution_mode,
                    "balance": self.balance,
                }, source="autonomous_trader")
            except Exception as e:
                log.warning(f"Suppressed exception at line 1779: {e}")
                pass

        try:
            while not self._stop_requested:
                cycle_started = time.time()
                if self.max_cycles is not None and cycles >= self.max_cycles:
                    break

                if self._is_paused():
                    self._sleep_remaining(cycle_started)
                    cycles += 1
                    continue

                # BUG FIX: reset_fallback_throttle_cycle() (in
                # intelligence/sentiment_model.py) resets the dedicated
                # SentimentModel per-cycle LLM budget (default 5 calls)
                # plus the key_manager-absent fallback throttle. It was
                # defined but never called anywhere in the codebase —
                # confirmed via a full-repo grep, only the def line itself
                # matched. Result: the counter only ever incremented,
                # never reset, so once 5 sentiment LLM calls happened
                # (typically during the very first NewsIntelligence burst
                # at boot), EVERY subsequent sentiment.analyze() call for
                # the rest of the process's lifetime was silently skipped
                # with "sentiment cap: 5 calls/cycle reached" — headline
                # sentiment analysis was effectively permanently dead
                # after the first few seconds of runtime. Calling it here,
                # once at the top of every cycle (mirrors the cadence the
                # real _key_manager.check_cycle_throttle() resets on),
                # fixes that.
                try:
                    from intelligence.sentiment_model import reset_fallback_throttle_cycle
                    reset_fallback_throttle_cycle()
                except Exception as e:
                    log.debug(f"[System] sentiment cycle-throttle reset skipped (non-fatal): {e}")

                cycle_results = []
                cycle_errors = []
                active_symbols = self._select_cycle_symbols()
                if self._metrics is not None:
                    try:
                        self._metrics.record_cycle()
                        self._metrics.set_gauge("trader.active_symbols", len(active_symbols))
                    except Exception as e:
                        log.warning(f"Suppressed exception at line 1801: {e}")
                        pass

                # Co-founder fix: detect MT5 position closes BEFORE per-symbol
                # cycles run. Previously, MT5 SL/TP hits during runtime were
                # only reconciled at next boot via orphan_cleanup — meaning
                # the bot kept trading as if the position was still open,
                # and the close event (with its WIN/LOSS outcome) was lost
                # until restart. This polls MT5 once per cycle, compares to
                # the last snapshot, and for any disappeared ticket fires
                # the same close handlers that paper-trade closes go through.
                try:
                    self._detect_mt5_position_closes()
                except Exception as e:
                    log.debug(f"[System] MT5 close detection failed (non-fatal): {e}")

                # ── Audit fix: weekend gap-risk guard ──────────────────
                # core/production_hardening.py's should_close_for_weekend()
                # already correctly implements the Friday-late/Saturday/
                # Sunday-pre-open rules, but nothing in the live loop ever
                # called it — so weekend gap risk wasn't being actively
                # managed by this logic. Wired here, once per cycle, before
                # any per-symbol analysis runs.
                #
                # Scope kept deliberately conservative: this blocks NEW
                # entries (via the existing _pause_until mechanism already
                # used by webhook "pause" commands, checked at the top of
                # this loop) and, only for the hard Saturday/Friday-late
                # "close all" case, reuses the exact close pattern this
                # file already uses for the catastrophic-error emergency
                # close a few lines below (hasattr(t, '_order_manager') →
                # close_all_orders()) rather than inventing a new,
                # unverified close path. The "reduce 50%" Friday-evening
                # case is logged only — automatically resizing live
                # positions is a materially different (and riskier)
                # operation than blocking new entries, and isn't
                # implemented here without a verified position-resize API.
                try:
                    from core.production_hardening import should_close_for_weekend
                    _weekend_positions = []
                    for _t in self.traders.values():
                        try:
                            _weekend_positions.extend(_t._paper.get_open_positions())
                        except Exception:
                            pass
                    weekend_check = should_close_for_weekend(_weekend_positions)
                    if weekend_check.get("should_close_all"):
                        log.critical(f"[Weekend] {weekend_check.get('reason')} — "
                                     f"blocking new entries and attempting close-all")
                        self._pause_until = datetime.now(timezone.utc) + timedelta(hours=1)
                        for sym, t in self.traders.items():
                            _om = t._registry.try_resolve("order_manager") if t._registry else None
                            if _om is not None:
                                try:
                                    _results = _om.close_all_orders(
                                        reason=f"Weekend guard: {weekend_check.get('reason')}"
                                    )
                                    # P1 fix: was silently discarded; now check + alert.
                                    _failed = [r for r in (_results or []) if not r.get("success")]
                                    if _failed:
                                        log.error(f"[Weekend] {sym}: {len(_failed)} positions failed to close")
                                        # Best-effort Telegram alert
                                        try:
                                            if self.notifier is not None:
                                                self.notifier.send(
                                                    f"⚠️ Weekend close failed for {sym}: "
                                                    f"{len(_failed)} positions still open"
                                                )
                                        except Exception:
                                            pass
                                except Exception as e:
                                    log.warning(f"[Weekend] close_all_orders failed for {sym}: {e}")
                        if self._bus is not None:
                            try:
                                self._bus.publish("risk.event", {
                                    "kind": "weekend_guard_close_all",
                                    "reason": weekend_check.get("reason"),
                                }, source="autonomous_trader")
                            except Exception:
                                pass
                    elif weekend_check.get("should_reduce"):
                        log.warning(f"[Weekend] {weekend_check.get('reason')} — "
                                    f"consider manually reducing exposure "
                                    f"(auto-resize not implemented)")
                except Exception as e:
                    log.debug(f"[System] Weekend guard check skipped (non-fatal): {e}")

                for symbol in active_symbols:
                    # ── Skip symbols known to be unavailable on broker ──
                    # Avoids wasting cycle time on 30+ non-existent symbols
                    # (USOUSD, BTCUSD, etc.) that would all fail and
                    # trigger spurious recovery pauses.
                    try:
                        from data.fetcher import is_symbol_unavailable
                        if is_symbol_unavailable(symbol):
                            continue
                    except Exception:
                        pass

                    trader = self.traders.get(symbol) or self._spawn_trader(symbol)
                    try:
                        if self._manual_pause_active():
                            closed = trader.monitor_open_trades()
                            cycle_results.append(
                                {
                                    "symbol": symbol,
                                    "final_action": "WAIT",
                                    "trade_allowed": False,
                                    "closed_trades": closed,
                                    "reject_reason": "Trading paused from Telegram",
                                }
                            )
                            continue

                        result = trader.run_cycle(auto_paper_trade=True)
                        cycle_results.append(result)
                        if result.get("error"):
                            cycle_errors.append(f"{symbol}: {result['error']}")
                    except Exception as e:
                        msg = f"{symbol}: {e}"
                        cycle_errors.append(msg)
                        log.exception(f"[System] Symbol cycle failed — {msg}")

                self._last_results = cycle_results
                self._write_runtime_report()

                # ── Day 100+ — Feature drift detection (wire dead code) ──
                # Runs every 50 cycles to detect ML feature distribution shift.
                # If significant drift is found, logs a warning recommending retraining.
                if cycles % 50 == 0 and cycles > 0:
                    try:
                        from ml.feature_selector import get_feature_selector
                        import pandas as pd
                        fs = get_feature_selector()
                        # Use recent df from any trader as "current" window
                        for sym, t in self.traders.items():
                            _mkt = getattr(t, '_market', None)
                            _df = getattr(_mkt, '_df', None) if _mkt is not None else None
                            if _df is not None and len(_df) > 100:
                                ref = _df.iloc[-200:-50]  # reference window
                                cur = _df.iloc[-50:]        # current window
                                if len(ref) > 10 and len(cur) > 10:
                                    drift_results = fs.detect_drift(ref, cur)
                                    sig = [d for d in drift_results if d.drift_level == "SIGNIFICANT"]
                                    if sig:
                                        log.warning(
                                            f"[System] ML DRIFT DETECTED on {sym}: "
                                            f"{len(sig)} features with significant drift — "
                                            f"retraining recommended. Top: "
                                            f"{sig[0].feature_name} (PSI={sig[0].psi:.3f})"
                                        )
                                break  # only check first available symbol
                    except Exception as e:
                        log.debug(f"[System] Drift check skipped: {e}")

                if cycle_errors:
                    # FIX: Don't trigger recovery pause for fetch_failed errors
                    # when the data source itself is down (systemic issue).
                    # If MOST symbols fail with fetch_failed, it's a data
                    # source problem, not a per-symbol problem — pausing
                    # won't help. Only pause when errors are NON-fetch
                    # (e.g., indicator crash, execution failure, DB error).
                    fetch_errors = [e for e in cycle_errors if "fetch_failed" in e or "fetchfailed" in e]
                    real_errors = [e for e in cycle_errors if e not in fetch_errors]
                    if real_errors:
                        self._handle_cycle_errors(real_errors)
                    elif fetch_errors and len(fetch_errors) == len(cycle_errors):
                        # ALL errors are fetch failures — log but don't pause.
                        # The auto-unavailable marking in fetcher.py will
                        # progressively reduce the error count each cycle.
                        if self._consecutive_error_cycles == 0:
                            log.warning(
                                f"[Recovery] {len(fetch_errors)} symbol(s) failed data fetch "
                                f"(source down). Not pausing — symbols will be auto-skipped. "
                                f"Symbols: {', '.join(fetch_errors[:5])}"
                                + (f" +{len(fetch_errors)-5} more" if len(fetch_errors) > 5 else "")
                            )
                        self._consecutive_error_cycles += 1
                    else:
                        # Mixed fetch + real errors — pause for the real ones
                        self._handle_cycle_errors(real_errors)
                else:
                    self._consecutive_error_cycles = 0

                self.backup_state()

                # KILL SHOT FIX: DB backup every 100 cycles
                # If the single SQLite DB corrupts, we lose ALL trade history.
                # Back it up periodically so we can recover.
                if cycles % 100 == 0 and cycles > 0:
                    try:
                        import shutil
                        src = str(DATABASE_DIR / "trader.db")
                        dst = str(DATABASE_DIR / f"trader_backup_{cycles}.db")
                        shutil.copy2(src, dst)
                        # Keep only last 3 backups
                        import glob
                        backups = sorted(glob.glob(str(DATABASE_DIR / "trader_backup_*.db")))
                        for old in backups[:-3]:
                            os.remove(old)
                        log.debug(f"[System] DB backed up to {dst}")
                    except Exception as e:
                        log.warning(f"[System] DB backup failed: {e}")

                # KILL SHOT FIX: Emergency close-all on catastrophic error streak
                # If 10 consecutive cycles ALL fail, close everything and halt.
                if self._consecutive_error_cycles >= 10:
                    log.critical(
                        f"[System] CATASTROPHIC: {self._consecutive_error_cycles} "
                        f"consecutive error cycles — EMERGENCY CLOSE ALL"
                    )
                    try:
                        for sym, t in self.traders.items():
                            _om = t._registry.try_resolve("order_manager") if t._registry else None
                            if _om is not None:
                                try:
                                    _results = _om.close_all_orders(
                                        reason="Emergency: 10 consecutive error cycles"
                                    )
                                    # P1 fix: check per-symbol results; was silently discarded.
                                    _failed = [r for r in (_results or []) if not r.get("success")]
                                    if _failed:
                                        log.critical(f"[System] {sym}: {len(_failed)} positions "
                                                     f"failed to close during emergency")
                                        try:
                                            if self.notifier is not None:
                                                self.notifier.send(
                                                    f"🚨 EMERGENCY close failed for {sym}: "
                                                    f"{len(_failed)} positions still open"
                                                )
                                        except Exception:
                                            pass
                                except Exception as _e:
                                    log.critical(f"[System] {sym} emergency close failed: {_e}")
                    except Exception as e:
                        log.critical(f"[System] Emergency close loop failed: {e}")
                    self._stop_requested = True
                    break

                self._sleep_remaining(cycle_started)
                cycles += 1

        except KeyboardInterrupt:
            log.info("[System] Stop requested by user")
        except Exception as e:
            # Day 37+ fix: any unexpected error in the outer loop used to
            # kill the trader entirely. Now we log + publish + keep the
            # function returning a report (main.py's auto-restart wrapper
            # will re-launch the loop).
            log.exception(f"[System] FATAL error in trading loop: {e}")
            try:
                if self._bus is not None:
                    self._bus.publish("system.error", {
                        "channel": "fatal_loop",
                        "reason": str(e),
                        "phase": "trader_loop",
                    }, source="autonomous_trader")
            except Exception as e:
                log.warning(f"Suppressed exception at line 1884: {e}")
                pass

        report = self._build_system_report()
        self._write_runtime_report(report)
        return report

    def stop(self) -> None:
        self._stop_requested = True

    # ──────────────────────────────────────────────────────────────
    # Co-founder fix: LIVE MT5 CLOSE DETECTION
    # ──────────────────────────────────────────────────────────────
    # Previously, MT5 SL/TP hits during runtime were only reconciled
    # at next boot via orphan_cleanup.reconcile_open_positions(). This
    # meant:
    #   1. The bot kept trading as if the position was still open
    #      (exposure/correlation risk still counted the closed trade)
    #   2. The close event (WIN/LOSS + pnl) was lost until restart
    #   3. CircuitBreaker, RiskEngine, and LearningAgent never saw
    #      the outcome — streak counters and win-rate stats were wrong
    #   4. If the bot crashed before next boot, the close was lost
    #      permanently
    #
    # This method runs once per cycle (before per-symbol trading),
    # snapshots MT5 positions, and for any ticket that disappeared
    # since the last snapshot, looks up the close in MT5 history and
    # fires the same close handlers that paper-trade closes go through.
    # ──────────────────────────────────────────────────────────────

    # Day 131 fix: `_mt5_known_tickets` used to be declared here as a
    # class-level mutable default (`_mt5_known_tickets: dict = {}`).
    # Because it's a dict (mutable), every AITrader instance — i.e. every
    # symbol — shared the *same* dict object until each instance's first
    # write. The guard below (`hasattr(self, ...)`) never caught this,
    # since `hasattr` is true for inherited class attributes too. In a
    # multi-symbol run, the very first read of this dict for a given
    # symbol could see ticket data left behind by a *different* symbol's
    # close-detection pass in the same cycle, producing false "closed
    # position" events (and the wrong PnL/close handlers firing) for the
    # wrong symbol. Now initialized per-instance in __init__ instead.

    def _detect_mt5_position_closes(self) -> list[dict]:
        """Poll MT5 once, detect closes, fire close handlers.

        Returns the list of close events detected this cycle. Safe to
        call when MT5 is unavailable (paper mode) — returns [].
        """
        # Skip entirely in paper mode or simulation
        if self.execution_mode != "mt5_demo":
            return []
        try:
            _sim_mode = bool(getattr(self._router, "_simulation_mode", False))
            if _sim_mode:
                return []
        except Exception:
            return []

        # Resolve shared MT5 connection (Day 131 fix — see
        # _resolve_mt5_connection() docstring for root cause).
        mt5_conn = self._resolve_mt5_connection()
        if mt5_conn is None:
            # Audit fix: this used to just `return []` silently every time
            # MT5 was unreachable, which meant a real broker-side close
            # (and its PnL) simply never got detected until the connection
            # came back — the daily-loss circuit breaker was blind for the
            # whole outage. We now count consecutive unreachable cycles so
            # run_cycle() can fail closed on NEW entries once the outage
            # has lasted long enough that "unknown" can't be treated as
            # "fine". Existing positions are never force-closed by this.
            self._mt5_disconnect_cycles = getattr(self, "_mt5_disconnect_cycles", 0) + 1
            if self._mt5_disconnect_cycles == 1 or self._mt5_disconnect_cycles % 5 == 0:
                log.warning(
                    f"[MT5CloseDetect] No shared MT5 connection — close "
                    f"detection skipped ({self._mt5_disconnect_cycles} "
                    f"consecutive cycles unreachable)"
                )
            return []

        # Snapshot current positions (our magic only)
        try:
            from core.constants import MT5_MAGIC_NUMBER
            positions = mt5_conn.positions_get()
            if positions is None:
                # Throttle this warning the same way _get_live_open_pairs
                # does — close-detection runs every cycle, so without
                # throttling this spams trader.log once per minute when
                # MT5 terminal is unreachable.
                self._mt5_disconnect_cycles = getattr(self, "_mt5_disconnect_cycles", 0) + 1
                _now = time.time()
                if _now - getattr(self, "_mt5_close_detect_warn_last_ts", 0.0) > 300:
                    log.warning(
                        "[MT5CloseDetect] positions_get() returned None "
                        "(MT5 terminal may not be running or account issue) — "
                        "close detection skipped for %d consecutive cycles "
                        "(warning throttled to once per 5min)",
                        self._mt5_disconnect_cycles,
                    )
                    self._mt5_close_detect_warn_last_ts = _now
                return []
            current = {
                p.ticket: p
                for p in positions
                if getattr(p, "magic", MT5_MAGIC_NUMBER) == MT5_MAGIC_NUMBER
            }
        except Exception as e:
            log.debug(f"[MT5CloseDetect] positions_get failed: {e}")
            self._mt5_disconnect_cycles = getattr(self, "_mt5_disconnect_cycles", 0) + 1
            return []

        # Successful poll — connection is healthy again.
        if getattr(self, "_mt5_disconnect_cycles", 0) > 0:
            log.info(
                f"[MT5CloseDetect] MT5 connection restored after "
                f"{self._mt5_disconnect_cycles} cycles — resuming normal "
                f"close detection"
            )
        self._mt5_disconnect_cycles = 0

        # Day 131 fix: _mt5_known_tickets is now always set per-instance
        # in __init__, so this is just a defensive belt-and-suspenders
        # check (e.g. for pre-existing pickled/older instances).
        if getattr(self, "_mt5_known_tickets", None) is None:
            self._mt5_known_tickets = {}

        # Find tickets that disappeared → closed
        closed_tickets = set(self._mt5_known_tickets.keys()) - set(current.keys())
        if not closed_tickets:
            self._mt5_known_tickets = current
            return []

        events = []
        for ticket in closed_tickets:
            last_pos = self._mt5_known_tickets[ticket]
            event = self._handle_mt5_close(mt5_conn, ticket, last_pos)
            if event:
                events.append(event)

        # Update snapshot
        self._mt5_known_tickets = current
        return events

    def _handle_mt5_close(self, mt5_conn, ticket: int, last_pos) -> dict | None:
        """Look up a closed MT5 position in history and fire close handlers.

        Uses mt5.history_get_by_ticket() (available in MT5 Python package)
        to retrieve the close price, close time, and profit. Then routes
        the close through _process_closed_trades so all the same handlers
        fire as for paper-trade closes (risk, circuit_breaker, memory,
        learning, journal).
        """
        try:
            import MetaTrader5 as mt5
            from datetime import datetime, timezone, timedelta
            from core.constants import MT5_MAGIC_NUMBER

            # history_get_by_ticket returns the deal that closed the position
            # Look back 24 hours for the close deal
            utc_to = datetime.now(timezone.utc)
            utc_from = utc_to - timedelta(hours=24)
            with mt5_conn.MT5_LOCK:
                deals = mt5.history_deals_get(utc_from, utc_to)
            if deals is None:
                log.warning(f"[MT5CloseDetect] No history deals for ticket {ticket}")
                return None

            # Find the closing deal for this position
            close_deal = None
            for d in deals:
                # position_id == ticket for the closing deal
                if getattr(d, "position_id", 0) == ticket:
                    close_deal = d
                    break

            symbol = getattr(last_pos, "symbol", "UNKNOWN")
            direction = "BUY" if getattr(last_pos, "type", 0) == 0 else "SELL"
            entry = float(getattr(last_pos, "price_open", 0))
            volume = float(getattr(last_pos, "volume", 0))
            sl = float(getattr(last_pos, "sl", 0))
            tp = float(getattr(last_pos, "tp", 0))

            if close_deal is not None:
                close_price = float(getattr(close_deal, "price", 0))
                pnl = float(getattr(close_deal, "profit", 0))
                # Tolerance-based SL/TP detection: slippage can cause the
                # close price to miss the exact SL/TP by a few pips.
                # Use 2× pip_size tolerance so positive slippage on a
                # BUY SL (price gaps BELOW the SL) still gets detected.
                try:
                    from core.constants import get_pip_size
                    _pip_size = get_pip_size(symbol)
                except Exception:
                    _pip_size = 0.0001  # safe fallback for most pairs
                _tol = 2 * _pip_size
                close_reason = "SL HIT" if close_price <= sl + _tol and direction == "BUY" else \
                               "SL HIT" if close_price >= sl - _tol and direction == "SELL" else \
                               "TP HIT" if close_price >= tp - _tol and direction == "BUY" else \
                               "TP HIT" if close_price <= tp + _tol and direction == "SELL" else \
                               "MANUAL"
            else:
                # Can't find the close deal — best-effort estimate
                close_price = entry
                pnl = 0.0
                close_reason = "UNKNOWN (no history deal)"

            result = "WIN" if pnl > 0 else ("LOSS" if pnl < 0 else "BREAKEVEN")

            # Build a close event in the same shape as PaperTrader.close_trade
            close_event = {
                "pair": symbol,
                "type": direction,
                "entry": entry,
                "exit_price": close_price,
                "lot": volume,
                "sl": sl,
                "tp": tp,
                "pnl": pnl,
                "pnl_pips": 0.0,  # would need pip_size to compute; non-critical
                "result": result,
                "reason": close_reason,
                "ticket": ticket,
                "close_time": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "context": {
                    "source": "mt5_demo",
                    "mt5_ticket": ticket,
                    "memory_trade_id": None,  # unknown — orphan fallback will handle
                    "close_reason": close_reason,
                },
            }

            log.info(
                f"[MT5CloseDetect] Close detected: {symbol} {direction} "
                f"ticket={ticket} → {result} ${pnl:.2f} ({close_reason})"
            )

            # Route through any AITrader's _process_closed_trades so all
            # close handlers fire (risk, CB, memory, learning, journal).
            # Pick the trader for this symbol, or the first available.
            target_trader = self.traders.get(symbol)
            if target_trader is None and self.traders:
                target_trader = next(iter(self.traders.values()))
            if target_trader is not None:
                try:
                    target_trader._process_closed_trades([close_event])
                    log.info(f"[MT5CloseDetect] Close event routed to AITrader({symbol}) for handler processing")
                except Exception as e:
                    log.warning(f"[MT5CloseDetect] Failed to route close to AITrader: {e}")

            return close_event

        except Exception as e:
            log.warning(f"[MT5CloseDetect] _handle_mt5_close failed for ticket {ticket}: {e}")
            return None

    def _select_cycle_symbols(self) -> list[str]:
        """Scanner-driven Top-N pairs when enabled and wired up; the static
        symbol list otherwise (or on any scanner failure).

        Day 37+ professional upgrade: when scanner is disabled, fall back to
        SessionAwarePairSelector instead of returning ALL 28 pairs every cycle.
        This makes each cycle focus on 8-12 pairs that are active in the
        current trading session (London/NY/Tokyo) instead of blindly scanning
        all 28 — faster cycles, higher-quality signals.
        """
        # 1. Scanner-driven mode (if enabled)
        if self.use_scanner and self.scanner:
            try:
                ranked = self.scanner.scan()
                top = self.scanner.get_top_opportunities(ranked)
                scanned = [opp["symbol"] for opp in top]
                if scanned:
                    return scanned
            except Exception as e:
                log.warning(f"[System] Scanner failed, falling back to session-aware selection: {e}")

        # 2. Session-aware fallback (Day 37+ professional default)
        try:
            from core.professional_tools import get_pair_selector
            selector = get_pair_selector(self.symbols)
            pairs, session = selector.select_with_session(top_n=len(self.symbols))
            if pairs:
                log.info(f"[System] Session-aware pair selection: {session} → {len(pairs)} pairs")
                return pairs
        except Exception as e:
            log.warning(f"[System] Session-aware selector failed: {e}")

        # 3. Final fallback: all symbols
        return self.symbols

    def _spawn_trader(self, symbol: str) -> AITrader:
        symbol = self._clean_symbol(symbol)
        trader = self._build_trader(symbol)
        self.traders[symbol] = trader
        return trader

    def backup_state(self, force: bool = False) -> Path | None:
        now = datetime.now(timezone.utc)
        if not force and self._last_backup:
            due_at = self._last_backup + timedelta(minutes=self.backup_interval_minutes)
            if now < due_at:
                return None

        timestamp = now.strftime("%Y%m%d_%H%M%S")
        backup_dir = BACKUPS_DIR / timestamp
        backup_dir.mkdir(parents=True, exist_ok=True)

        for src_path in [
            DATABASE_DIR / "trader.db",
            MEMORY_DIR / "trader.db",
            MEMORY_DIR / "trade_memory.json",
            MEMORY_DIR / "daily_risk.json",
            MEMORY_DIR / "analysis_history.json",
            MEMORY_DIR / "circuit_breaker_state.json",
            MEMORY_DIR / "pending_approvals.json",
        ]:
            if src_path.exists():
                shutil.copy2(str(src_path), backup_dir / src_path.name)

        self._last_backup = now
        log.info(f"[System] Backup created: {backup_dir}")
        return backup_dir

    def _handle_cycle_errors(self, errors: list[str]) -> None:
        self._consecutive_error_cycles += 1
        self._pause_until = datetime.now(timezone.utc) + timedelta(minutes=self.cooldown_minutes)
        reason = "; ".join(errors[:3])
        log.error(f"[Recovery] Pausing trading after errors: {reason}")

        if self.notifier:
            self._notify_system_warning(
                reason,
                f"{self.cooldown_minutes} minutes",
            )

    def _sync_risk_state(self) -> None:
        # Day 96 bugfix: was reading trader._paper directly (always empty
        # in mt5_demo mode) — now reuses AITrader._get_live_open_pairs(),
        # which reads real MT5 positions when execution_mode=mt5_demo.
        open_pairs = []
        for trader in self.traders.values():
            open_pairs.extend(trader._get_live_open_pairs())
        for trader in self.traders.values():
            trader._risk.sync_open_positions(open_pairs)

    def _start_telegram_commands(self) -> None:
        """
        Telegram polling boot_alerts phase এ already start হয়ে গেছে।
        এখানে আর start করার দরকার নেই — duplicate = 409 Conflict।
        শুধু log করি যে notifier available আছে কিনা।
        """
        if self.notifier:
            log.info("[System] Telegram notifier ready (polling already started by boot_alerts)")
        else:
            log.info("[System] Telegram notifier not available — skipping")

    def _notify_warning(self, event_name: str, time_remaining: str) -> None:
        if not self.notifier:
            return
        # Bug fix: use _run_async instead of asyncio.run (avoids event loop closure)
        self._run_async_safe(self.notifier.notify_news_warning(event_name, time_remaining))

    def _notify_system_warning(self, reason: str, pause_duration: str) -> None:
        if not self.notifier:
            return
        self._run_async_safe(self.notifier.notify_system_warning(reason, pause_duration))

    def _run_async_safe(self, coro) -> None:
        """Run an async coroutine safely.

        Issue 9 fix: delegate to utils.async_utils.run_coro_sync(), the same
        persistent-loop helper AITrader._run_async() uses, instead of a
        second, duplicated asyncio.get_event_loop()/new_event_loop() dance.
        Avoids the deprecated get_event_loop() call and the "Event loop is
        closed" errors that come from repeatedly creating/discarding loops.
        """
        try:
            from utils.async_utils import run_coro_sync
            run_coro_sync(coro)
        except Exception as e:
            log.warning(f"Telegram notify failed: {e}")

    def _manual_pause_active(self) -> bool:
        return bool(telegram_module and getattr(telegram_module, "IS_TRADING_PAUSED", False))

    def _is_paused(self) -> bool:
        if not self._pause_until:
            return False
        if datetime.now(timezone.utc) >= self._pause_until:
            log.info("[Recovery] Cooldown completed. Resuming trading loop safely.")
            self._pause_until = None
            return False
        return True

    def _sleep_remaining(self, cycle_started: float) -> None:
        elapsed = time.time() - cycle_started
        remaining = max(0, self.poll_seconds - elapsed)
        if remaining:
            time.sleep(remaining)

    def _write_runtime_report(self, report: dict | None = None) -> Path:
        report = report or self._build_system_report()
        report_dir = REPORTS_DIR
        report_dir.mkdir(parents=True, exist_ok=True)
        path = report_dir / "latest_report.json"
        path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        return path

    def _build_system_report(self) -> dict:
        sample_trader = next(iter(self.traders.values()))
        stats = sample_trader._db.get_overall_stats(starting_balance=self.balance)
        recent = sample_trader._db.get_trade_history(limit=20)

        best_setup = "N/A"
        biggest_mistake = "N/A"
        if not recent.empty and "pattern" in recent.columns:
            wins = recent[recent["result"] == "WIN"]
            losses = recent[recent["result"] == "LOSS"]
            if not wins.empty:
                best_setup = str(wins["pattern"].fillna("unknown").mode().iloc[0])
            if not losses.empty:
                biggest_mistake = str(losses["pattern"].fillna("unknown").mode().iloc[0])

        avg_rr = 0
        closed_count = len(recent.index)
        if closed_count and {"entry", "sl", "tp"}.issubset(set(recent.columns)):
            rr_values = []
            for _, row in recent.iterrows():
                try:
                    risk = abs(float(row["entry"]) - float(row["sl"]))
                    reward = abs(float(row["tp"]) - float(row["entry"]))
                    rr_values.append(round(reward / risk, 2) if risk else 0)
                except Exception as e:
                    log.warning(f"Suppressed exception at line 2061: {e}")
                    continue
            if rr_values:
                avg_rr = round(sum(rr_values) / len(rr_values), 2)

        return {
            "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "mode": self.execution_mode.upper(),
            "scanner": "ON" if self.use_scanner else "OFF",
            "pairs": self.symbols,
            "active_pairs": list(self.traders.keys()),
            "timeframe": self.timeframe,
            "balance": self.balance,
            "system_state": "PAUSED" if self._manual_pause_active() or self._is_paused() else "RUNNING",
            "circuit_breaker": self._circuit_breaker_status_summary(),
            "summary": {
                "trades": stats.get("total", 0),
                "wins": stats.get("wins", 0),
                "losses": stats.get("losses", 0),
                "win_rate": stats.get("win_rate", 0),
                "profit": stats.get("total_pnl", 0),
                "balance": stats.get("balance", self.balance),
                "open_positions": stats.get("open_trades", 0),
                "average_rr": avg_rr,
                "best_setup": best_setup,
                "biggest_mistake": biggest_mistake,
            },
            "last_results": self._last_results[-len(self.symbols):],
        }

    def _clean_symbol(self, symbol: str) -> str:
        # Round-14 fix: see backtest/simulator.py — blanket "USDT"->"USD"
        # replace corrupted real FX codes containing "USDT" as a
        # substring: USDTRY (USD/Turkish Lira) -> USDRY, USDTHB
        # (USD/Thai Baht) -> USDHB. This is the definition that actually
        # runs (Python keeps the last of two same-named methods in this
        # class — see the now-dead duplicate near line 2533).
        cleaned = str(symbol).upper().replace("/", "").replace("=X", "").strip()
        if cleaned.endswith("USDT"):
            cleaned = cleaned[:-1]
        return cleaned

    # ── Day 37+ runtime unification: health & introspection ──────────
    def health_status(self) -> dict:
        """Return a snapshot of system health for the dashboard / health monitor.
        Aggregates circuit-breaker state, open positions, last cycle results,
        and any registered runtime metrics."""
        cb = self._circuit_breaker_status_summary()
        open_positions = []
        for trader in self.traders.values():
            try:
                # In mt5_demo mode, _paper is empty — use live MT5 positions
                # via _get_live_open_pairs() which already handles the
                # mode-aware lookup (MT5 vs paper).
                if trader.execution_mode == "mt5_demo":
                    open_positions.extend(trader._get_live_open_pairs())
                else:
                    open_positions.extend(trader._paper.get_open_positions())
            except Exception as e:
                log.warning(f"health_status open-positions fetch failed for {trader.symbol}: {e}")
        return {
            "running": not self._stop_requested,
            "paused": self._is_paused(),
            "manual_pause": self._manual_pause_active(),
            "execution_mode": self.execution_mode,
            "approval_mode": self.approval.mode_name if self.approval else "N/A",
            "symbols": self.symbols,
            "active_traders": list(self.traders.keys()),
            "circuit_breaker": cb,
            "open_positions": len(open_positions),
            "last_cycle_results": (self._last_results or [])[-len(self.symbols):],
            "consecutive_error_cycles": self._consecutive_error_cycles,
            "registry_wired": self._registry is not None,
            "bus_wired": self._bus is not None,
            "metrics_wired": self._metrics is not None,
        }

    def get_runtime_metrics(self) -> dict:
        """Return the runtime metrics report, if available."""
        if self._metrics is not None:
            try:
                return self._metrics.build_report()
            except Exception as e:
                return {"error": str(e)}
        return {"error": "runtime metrics not wired"}